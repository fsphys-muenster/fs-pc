"""
  This file defines various functions used by all of CRA.

  (C) Fuji Xerox Co., Ltd. 2010-2012
 
  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:
  1. Redistributions of source code must retain the above copyright
     notice, this list of conditions and the following disclaimer.
  2. Redistributions in binary form must reproduce the above copyright
     notice, this list of conditions and the following disclaimer in the
     documentation and/or other materials provided with the distribution.
  3. Neither the name of Fuji Xerox Co., Ltd. nor the names of its
     contributors may be used to endorse or promote products derived from
     this software without specific prior written permission.
  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
  POSSIBILITY OF SUCH DAMAGE.
"""

try:
    import locale
    import os
    
    from common import defs
except:
    raise # Exception code is written in parent module.

def get_locale():
    """ Get locale name from locale module of python library.
    If failed to get from locale module because current locale is 
    not supported by python, get LANG environment value from system.
    
    Return Values:
    Locale name -- Succeed to get from locale module.
    LANG environment value -- Failed to get from locale module.
    """
    try:
        sys_locale_and_lang = locale.getdefaultlocale()
        locale_name = sys_locale_and_lang[0]
        if locale_name is None:
            raise ValueError
    except:
        locale_name = os.environ[defs.ENV_LANG]
    locale_name = normalize_locale_name(locale_name)
    return locale_name

def normalize_locale_name(locale_name):
    """ Normalize local name.
    The all characters before under bar ("_") will be converted lower case
    and the others will be upper case if local_name contains under bar.
    If two or more under bars are contained in local_name,
    the first occurrence of under bar will be selected and then local_name
    will be converted following the above rule.
    If there are no under bars in local_name, the return value will be same as
    local_name.
    
    Argument:
    Locale Name -- Locale name to normalize.
    
    Return value:
    Normalized local name -- Contains under bar in local_name
    Local name as same as input -- Contains no under bar in local_name
    """
    if not isinstance(locale_name, basestring):
        return locale_name
    elif  not "_" in locale_name:
        return locale_name
    
    index = locale_name.find("_")
    before_under_bar = locale_name[:index].lower()
    after_under_bar = locale_name[index:].upper()

    return before_under_bar + after_under_bar
    
    
def get_user_phone_list_dir_path():
    """Get user phone list directory path.
    
    Return Value:
    Directory path -- Phone list directory path for user.
    """
    dir_path = os.path.expanduser(defs.PATH_DLST_HOME)
    return dir_path

