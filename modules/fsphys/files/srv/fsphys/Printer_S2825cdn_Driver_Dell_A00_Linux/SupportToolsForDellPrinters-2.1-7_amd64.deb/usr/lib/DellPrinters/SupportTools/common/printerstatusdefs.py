"""
  This file defines information using in printerstatus library.

  (C) Fuji Xerox Co., Ltd. 2010
 
  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:
  1. Redistributions of source code must retain the above copyright
     notice, this list of conditions and the following disclaimer.
  2. Redistributions in binary form must reproduce the above copyright
     notice, this list of conditions and the following disclaimer in the
     documentation and/or other materials provided with the distribution.
  3. Neither the name of Fuji Xerox Co., Ltd. nor the names of its
     contributors may be used to endorse or promote products derived from
     this software without specific prior written permission.
  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
  POSSIBILITY OF SUCH DAMAGE.
"""

KEY_STATUS_MODEL = 'model'
KEY_STATUS_STATUS = 'status'
KEY_STATUS_CONSOLE_LANG = 'console_lang'
KEY_STATUS_SERVICE_TAG = 'service_tag'
KEY_STATUS_CYAN_SIZE = 'cyan_toner_size'
KEY_STATUS_MAGENTA_SIZE = 'magenta_toner_size'
KEY_STATUS_YELLOW_SIZE = 'yellow_toner_size'
KEY_STATUS_BLACK_SIZE = 'black_toner_size'
KEY_STATUS_CYAN_REMAIN = 'cyan_toner_remain'
KEY_STATUS_MAGENTA_REMAIN = 'magenta_toner_remain'
KEY_STATUS_YELLOW_REMAIN = 'yellow_toner_remain'
KEY_STATUS_BLACK_REMAIN = 'black_toner_remain'

