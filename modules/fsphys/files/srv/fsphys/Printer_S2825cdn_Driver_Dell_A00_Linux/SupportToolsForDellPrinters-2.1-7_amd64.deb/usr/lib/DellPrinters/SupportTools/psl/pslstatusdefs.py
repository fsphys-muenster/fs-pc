"""
  This file defines status showed in PSL.

  (C) Fuji Xerox Co., Ltd. 2010

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:
  1. Redistributions of source code must retain the above copyright
     notice, this list of conditions and the following disclaimer.
  2. Redistributions in binary form must reproduce the above copyright
     notice, this list of conditions and the following disclaimer in the
     documentation and/or other materials provided with the distribution.
  3. Neither the name of Fuji Xerox Co., Ltd. nor the names of its
     contributors may be used to endorse or promote products derived from
     this software without specific prior written permission.
  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
  POSSIBILITY OF SUCH DAMAGE.
"""

try:
    import gettext
except:
    raise # Exception code is written in parent module.
_ = gettext.gettext


# pylint: disable-msg=C0301


# Status message showed in PSL.
MSG_PSL_PAPER_JAM = _('Paper Jam')
MSG_PSL_DOOR_OPEN = _('Door Open')
MSG_PSL_NO_TONER = _('No Toner')
MSG_PSL_OUT_OF_PAPER = _('Out Of Paper')
MSG_PSL_TONER_LOW = _('Toner Low')
MSG_PSL_PAPER_LOW = _('Paper Low')
MSG_PSL_OFFLINE = _('Offline')
MSG_PSL_READY = _('Ready')
MSG_PSL_UNKNOWN = _('Unknown')

# PSL status bit in printer status.
PSL_STATUS_BIT = 8
PRINTER_STATUS_BIT = 32


# Status message ID.
ID_MSG_PSL_PAPER_JAM = 0x1
ID_MSG_PSL_DOOR_OPEN = 0x2
ID_MSG_PSL_NO_TONER = 0x3
ID_MSG_PSL_OUT_OF_PAPER = 0x4
ID_MSG_PSL_TONER_LOW = 0x5
ID_MSG_PSL_PAPER_LOW = 0x6
ID_MSG_PSL_OFFLINE = 0x7
ID_MSG_PSL_READY = 0x8
ID_MSG_PSL_UNKNOWN = 0x9

# Status icon ID.
ID_ICON_GREEN = 0
ID_ICON_YELLOW = 1
ID_ICON_RED = 2


# Matching ID and status table.
PSL_STATUS_TABLE = {
    ID_MSG_PSL_PAPER_JAM: (MSG_PSL_PAPER_JAM, ID_ICON_RED),
    ID_MSG_PSL_DOOR_OPEN: (MSG_PSL_DOOR_OPEN, ID_ICON_RED),
    ID_MSG_PSL_NO_TONER: (MSG_PSL_NO_TONER, ID_ICON_RED),
    ID_MSG_PSL_OUT_OF_PAPER: (MSG_PSL_OUT_OF_PAPER, ID_ICON_RED),
    ID_MSG_PSL_TONER_LOW: (MSG_PSL_TONER_LOW, ID_ICON_YELLOW),
    ID_MSG_PSL_PAPER_LOW: (MSG_PSL_PAPER_LOW, ID_ICON_YELLOW),
    ID_MSG_PSL_OFFLINE: (MSG_PSL_OFFLINE, ID_ICON_YELLOW),
    ID_MSG_PSL_READY: (MSG_PSL_READY, ID_ICON_GREEN),
    ID_MSG_PSL_UNKNOWN: (MSG_PSL_UNKNOWN, ID_ICON_YELLOW)
}
# pylint: enable-msg=C0301


