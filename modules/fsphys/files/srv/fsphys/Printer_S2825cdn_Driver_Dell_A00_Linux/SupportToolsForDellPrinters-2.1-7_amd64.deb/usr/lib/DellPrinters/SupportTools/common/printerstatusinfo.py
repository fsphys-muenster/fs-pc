"""
  This class is used to managing the printer status information file.

  (C) Fuji Xerox Co., Ltd. 2010
 
  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:
  1. Redistributions of source code must retain the above copyright
     notice, this list of conditions and the following disclaimer.
  2. Redistributions in binary form must reproduce the above copyright
     notice, this list of conditions and the following disclaimer in the
     documentation and/or other materials provided with the distribution.
  3. Neither the name of Fuji Xerox Co., Ltd. nor the names of its
     contributors may be used to endorse or promote products derived from
     this software without specific prior written permission.
  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
  POSSIBILITY OF SUCH DAMAGE.
"""

try:
    import pickle
    import fcntl
    import os
    import errno
    
    from common import defs, checkchartype, printerstatusdefs, printermodellist
except:
    raise # Exception code is written in parent module.

# Printer status information names.
STATUS_INFO_ST = 'ST'
STATUS_INFO_MD = 'MD'
STATUS_INFO_LS = 'LS'
STATUS_INFO_LC = 'LC'
STATUS_INFO_DL = 'DL'
STATUS_INFO_KCMY = 'KCMY'
STATUS_INFO_KCMY2 = 'KCMY2'
STATUS_INFO_KCMY3 = 'KCMY3'
STATUS_INFO_KCMY4 = 'KCMY4'
STATUS_INFO_KTS = 'KTS'
STATUS_INFO_KTS2 = 'KTS2'
STATUS_INFO_KTS3 = 'KTS3'
STATUS_INFO_KTS4 = 'KTS4'
STATUS_INFO_KTL = 'KTL'
STATUS_INFO_KTL2 = 'KTL2'
STATUS_INFO_KTL3 = 'KTL3'
STATUS_INFO_KTL4 = 'KTL4'

KCMY_BLACK = '00'
KCMY_CYAN = '10'
KCMY_MAGENTA = '20'
KCMY_YELLOW = '30'

DL_ENGLISH = '0'
DL_FRENCH = '1'
DL_GERNAM = '2'
DL_ITALIAN = '3'
DL_SPANISH = '4'
DL_DANISH = '5'
DL_NORWEGIAN = '6'
DL_DUTCH = '7'
DL_SWEDISH = '8'
DL_FINNISH = '9'
DL_KATAKANA = '11'
DL_CZECH = '15'
DL_HUNGARIAN = '17'
DL_POLISH = '20'
DL_BRAZILILAN = '21'
DL_RUSSIAN = '22'
DL_TRULISH = '24'
DL_UNKNOWN = '99'

# Table printerstatus correspond to printerstatusinfo
PRN_STATUS_TO_PRN_STATUS_INFO = {
    printerstatusdefs.KEY_STATUS_SERVICE_TAG: STATUS_INFO_ST,
    printerstatusdefs.KEY_STATUS_MODEL: STATUS_INFO_MD,
    printerstatusdefs.KEY_STATUS_CONSOLE_LANG: STATUS_INFO_DL,
    printerstatusdefs.KEY_STATUS_BLACK_SIZE: STATUS_INFO_KTS,
    printerstatusdefs.KEY_STATUS_CYAN_SIZE: STATUS_INFO_KTS2,
    printerstatusdefs.KEY_STATUS_MAGENTA_SIZE: STATUS_INFO_KTS3,
    printerstatusdefs.KEY_STATUS_YELLOW_SIZE: STATUS_INFO_KTS4,
    printerstatusdefs.KEY_STATUS_BLACK_REMAIN: STATUS_INFO_KTL,
    printerstatusdefs.KEY_STATUS_CYAN_REMAIN: STATUS_INFO_KTL2,
    printerstatusdefs.KEY_STATUS_MAGENTA_REMAIN: STATUS_INFO_KTL3,
    printerstatusdefs.KEY_STATUS_YELLOW_REMAIN: STATUS_INFO_KTL4}

# Table printerstatus correspond to printerstatusinfo
BLK_PRN_STATUS_TO_PRN_STATUS_INFO = {
    printerstatusdefs.KEY_STATUS_SERVICE_TAG: STATUS_INFO_ST,
    printerstatusdefs.KEY_STATUS_MODEL: STATUS_INFO_MD,
    printerstatusdefs.KEY_STATUS_CONSOLE_LANG: STATUS_INFO_DL,
    printerstatusdefs.KEY_STATUS_BLACK_SIZE: STATUS_INFO_KTS,
    printerstatusdefs.KEY_STATUS_BLACK_REMAIN: STATUS_INFO_KTL}

# MIN and MAX length of each status table.
STATUS_LENGTH_FORM = {
    STATUS_INFO_ST: (0, 0),
    STATUS_INFO_MD: (1, 27),
    STATUS_INFO_LS: (0, 0),
    STATUS_INFO_LC: (0 ,0),
    STATUS_INFO_DL: (1, 2),
    STATUS_INFO_KCMY: (1, 2),
    STATUS_INFO_KCMY2: (1, 2),
    STATUS_INFO_KCMY3: (1, 2),
    STATUS_INFO_KCMY4: (1, 2),
    STATUS_INFO_KTS: (1, 6),
    STATUS_INFO_KTS2: (1, 6),
    STATUS_INFO_KTS3: (1, 6),
    STATUS_INFO_KTS4: (1, 6),
    STATUS_INFO_KTL: (1, 3),
    STATUS_INFO_KTL2: (1, 3),
    STATUS_INFO_KTL3: (1, 3),
    STATUS_INFO_KTL4: (1, 3)}

BLK_STATUS_LENGTH_FORM = {
    STATUS_INFO_ST: (0, 0),
    STATUS_INFO_MD: (1, 27),
    STATUS_INFO_LS: (0, 0),
    STATUS_INFO_LC: (0 ,0),
    STATUS_INFO_DL: (1, 2),
    STATUS_INFO_KCMY: (1, 2),  
    STATUS_INFO_KTS: (1, 6),
    STATUS_INFO_KTL: (1, 3)}

DL_VALUES = (
    DL_ENGLISH,
    DL_FRENCH,
    DL_GERNAM,
    DL_ITALIAN,
    DL_SPANISH,
    DL_DANISH,
    DL_NORWEGIAN,
    DL_DUTCH,
    DL_SWEDISH,
    DL_FINNISH,
    DL_KATAKANA,
    DL_CZECH,
    DL_HUNGARIAN,
    DL_POLISH,
    DL_BRAZILILAN,
    DL_RUSSIAN,
    DL_TRULISH,
    DL_UNKNOWN)

CMYK_VALUES = (
    KCMY_BLACK,
    KCMY_CYAN,
    KCMY_MAGENTA,
    KCMY_YELLOW)

def get_default_status_info():
    """Return printer status information list
    contain the default value.
    
    Return value:
    Status information list
    """
    status_info = {
        STATUS_INFO_ST:None, 
        STATUS_INFO_MD:None, 
        STATUS_INFO_LS:'Unknown', 
        STATUS_INFO_DL:DL_UNKNOWN, 
        STATUS_INFO_LC:None, 
        STATUS_INFO_KCMY:None, 
        STATUS_INFO_KCMY2:None, 
        STATUS_INFO_KCMY3:None, 
        STATUS_INFO_KCMY4:None, 
        STATUS_INFO_KTS:None, 
        STATUS_INFO_KTS2:None, 
        STATUS_INFO_KTS3:None, 
        STATUS_INFO_KTS4:None, 
        STATUS_INFO_KTL:None, 
        STATUS_INFO_KTL2:None, 
        STATUS_INFO_KTL3:None, 
        STATUS_INFO_KTL4:None}
    
    return status_info


class PrinterStatusInfo:
    """Manage the printer status information file."""
    
    def __init__(self):
        """Constructor of this class."""
        self.__status_info = get_default_status_info()

    def load_status_info_from_file(self, service_tag):
        """Load the printer status information from
        the status information file specified service tag.
        
        Argument:
        service_tag -- Number to specify status information file.
        
        Exceptions:
        IOError -- When failed to load the status information file.
        ValueError -- When the incorrect status is contained in the 
                      status information file.
        """
        status_info_temp = {}
        status_file_path = os.path.expanduser(defs.PATH_DLST_HOME + 
                                              defs.PREFIX_STATUS_INFO + 
                                              service_tag + 
                                              defs.POSTFIX_STATUS_INFO)
        status_file = None
        try:
            status_file = open(status_file_path, 'rb')
            fcntl.flock(status_file.fileno(), fcntl.LOCK_SH)
            status_info_temp = pickle.load(status_file)
        except IOError, error_val:
            if status_file:
                status_file.close()
                
            if error_val[0] != errno.ENOENT:  # Other than File not found.
                raise
            else:
                self.__status_info = get_default_status_info()
                
                self.set_status_info_by_name(STATUS_INFO_ST, service_tag)
                return
        except:
            if status_file:
                status_file.close()
            raise
        else:
            if status_file:
                status_file.close()
        
        for status_name in status_info_temp.keys():
            self.__is_supported_status_info_form(
                                    status_name, 
                                    status_info_temp[status_name])
        
        self.__status_info = status_info_temp
        
    def set_status_info_by_name(self, info_name, info_value):
        """Set the status information value to the specified status.
        
        Arguments:
        info_name -- The status name which value is set.
        info_value -- The status value to set.
        
        Exception:
        ValueError -- Failed to set the value.
        """
        self.__is_supported_status_info_form(info_name,  info_value)
        self.__status_info[info_name] = info_value
        
    def __is_supported_status_info_form(self,   # pylint: disable-msg=R0201
                                        info_name, 
                                        info_value): 
        """Check the format of the status information.
        Permitted characters are depend on info_name.
        
        Arguments:
        info_name -- The status name of format to check value.
        info_value -- The status value to check.
        
        Exception:
        ValueError -- If incorrect format.
        """
        alnum_name_group = [STATUS_INFO_ST, \
                            STATUS_INFO_MD, 
                            STATUS_INFO_LS]
        
	num_name_group = [STATUS_INFO_KTS, STATUS_INFO_KTS2, 
                         STATUS_INFO_KTS3, STATUS_INFO_KTS4, 
                         STATUS_INFO_KTL, STATUS_INFO_KTL2, 
                         STATUS_INFO_KTL3, STATUS_INFO_KTL4]
       	cmyk_group = [STATUS_INFO_KCMY, STATUS_INFO_KCMY2, 
                      	STATUS_INFO_KCMY3, STATUS_INFO_KCMY4]
        all_name_group = alnum_name_group + num_name_group + cmyk_group + \
                         [STATUS_INFO_LC] + [STATUS_INFO_DL]

        supported_name = False
        
        if info_name in all_name_group:
            supported_name = True
            
        if supported_name:
            if info_value is None:
                return
            elif info_value == "":
                raise ValueError
        
        if info_name in alnum_name_group:
            checkchartype.check_alphanumeric(info_value)
            self.__is_supported_length(info_name, info_value)
            return
                
        if info_name in num_name_group:
            if info_value.isdigit():
                self.__is_supported_length(info_name, info_value)
                return
            
        if info_name in cmyk_group:
            if info_value in CMYK_VALUES:
                return
            
        if info_name == STATUS_INFO_DL:
            if info_value in DL_VALUES:
                return
                
        if info_name == STATUS_INFO_LC:
            checkchartype.check_hex(info_value)
            return
                    
        raise ValueError
    
    def __is_supported_length(self,     # pylint: disable-msg=R0201
                              info_name, 
                              info_value):
        """Check the length of the status information.
        Permitted length are depend on info_name.
        
        Arguments:
        info_name -- The status name of format to check value.
        info_value -- The status value to check.
        
        Exception:
        ValueError -- If incorrect format.
        """
        min_length, max_length = STATUS_LENGTH_FORM[info_name]
        
        # If min and max is 0, not need check.
        if (min_length == 0 and max_length == 0):
            return

        if (min_length <= len(info_value) and 
            len(info_value) <= max_length):
            return
        
        raise ValueError
        
    def get_status_info(self):
        """Get the status information dictionary array.
        
        Return value:
        Status information array -- Contain the all status informations
                                    as dictionary.
        """
        return self.__status_info
        
    def save_status_info(self):
        """Save the status information to the status information file.
        Status information file's name is decided by ST value.
        Status information file is saved in pickle format.
        
        Exceptions:
        IOError -- When failed to save the status information file.
        ValueError -- When ST value in __status_info is invalid.
        """
        service_tag = self.__status_info[STATUS_INFO_ST]
        if not service_tag:
            raise ValueError
        
        status_file_path = os.path.expanduser(defs.PATH_DLST_HOME + 
                                              defs.PREFIX_STATUS_INFO + 
                                              service_tag + 
                                              defs.POSTFIX_STATUS_INFO)
        status_file = None
        status_file_lock = None
        try:
            # Open file with mode 'a' for get file lock before mode 'w'
            status_file_lock = open(status_file_path, 'a')
            fcntl.flock(status_file_lock.fileno(), fcntl.LOCK_EX)
            status_file = open(status_file_path, 'wb')
            pickle.dump(self.__status_info, status_file)
            os.chmod(status_file_path, defs.MOD_DLST_HOME_FILE)
        finally:
            if status_file:
                status_file.close()
            if status_file_lock:
                status_file_lock.close()
        
    def load_status_info_from_commandline(self, params):
        """Load the printer status information from
        the command line parameter.
        
        Argument:
        params -- command line parameters contain status informations.
        
        Exceptions:
        ValueError -- When the incorrect status is contained in the 
                      command line parameters, or
                      printer model number is specified.
        """
        for param in params:
            name_value = param.split('=')
            # If name and value is separated correctly, 2 values returned.
            if len(name_value) != 2:
                raise ValueError
            
            self.set_status_info_by_name(name_value[0],
                                         name_value[1])
            
        # If 'MD' is None, parameter is incorrect.
        model_number = self.__status_info[STATUS_INFO_MD]
        if not model_number:
            raise ValueError
            
    def get_service_tag(self):
        """Get service tag number from __status_info.
        
        Return Value:
        Service tag number
        """
        return self.__status_info[STATUS_INFO_ST]
    
    def set_service_tag(self, service_tag):
        """Set model_number into __status_info
        
        Argument:
        service_tag -- Service tag number
        """
        self.__is_supported_status_info_form(STATUS_INFO_ST, service_tag)
        self.__status_info[STATUS_INFO_ST] = service_tag
    
    def get_printer_model_number(self):
        """Get printer model number from __status_info.
        
        Return Value:
        Printer Model number
        """
        return self.__status_info[STATUS_INFO_MD]
    
    def set_printer_model_number(self, model_number):
        """Set model_number into __status_info
        
        Argument:
        model_number -- Printer model number
        """
        self.__is_supported_status_info_form(STATUS_INFO_MD, model_number)
        self.__status_info[STATUS_INFO_MD] = model_number
        
    def load_status_info_from_printer_status(self, printer_status, color_device):
        """Load the printer status information from
        the printer status dictionary.
        If incorrect status contained, skip setting the status,
        and set the correct statuses only.
        
        Argument:
        printer_status -- Printer status dictionary get from 
                          printerstatus module.
        
        Exception:
        ValueError -- When printer_status is None, or not dictionary.
        """
        if not printer_status:
            raise ValueError
        
        if not isinstance(printer_status, dict):
            raise ValueError
        
        # Set KCMY color id
	if (color_device == 'True'):
            self.set_status_info_by_name(STATUS_INFO_KCMY, KCMY_BLACK)
            self.set_status_info_by_name(STATUS_INFO_KCMY2, KCMY_CYAN)
            self.set_status_info_by_name(STATUS_INFO_KCMY3, KCMY_MAGENTA)
            self.set_status_info_by_name(STATUS_INFO_KCMY4, KCMY_YELLOW)
        
            # Set each status from printer status.
            for key in PRN_STATUS_TO_PRN_STATUS_INFO.keys():
                if printer_status.has_key(key):
                    # Get model number for MD
                    if key == printerstatusdefs.KEY_STATUS_MODEL:
                        prn_model_list = printermodellist.PrinterModelList()
                        val = prn_model_list.get_model_number_from_device_name(
                                printer_status[key])
                    else:
                        val = printer_status[key]
                    
                    try:
                        if val is None:     # If value is None, set as it is.
                            self.set_status_info_by_name(
                                PRN_STATUS_TO_PRN_STATUS_INFO[key], 
                                val)
                        else:           # Cast value to string.
                            self.set_status_info_by_name(
                                PRN_STATUS_TO_PRN_STATUS_INFO[key], 
                                str(val))
                    except ValueError:
                        # if value is incorrect, skip setting it.
                        pass
        else:
	    self.set_status_info_by_name(STATUS_INFO_KCMY, KCMY_BLACK)                
            # Set each status from printer status.
            for key in BLK_PRN_STATUS_TO_PRN_STATUS_INFO.keys():
                if printer_status.has_key(key):
                    # Get model number for MD
                    if key == printerstatusdefs.KEY_STATUS_MODEL:
                        prn_model_list = printermodellist.PrinterModelList()
                        val = prn_model_list.get_model_number_from_device_name(
                                printer_status[key])
                    else:
                        val = printer_status[key]
                    
                    try:
                        if val is None:     # If value is None, set as it is.
                            self.set_status_info_by_name(
                                BLK_PRN_STATUS_TO_PRN_STATUS_INFO[key], 
                                val)
                        else:           # Cast value to string.
                            self.set_status_info_by_name(
                                BLK_PRN_STATUS_TO_PRN_STATUS_INFO[key], 
                                str(val))
                    except ValueError:
                        # if value is incorrect, skip setting it.
                        pass
                   
    def make_command_line_params(self):
        """ Make command line params from status.
        Status which value is None isn't appended in command line params.
        
        Return Value:
        command_params -- list type.
        
        """
        command_params = []
        
        for key in self.__status_info.keys():
            val = self.__status_info[key]
            if val is None:
                continue
            command = key + '=' + val
            command_params.append(command)
        return command_params
                
