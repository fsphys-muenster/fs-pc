"""
  This class is used to show printer status window.

  (C) Fuji Xerox Co., Ltd. 2014
 
  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:
  1. Redistributions of source code must retain the above copyright
     notice, this list of conditions and the following disclaimer.
  2. Redistributions in binary form must reproduce the above copyright
     notice, this list of conditions and the following disclaimer in the
     documentation and/or other materials provided with the distribution.
  3. Neither the name of Fuji Xerox Co., Ltd. nor the names of its
     contributors may be used to endorse or promote products derived from
     this software without specific prior written permission.
  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
  POSSIBILITY OF SUCH DAMAGE.
"""

try:
    import os
    import thread
    import gtk
    import gtk.glade
    import pygtk
    pygtk.require("2.0")
    
    from common import defs, msgdlg, printerstatusinfo, printerstatusdefs
    from common.defs import PATH_DLST_RESOURCE
    from psw import pswmessage, pswstatusdefs
    from psl import psldefs
except:
    raise  # Exception code is written in parent module.

FILE_GLADE = 'pswdialog.glade'
FILE_ICON_48x48 = 'dlpsw_icon_dlpsw_48x48_32.png'
FILE_ICON_16x16 = 'dlpsw_icon_dlpsw_16x16_32.png'

TONER_RANGE_OVER_30 = 3
TONER_RANGE_1_TO_29 = 2
TONER_RANGE_0 = 1
TONER_RANGE_UNKNOWN = -1

TONER_IMAGE = 'Toner_%s_%03d.bmp'
TONER_UNKNOWN_IMAGE = 'Toner_Unk.bmp'
CHAIN_LINK = '%03d-%03d'

TONER_STATE_IMAGE_GREEN = 'psw_image_green.png'
TONER_STATE_IMAGE_YELLOW = 'psw_image_yellow.png'
TONER_STATE_IMAGE_RED = 'psw_image_red.png'
TONER_STATE_IMAGE_UNKNOWN = 'psw_image_unk.png'

class PSWDialog: # pylint: disable-msg=R0902, R0903
    """ Show the printer status window """
    
    def __init__(self, printer_name, color_device, polling_thread):
        """ Show the printer status window.
        
        Arguments:
        printer_name -- Printer name from printer list.
        polling -- Instance of PollingThread class.
        
        """
        self.__status_info = None
        self.__printer_name = printer_name
	self.__color_device = color_device
        self.__printer_id = None
        self.__polling_thread = polling_thread
        self.__printer_status_info = printerstatusinfo.PrinterStatusInfo()
        self.__unknown_toner_file = (PATH_DLST_RESOURCE + TONER_UNKNOWN_IMAGE)
        self.__unknown_toner_state_file = (PATH_DLST_RESOURCE + 
                                           TONER_STATE_IMAGE_UNKNOWN)
        self.__color = None
        
        # Display the PSWdialog.
       	glade = PATH_DLST_RESOURCE + FILE_GLADE
        
	self.__widget_tree = gtk.glade.XML(glade)
        self.__windowPrinterStatus = self.__widget_tree.get_widget(
                                                    'windowPrinterStatus')

	self.__frameToner = self.__widget_tree.get_widget('frameToner')

        self.__labelPrinterStatusMessage = self.__widget_tree.get_widget(
                                                'labelPrinterStatusMessage')
        self.__buttonRefresh = self.__widget_tree.get_widget('buttonRefresh')
        self.__buttonClose = self.__widget_tree.get_widget('buttonClose')
        self.__buttonOrderOnline = self.__widget_tree.get_widget(
                                                        'buttonOrderOnline')
        self.__imageTonerBlack = self.__widget_tree.get_widget(
                                                        'imageTonerBlack')
        self.__imageTonerCyan = self.__widget_tree.get_widget(
                                                        'imageTonerCyan')
        self.__imageTonerMagenta = self.__widget_tree.get_widget(
                                                        'imageTonerMagenta')
        self.__imageTonerYellow = self.__widget_tree.get_widget(
                                                        'imageTonerYellow')

        self.__labelTonerAlert = self.__widget_tree.get_widget(
                                                        'labelTonerAlert')
        self.__imageBrowser = self.__widget_tree.get_widget(
                                                        'imageBrowser')
        self.__labelOrderOnline = self.__widget_tree.get_widget(
                                                        'labelOrderOnline')
        self.__hseparatorOrderOnline = self.__widget_tree.get_widget(
                                                    'hseparatorOrderOnline')
        
	self.__imageTonerBlackState = self.__widget_tree.get_widget(
                                                    'imageTonerBlackState')
	
	self.__imageTonerCyanState = self.__widget_tree.get_widget(
                                                    'imageTonerCyanState')
        self.__imageTonerMagentaState = self.__widget_tree.get_widget(
                                                'imageTonerMagentaState')
        self.__imageTonerYellowState = self.__widget_tree.get_widget(
                                                'imageTonerYellowState')

	self.__labelTonerBlack = self.__widget_tree.get_widget(
                                                    'labelTonerBlack')
	self.__labelTonerCyan = self.__widget_tree.get_widget(
                                                    'labelTonerCyan')
        self.__labelTonerMagenta = self.__widget_tree.get_widget(
                                                    'labelTonerMagenta')
        self.__labelTonerYellow = self.__widget_tree.get_widget(
                                                    'labelTonerYellow')
        # Create instance of message box class.
        self.__err_dlg = msgdlg.MsgDialog(
                            pswmessage.MSG_PSW_TITLE_ERR_DLG,
                            PATH_DLST_RESOURCE + FILE_ICON_16x16,
                            PATH_DLST_RESOURCE + FILE_ICON_48x48,
                            self.__windowPrinterStatus)        
        
        self.__windowPrinterStatus.set_icon_list(
            gtk.gdk.pixbuf_new_from_file(PATH_DLST_RESOURCE + 
                                         FILE_ICON_16x16),
            gtk.gdk.pixbuf_new_from_file(PATH_DLST_RESOURCE + 
                                         FILE_ICON_48x48))
        
        self.__windowPrinterStatus.modify_bg(
                             gtk.STATE_NORMAL, gtk.gdk.color_parse('white'))
        
        self.__windowPrinterStatus.set_title(pswmessage.MSG_PSW_TITLE_BAR %
                                             printer_name)
        
        # Initialize setting
        self.__labelPrinterStatusMessage.set_text(
                                    pswstatusdefs.MSG_PSW_GETTINGINFO)
	if (color_device == 'False'): 
		self.__imageTonerCyan.hide()
		self.__imageTonerMagenta.hide()
		self.__imageTonerYellow.hide()
		self.__imageTonerCyanState.hide()
		self.__imageTonerMagentaState.hide()
		self.__imageTonerYellowState.hide()
		self.__labelTonerCyan.hide()
		self.__labelTonerMagenta.hide()
		self.__labelTonerYellow.hide()
		self.__frameToner.set_property("height_request", 80)

	self.__set_unknown_toner_remain_images()
        self.__set_unknown_toner_state_images()
        self.__buttonOrderOnline.hide()
        self.__labelOrderOnline.hide()
        self.__imageBrowser.hide()
        self.__hseparatorOrderOnline.hide()
        self.__set_updating_status()
        self.__buttonClose.grab_focus()
        
        event_dic = {
            "on_windowPrinterStatus_destroy": 
                                self.__on_windowPrinterStatus_destroy,
            "on_windowPrinterStatus_key_press_event": 
                                self.__on_windowPrinterStatus_key_press_event,
            "on_buttonOrderOnline_clicked": 
                                    self.__on_buttonOrderOnline_clicked,
            "on_buttonRefresh_clicked": self.__on_buttonRefresh_clicked,
            "on_buttonClose_clicked": self.__on_buttonClose_clicked}
        self.__widget_tree.signal_autoconnect(event_dic)
        
        gtk.main()
        
    def __on_buttonClose_clicked(self, button): # pylint: disable-msg=W0613
        """ Close printer status window when close button clicked.
        
        Argument:
        button -- instance of buttonClose
        """
        self.__windowPrinterStatus.destroy()
    
    def __on_windowPrinterStatus_key_press_event(   # pylint: disable-msg=W0613
                            self, widget, event):
        """ Close printer status window when Esc-key clicked.
        And refresh printer status when F5-key clicked.
        
        Arguments:
        widget -- The widget that received the key_press_event.
        event -- The event triggered that the key_press_event.
        
        """
        if event.keyval == defs.KEY_CODE_ESC:
            self.__windowPrinterStatus.destroy()
            
        if event.keyval == defs.KEY_CODE_F5:
            self.__set_updating_status()
            
    def __on_windowPrinterStatus_destroy(   # pylint: disable-msg=W0613
                               self, window):
        """ Close printer status window 
        when [x] button and [Alt]+[F4] key clicked.
        And delete polling thread.
            
        Arguments:
        window -- the window that received the destroy.
        
        """
        self.__polling_thread.del_psw_info()
        gtk.main_quit()
            
    def __set_updating_status(self):
        """ Refresh printer status. """
        self.__buttonRefresh.set_sensitive(False)
        self.__polling_thread.set_psw_refresh_flag(self.__printer_name, 
                                            self.__update_status)
        
    def __on_buttonRefresh_clicked(self, button): # pylint: disable-msg=W0613
        """ Refresh printer status when Refresh button clicked.
        
        Argument:
        button -- instance of buttonRefresh.
        
        """
        self.__set_updating_status()
    
    def __open_order_site_thread(self):
        """Open order site using SMS.
        This thread waits exiting SMS.
        And It automatically quits after exiting SMS.
        
        """
        if (self.__printer_id is None or 
            not isinstance(self.__printer_id, basestring)):
            gtk.gdk.threads_enter()
            self.__err_dlg.show_error_dialog(
                            pswmessage.MSG_PSW_START_WEB_FAILE)
            gtk.gdk.threads_leave()
            return
        
        command_params = self.__printer_status_info.make_command_line_params()
        printer_id_param = defs.PARAM_PRINTER_ID + '=' + self.__printer_id
        command_line = [defs.PATH_DLST_BIN_SMS] + [printer_id_param] + \
                            command_params
        exit_code = os.spawnv(os.P_WAIT, defs.PATH_DLST_BIN_SMS, command_line)
        if exit_code != 0:
            gtk.gdk.threads_enter()
            self.__err_dlg.show_error_dialog(
                            pswmessage.MSG_PSW_START_WEB_FAILE)
            gtk.gdk.threads_leave()
        
    def __on_buttonOrderOnline_clicked(self,    # pylint: disable-msg=W0613
                                       button):
        """ Open order supplies online browser.
        
        Argument:
        button -- instance of buttonOrderOnline.
        
        """
        try:
            del self.__printer_status_info
            self.__printer_status_info = printerstatusinfo.PrinterStatusInfo()
            self.__printer_status_info.load_status_info_from_printer_status(
                                                        self.__status_info, self.__color_device)
        except ValueError:
            self.__err_dlg.show_error_dialog(
                                        pswmessage.MSG_PSW_START_WEB_FAILE)
            return
        
        args = ()
        thread.start_new_thread(self.__open_order_site_thread, args)
        
    def __update_status(self, info):
        """ Change printer status. 
        
        Argument:
        info -- Dictionary printer status information.
        
        """
        if info[psldefs.KEY_INFO_NAME] == self.__printer_name:
            self.__status_info = info[psldefs.KEY_INFO_STATUS]
            if self.__status_info is None:
                self.__labelPrinterStatusMessage.set_text(
                                            pswstatusdefs.MSG_PSW_NOGETINFO)
                self.__set_unknown_toner_remain_images()
                self.__set_unknown_toner_state_images()
            else:
                self.__set_printer_status_text()
                self.__set_toner_image()
                self.__set_toner_state_image()
            self.__printer_id = info[psldefs.KEY_INFO_PRINTER_ID]
            self.__set_alert_text()
            self.__change_order_guidance()
            self.__buttonRefresh.set_sensitive(True)
        
    def __set_printer_status_text(self):
        """ Indicate printer status. """
        try:
            printer_status = \
                self.__status_info[printerstatusdefs.KEY_STATUS_STATUS]
            status_message = pswstatusdefs.PSW_STATUS_TABLE[printer_status]
        except KeyError:
            status_message = pswstatusdefs.MSG_PSW_ST

        self.__labelPrinterStatusMessage.set_text(status_message)
        
    def __set_toner_image(self):
        """ Set toner remain image. """
        # level_list is decide on range of toner image.
        level_list = range(100, -1, -10)
        if (self.__color_device == 'True'): 
		color_list = ['C', 'M', 'Y', 'K']
        	toner_remain = \
        	{'C': self.__status_info[printerstatusdefs.KEY_STATUS_CYAN_REMAIN],
         	 'M': self.__status_info[printerstatusdefs.KEY_STATUS_MAGENTA_REMAIN],
         	 'Y': self.__status_info[printerstatusdefs.KEY_STATUS_YELLOW_REMAIN],
         	 'K': self.__status_info[printerstatusdefs.KEY_STATUS_BLACK_REMAIN]}
        else:
		color_list = ['K']
        	toner_remain = \
        	{ 'K': self.__status_info[printerstatusdefs.KEY_STATUS_BLACK_REMAIN]}

        # Check toner remain and select toner image correspond to toner level.
        for self.__color in color_list:
            remain = toner_remain[self.__color]
            if 0 <= remain <= 100:
                for level in level_list:
                    if remain >= level:
                        remain_file = PATH_DLST_RESOURCE + (
                                    TONER_IMAGE % (self.__color, level))
                        self.__set_toner_image_on_ui(remain_file)
                        break
            else:
                self.__unknown_toner_file = (PATH_DLST_RESOURCE
                                          + TONER_UNKNOWN_IMAGE)
                self.__set_toner_image_on_ui(self.__unknown_toner_file)
                
    def __set_toner_image_on_ui(self, image_file):
        """ Set toner image on UI. 
        
        Argument:
        image_file -- Toner image bitmap file.
        
        """
	if (self.__color_device == 'True'): 
            	if self.__color == 'C':
            		self.__imageTonerCyan.set_from_file(image_file)
            	elif self.__color == 'M':
                	self.__imageTonerMagenta.set_from_file(image_file)
            	elif self.__color == 'Y':
                	self.__imageTonerYellow.set_from_file(image_file)
            	elif self.__color == 'K':
                	self.__imageTonerBlack.set_from_file(image_file)
        else:
        	if self.__color == 'K':
                	self.__imageTonerBlack.set_from_file(image_file)

    def __set_toner_state_image(self):
        """ Set toner state images. """
        if (self.__color_device == 'True'): 
            	color_list = ['C', 'M', 'Y', 'K']
            	toner_remain = \
            	{'C': self.__status_info[printerstatusdefs.KEY_STATUS_CYAN_REMAIN],
             	 'M': self.__status_info[printerstatusdefs.KEY_STATUS_MAGENTA_REMAIN],
             	 'Y': self.__status_info[printerstatusdefs.KEY_STATUS_YELLOW_REMAIN],
             	 'K': self.__status_info[printerstatusdefs.KEY_STATUS_BLACK_REMAIN]}
        else:
		color_list = ['K']
		toner_remain = \
            	{'K': self.__status_info[printerstatusdefs.KEY_STATUS_BLACK_REMAIN]}        
        
        if self.__status_info is None:
            for self.__color in color_list:
                self.__set_toner_state_image_on_ui(PATH_DLST_RESOURCE + 
                                                   TONER_STATE_IMAGE_UNKNOWN)
                return
        
        for self.__color in color_list:
            remain = toner_remain[self.__color]
            if remain > 100:
                self.__set_toner_state_image_on_ui(PATH_DLST_RESOURCE + 
                                                   TONER_STATE_IMAGE_UNKNOWN)
            elif remain >= 30:
                self.__set_toner_state_image_on_ui(PATH_DLST_RESOURCE + 
                                                   TONER_STATE_IMAGE_GREEN)
            elif remain >= 10:
                self.__set_toner_state_image_on_ui(PATH_DLST_RESOURCE + 
                                                   TONER_STATE_IMAGE_YELLOW)
            elif remain >= 0:
                self.__set_toner_state_image_on_ui(PATH_DLST_RESOURCE + 
                                                   TONER_STATE_IMAGE_RED)
            else:
                self.__set_toner_state_image_on_ui(PATH_DLST_RESOURCE + 
                                                   TONER_STATE_IMAGE_UNKNOWN)
        
    def __set_toner_state_image_on_ui(self, image_file):
        """ Set toner state image on UI.
        
        Argument:
        image_file -- Toner state image file.
        """
	if (self.__color_device == 'True'):
        	if self.__color == 'C':
            		self.__imageTonerCyanState.set_from_file(image_file)
        	elif self.__color == 'M':
            		self.__imageTonerMagentaState.set_from_file(image_file)
        	elif self.__color == 'Y':
            		self.__imageTonerYellowState.set_from_file(image_file)
        	elif self.__color == 'K':
            		self.__imageTonerBlackState.set_from_file(image_file)
	else:
		if self.__color == 'K':
            		self.__imageTonerBlackState.set_from_file(image_file)
        
    def __set_unknown_toner_remain_images(self):
        """ Set unknown toner image. """
 	if (self.__color_device == 'True'): 
		self.__imageTonerCyan.set_from_file(self.__unknown_toner_file)
        	self.__imageTonerMagenta.set_from_file(self.__unknown_toner_file)
        	self.__imageTonerYellow.set_from_file(self.__unknown_toner_file)
        	self.__imageTonerBlack.set_from_file(self.__unknown_toner_file)
	else:
		self.__imageTonerBlack.set_from_file(self.__unknown_toner_file)
        
    def __set_unknown_toner_state_images(self):
        """Set unknown toner state images"""
	if (self.__color_device == 'True'):
        	self.__imageTonerCyanState.set_from_file(
            		self.__unknown_toner_state_file)
        	self.__imageTonerMagentaState.set_from_file(
            		self.__unknown_toner_state_file)
        	self.__imageTonerYellowState.set_from_file(
            		self.__unknown_toner_state_file)
        	self.__imageTonerBlackState.set_from_file(
            		self.__unknown_toner_state_file)
	else:
		self.__imageTonerBlackState.set_from_file(
            		self.__unknown_toner_state_file)	
        
    def __get_toner_range(self):
        """ Get minimum range of toner remain. 
        
        Return value:
        TONER_RANGE_OVER_30 -- All toner remain is over 30%.
        TONER_RANGE_1_TO_29 -- Any toner remain is 1 to 29%.
        TONER_RANGE_0 -- Any toner remain is 0%.
        TONER_RANGE_UNKNOWN -- All toner remain is unknown.
        
        """
        if self.__status_info is None:
            return TONER_RANGE_UNKNOWN
        
	if (self.__color_device == 'True'):
        	toner_remain = \
          		[self.__status_info[printerstatusdefs.KEY_STATUS_CYAN_REMAIN],
           		 self.__status_info[printerstatusdefs.KEY_STATUS_MAGENTA_REMAIN],
           		 self.__status_info[printerstatusdefs.KEY_STATUS_YELLOW_REMAIN],
           		 self.__status_info[printerstatusdefs.KEY_STATUS_BLACK_REMAIN]]
	else:
        	toner_remain = \
          		[self.__status_info[printerstatusdefs.KEY_STATUS_BLACK_REMAIN]]
       
        ret = None
        toner_unknown = True
        
        for remain in toner_remain:
            if remain >= 30:
                toner_range = TONER_RANGE_OVER_30
                toner_unknown = False
            elif remain >= 1:
                toner_range = TONER_RANGE_1_TO_29
                toner_unknown = False
            elif remain == 0:
                ret = TONER_RANGE_0
                toner_unknown = False
                break
            else:
                continue # Toner remain unknown.
            
            if (ret is None or toner_range < ret):
                ret = toner_range
                         
        if toner_unknown: # All toner remain unknown.
            ret = TONER_RANGE_UNKNOWN
            
        return ret
        
    def __set_alert_text(self):
        """ Set toner alert text. """
        alert_toner_range = self.__get_toner_range()
        
        if alert_toner_range == TONER_RANGE_0:
            self.__labelTonerAlert.set_markup(
                            pswmessage.MSG_PSW_ALERT_NO_TONER_REMAIN)
        elif alert_toner_range == TONER_RANGE_1_TO_29:
            self.__labelTonerAlert.set_markup(
                            pswmessage.MSG_PSW_ALERT_LOW_TONER_REMAIN)
        else:
            self.__labelTonerAlert.set_text('')
                    
    def __change_order_guidance(self):
        """ Change indication for order guidance area. """
        order_toner_range = self.__get_toner_range()
        
        if (order_toner_range == TONER_RANGE_1_TO_29
            or order_toner_range == TONER_RANGE_0):
            self.__buttonOrderOnline.show()
            self.__labelOrderOnline.show()
            self.__imageBrowser.show()
            self.__hseparatorOrderOnline.show()
        else:
            if self.__buttonOrderOnline.is_focus():
                self.__buttonRefresh.grab_focus()
            self.__buttonOrderOnline.hide()
            self.__labelOrderOnline.hide()
            self.__imageBrowser.hide()
            self.__hseparatorOrderOnline.hide()
        
