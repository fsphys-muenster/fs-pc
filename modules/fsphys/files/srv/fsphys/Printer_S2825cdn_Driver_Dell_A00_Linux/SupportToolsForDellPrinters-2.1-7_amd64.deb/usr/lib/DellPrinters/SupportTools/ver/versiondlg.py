"""
  This class is to show version dialog.

  (C) Fuji Xerox Co., Ltd. 2010
 
  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:
  1. Redistributions of source code must retain the above copyright
     notice, this list of conditions and the following disclaimer.
  2. Redistributions in binary form must reproduce the above copyright
     notice, this list of conditions and the following disclaimer in the
     documentation and/or other materials provided with the distribution.
  3. Neither the name of Fuji Xerox Co., Ltd. nor the names of its
     contributors may be used to endorse or promote products derived from
     this software without specific prior written permission.
  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
  POSSIBILITY OF SUCH DAMAGE.
"""

try:
    import gtk
    import gtk.glade

    import common.defs
    from common.defs import PATH_DLST_RESOURCE
    from common import preventsamewindow
except:
    raise # Exception code is written in parent module.

class VersionDlg(preventsamewindow.PreventSameWindow):
    """Class for showing version dialog."""
    
    WINDOW_ATOM_NAME_OF_VERDLG =  'SupportToolsForDellPrinters_ver_VersionDlg'
    
    def __init__(self):
        """Show version dialog."""
        preventsamewindow.PreventSameWindow.__init__(self)
        
        # Check if this program is already running.
        self.set_window_atom_name(self.WINDOW_ATOM_NAME_OF_VERDLG)
        if self.is_existing():
            self.move_forward()
            return

        # Create dialog.
        self.glade = PATH_DLST_RESOURCE + 'versiondlg.glade'
        self.widget_tree = gtk.glade.XML(self.glade)
        self.windowMain = self.widget_tree.get_widget('windowMain')
        self.windowMain.realize()
        self.register_window_atom(self.windowMain.window.xid)

        self.windowMain.set_icon_list(
            gtk.gdk.pixbuf_new_from_file(PATH_DLST_RESOURCE + 
                                         'dlver_icon_dlver_16x16_32.png'),
            gtk.gdk.pixbuf_new_from_file(PATH_DLST_RESOURCE + 
                                         'dlver_icon_dlver_48x48_32.png'))
       
        self.event_dic = {"on_windowMain_destroy": self.quit,
                          "on_buttonOK_clicked": self.quit,
                          "on_windowMain_key_press_event": self.esckey_press}
        self.widget_tree.signal_autoconnect(self.event_dic)
        gtk.main()
        
    def quit(self, widget):  # pylint: disable-msg=W0613
        """Quit version dialog.
        
        Argument:
        widget -- a object of windowMain
        
        """
        self.delete_window_atom()
        gtk.main_quit()

    def esckey_press(self, widget, event):
        """Quit version dialog when esc-key is pressed.
        
        Arguments:
        widget -- a object of windowMain
        event -- a event object of on_windowMain_key_press_event
        
        """
        if event.keyval == common.defs.KEY_CODE_ESC:
            self.quit(widget)
