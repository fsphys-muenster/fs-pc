"""
  This file defines messages used by supplies management system.

  (C) Fuji Xerox Co., Ltd. 2010-2012
 
  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:
  1. Redistributions of source code must retain the above copyright
     notice, this list of conditions and the following disclaimer.
  2. Redistributions in binary form must reproduce the above copyright
     notice, this list of conditions and the following disclaimer in the
     documentation and/or other materials provided with the distribution.
  3. Neither the name of Fuji Xerox Co., Ltd. nor the names of its
     contributors may be used to endorse or promote products derived from
     this software without specific prior written permission.
  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
  POSSIBILITY OF SUCH DAMAGE.
"""
try:
    import gettext
except:
    raise # Exception code is written in parent module.

_ = gettext.gettext

# Define messages used by SMS.
# pylint: disable-msg=C0301
MSG_SMS_TITLE_ERR_DLG = _('Dell Supplies Management System')
MSG_SMS_SERVICETAG_INCORRECT = _('Invalid characters in Service Tag. Enter up to 7 alphanumeric characters.')
MSG_SMS_URL_SAVE_FAIL = _('Failed to save the selected Reorder URL.')
MSG_SMS_STATUS_INCORRECT = _('Incorrect status information.')
MSG_SMS_STATUS_LOAD_FAIL = _('Failed to get printer supplies information.')
MSG_SMS_BROWSE_FAIL = _('The Web browser did not start. Make sure the default Web browser is properly installed.')
MSG_SMS_START_FAIL = _('Dell Supplies Management System did not start.')
MSG_SMS_LOAD_SETTING_FAIL = _('Failed to read the setting file.')

MGS_SMS_SAVE_UPDATEED_DATE_FAIL = _('Failed to save the updated date of phone number list.')
MGS_SMS_SAVE_UPDATE_FLAG_FAIL = _('Failed to save the setting for update of phone number list.')
MGS_SMS_UPDATED_PHONE_NUMBER_INFO = _('The currently selected phone contacts have been updated.')

MSG_SMS_NOTIFY_NOW_UPDATING = _('Updating phone contacts.')
MSG_SMS_NOTIFY_SUCCESS_IN_UPDATE = _('Updating of phone contacts completed.')
MSG_SMS_NOTIFY_FAILED_TO_CONNECT = _('Failed to connect to server.')
MSG_SMS_NOTIFY_FAILED_TO_DOWNLOAD = _('Failed to update. Phone number list file might not be downloaded from the server correctly.')
MSG_SMS_NOTIFY_FAILED_TO_UPDATE = _('Updating of phone contacts failed.')
MSG_SMS_NOTIFY_NO_UPDATE = _('Updating of phone contacts unnecessary.')
# pylint: enable-msg=C0301
