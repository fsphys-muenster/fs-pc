"""
  This file defines values for some modules.

  (C) Fuji Xerox Co., Ltd. 2010
 
  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:
  1. Redistributions of source code must retain the above copyright
     notice, this list of conditions and the following disclaimer.
  2. Redistributions in binary form must reproduce the above copyright
     notice, this list of conditions and the following disclaimer in the
     documentation and/or other materials provided with the distribution.
  3. Neither the name of Fuji Xerox Co., Ltd. nor the names of its
     contributors may be used to endorse or promote products derived from
     this software without specific prior written permission.
  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
  POSSIBILITY OF SUCH DAMAGE.
"""

# File paths.
PATH_DLST = 'DellPrinters/SupportTools/'
PATH_DLST_SHARE = '/usr/share/' + PATH_DLST
PATH_DLST_RESOURCE = PATH_DLST_SHARE + 'res/'
PATH_DLST_LOCALES = PATH_DLST_SHARE + 'locales/'
PATH_DLST_BIN = '/usr/bin/' + PATH_DLST
PATH_DLST_BIN_SMS = PATH_DLST_BIN + 'dlsms.py'
PATH_DLST_ETC = '/etc/' + PATH_DLST
PATH_DLST_HOME = '~/.' + PATH_DLST

PREFIX_STATUS_INFO =  'pss_'
POSTFIX_STATUS_INFO = '.dat'

# Define file permission in user's home directory.
MOD_DLST_HOME = 0700
MOD_DLST_HOME_FILE = 0600

# Key code map.
KEY_CODE_ESC = 65307
KEY_CODE_F5 = 65474

# Default locale.
DEFAULT_LOCALE = 'en_US'
DEFAULT_LC_MESSAGES = 'C'

# Define the premier url name.
URL_NAME_REGULAR = 'Regular'
URL_NAME_PREMIER = 'Premier'

# Environment value for locale name
ENV_LANG = 'LANG'
ENV_LC_MESSAGES = 'LC_MESSAGES'

# Default environment locale.
DEFAULT_LOCALE_LANG = 'en_US.UTF-8'

# Printer ID Parameter Name
PARAM_PRINTER_ID = 'PRNID'