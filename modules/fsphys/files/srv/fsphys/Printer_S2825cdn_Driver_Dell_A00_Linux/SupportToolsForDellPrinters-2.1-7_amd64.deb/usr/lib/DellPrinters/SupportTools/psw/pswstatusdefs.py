"""
  This file defines status showed in PSW.

  (C) Fuji Xerox Co., Ltd. 2010

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:
  1. Redistributions of source code must retain the above copyright
     notice, this list of conditions and the following disclaimer.
  2. Redistributions in binary form must reproduce the above copyright
     notice, this list of conditions and the following disclaimer in the
     documentation and/or other materials provided with the distribution.
  3. Neither the name of Fuji Xerox Co., Ltd. nor the names of its
     contributors may be used to endorse or promote products derived from
     this software without specific prior written permission.
  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
  POSSIBILITY OF SUCH DAMAGE.
"""

try:
    import gettext
except:
    raise # Exception code is written in parent module.
_ = gettext.gettext


# pylint: disable-msg=C0301


# Status message showed in PSW.
MSG_PSW_PAPERJAM = _('Paper Jam has occurred.')
MSG_PSW_COVEROPEN = _('The cover is open.')
MSG_PSW_NOTONER = _('The Toner Cartridge needs to be replaced now.')
MSG_PSW_NOPAPER = _('No paper detected.')
MSG_PSW_TONERLOW = _('The Toner Cartridge needs to be replaced soon.')
MSG_PSW_PAPERLOW = _('Paper Low.')
MSG_PSW_OFFLINE = _('Printer is offline.')
MSG_PSW_ONLINE = _('Ready to print.')
MSG_PSW_ST = _('Error has occurred on the printer.\nCheck if there are any errors displayed on the operator panel.')
MSG_PSW_NOGETINFO = _('Cannot get printer information.')
MSG_PSW_GETTINGINFO = _('Acquiring printer information.')


# Status message ID.
ID_MSG_PSW_PAPERJAM = 0x1000001
ID_MSG_PSW_COVEROPEN = 0x2000001
ID_MSG_PSW_NOTONER = 0x3000001
ID_MSG_PSW_NOPAPER = 0x4000001
ID_MSG_PSW_TONERLOW = 0x5000001
ID_MSG_PSW_PAPERLOW = 0x6000001
ID_MSG_PSW_OFFLINE = 0x7000001
ID_MSG_PSW_ONLINE = 0x8000001
ID_MSG_PSW_ST = 0x9000001
ID_MSG_PSW_NOGETINFO = 0x9000002
ID_MSG_PSW_GETTINGINFO = 0x9000003


# Matching ID and status table.
PSW_STATUS_TABLE = {
    ID_MSG_PSW_PAPERJAM: MSG_PSW_PAPERJAM,
    ID_MSG_PSW_COVEROPEN: MSG_PSW_COVEROPEN,
    ID_MSG_PSW_NOTONER: MSG_PSW_NOTONER,
    ID_MSG_PSW_NOPAPER: MSG_PSW_NOPAPER,
    ID_MSG_PSW_TONERLOW: MSG_PSW_TONERLOW,
    ID_MSG_PSW_PAPERLOW: MSG_PSW_PAPERLOW,
    ID_MSG_PSW_OFFLINE: MSG_PSW_OFFLINE,
    ID_MSG_PSW_ONLINE: MSG_PSW_ONLINE,
    ID_MSG_PSW_ST: MSG_PSW_ST,
    ID_MSG_PSW_NOGETINFO: MSG_PSW_NOGETINFO,
    ID_MSG_PSW_GETTINGINFO: MSG_PSW_GETTINGINFO
}

# pylint: enable-msg=C0301


