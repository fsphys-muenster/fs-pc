"""
  This class is used to get printer status and refresh PSL and PSW regularly.

  (C) Fuji Xerox Co., Ltd. 2010
 
  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:
  1. Redistributions of source code must retain the above copyright
     notice, this list of conditions and the following disclaimer.
  2. Redistributions in binary form must reproduce the above copyright
     notice, this list of conditions and the following disclaimer in the
     documentation and/or other materials provided with the distribution.
  3. Neither the name of Fuji Xerox Co., Ltd. nor the names of its
     contributors may be used to endorse or promote products derived from
     this software without specific prior written permission.
  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
  POSSIBILITY OF SUCH DAMAGE.
"""

try:
    from threading import Thread, Lock
    from datetime import datetime, timedelta
    import time
    import gtk
    
    from common import printerstatusinfo, printerinfo, printerinfodefs
    from common import printerstatus, printerstatusdefs
    from common.printermodellist import PrinterModelList
    from psl import psldefs, pslmisc
except:
    raise # Exception code is written in parent module.

TIME_SLEEP_PER_LOOP = 0.01  # seconds

def _get_initialized_info():
    """ Get the initialized information dictionary.
    
    Return value:
    Initialized information dictionary.
    
    """
    info = {psldefs.KEY_INFO_NAME:None,
            psldefs.KEY_INFO_MODEL:None,
            psldefs.KEY_INFO_URI:None,
            psldefs.KEY_INFO_STATUS:None,
            psldefs.KEY_INFO_GOT:False,
            psldefs.KEY_INFO_EXIST:True,
            psldefs.KEY_INFO_PRINTER_ID:None,
    	    psldefs.KEY_INFO_COLOR_DEVICE:None}
    return info

def _set_printer_info(info, printer_info):
    """ Set the printer information values to information dictionary.
    
    Arguments:
    info -- Information dictionary to set printer information.
    printer_info -- Printer information contains 
                    printer name, model name, device URI.
                    
    """
    # Set printer information if printer_tuple member is correct.
    if len(printer_info) == printerinfodefs.NUM_OF_PRN_INFO:
        info[psldefs.KEY_INFO_NAME] = \
            printer_info[printerinfodefs.INDEX_PRN_INFO_NAME]
        info[psldefs.KEY_INFO_MODEL] = \
            printer_info[printerinfodefs.INDEX_PRN_INFO_MODEL]
        info[psldefs.KEY_INFO_URI] = \
            printer_info[printerinfodefs.INDEX_PRN_INFO_URI]

def _set_not_existing_info(info, printer_name):
    """ Set the information dictionary for values of not existing printer. 
    
    Arguments:
    info -- Information dictionary to set values.
    printer_name -- Printer name to set to printer information dictionary.
    
    """
    info[psldefs.KEY_INFO_NAME] = printer_name
    info[psldefs.KEY_INFO_GOT] = True
    info[psldefs.KEY_INFO_EXIST] = False
    info[psldefs.KEY_INFO_COLOR_DEVICE] = True
    
def _save_printer_status_info(printer_status, color_device):
    """Save printer status to printer status information file.
    
    Argument:
    printer_status -- Printer status to save.
    
    """
    printer_status_info = printerstatusinfo.PrinterStatusInfo()
    try:
        printer_status_info.load_status_info_from_printer_status(
            printer_status, color_device)
        printer_status_info.save_status_info()
    except (ValueError, IOError): # pylint: disable-msg=W0704
        pass    # No process to Error at save file in polling thread.
    

class PollingThread(Thread):    # pylint: disable-msg=R0902
    """Get printer status and refresh PSL and PSW regularly."""
    
    def __init__(self, callback_update_psl_printer, 
                 callback_update_psl_list, resolve):
        """Initialize each members, and prepare to start new thread.
        
        Arguments:
        callback_update_psl_printer -- Callback method for update status of 
                                       one printer in PSL.
        callback_update_psl_list -- Callback method for update status of 
                                    all printers in PSL.
        resolve -- Flag how to resolve host name.
        
        Exceptions:
        ValueError -- If callback_update_psl_printer or 
                      callback_update_psl_list is not callable object,
                      of printer model list contains incorrect value.
        IOError -- Failed to load printer model list file.
        
        """
        if (not callable(callback_update_psl_printer) or 
            not callable(callback_update_psl_list)):
            raise ValueError
        
        Thread.__init__(self)
        self.setDaemon(True)
        
        self.__callback_update_psl_printer = callback_update_psl_printer
        self.__callback_update_psl_list = callback_update_psl_list
        self.__name_psw_printer = None
        self.__callback_update_psw_printer = None
        self.__req_psl_refresh = False
        self.__req_psw_refresh = False
        self.__polling = False
        self.__polling_time = 0
        self.__community_name = None
        self.__req_quit = False
        self.__refreshed_psw = False
        self.__thread_lock = Lock()
        self.__info_list = None
        self.__printer_model_list = PrinterModelList()
        self.__resolve = resolve

    def run(self):
        """Get printer status and refresh PSW and PSL regularly in new thread.
        """
        polling_time_start = datetime.now()
        start_get_status = False
        while True:     # Loop until quit flag is set.
            time.sleep(TIME_SLEEP_PER_LOOP)
            polling_time_now = datetime.now()
            
            self.__thread_lock.acquire()
            req_quit = self.__req_quit
            req_psw_refresh = self.__req_psw_refresh
            req_psl_refresh = self.__req_psl_refresh
            polling_time = self.__polling_time
            polling = self.__polling
            community_name = self.__community_name
            self.__thread_lock.release()
            
            if req_quit:
                break
            
            if req_psw_refresh:
                self.__thread_lock.acquire()
                self.__req_psw_refresh = False
                self.__thread_lock.release()
                self.__refresh_psw_printer_status(community_name)
                continue
                
            if req_psl_refresh:
                start_get_status = True
            else:
                if(polling):
                    passed_time = polling_time_now - polling_time_start
                    if (passed_time >= timedelta(seconds=polling_time)):
                        start_get_status = True
                    elif(passed_time < timedelta(0)):
                        start_get_status = True
            
            # Continue waiting if any refresh flag is set.
            if not start_get_status:
                continue
            
            self.__get_printers_status(community_name)
            
            self.__thread_lock.acquire()
            req_quit = self.__req_quit
            self.__thread_lock.release()
            if req_quit:
                break

            self.__refresh_all_printers_status()

            # Reset polling passed status.
            self.__info_list = None
            polling_time_start = datetime.now()
            start_get_status = False
    
    def quit(self):
        """Set true to __req_quit for finish the polling thread."""
        self.__thread_lock.acquire()
        self.__req_quit = True
        self.__thread_lock.release()
    
    def set_psl_refresh_flag(self):
        """Set true to __req_psl_refresh for update PSL in run method."""
        self.__thread_lock.acquire()
        self.__req_psl_refresh = True
        self.__thread_lock.release()
    
    def set_psw_refresh_flag(self, name, callback_update_psw_printer):
        """Set true to __req_psw_refresh, and set printer name showing in PSW 
        and callback method for update PSW to each member.
        
        Arguments:
        name -- Printer name showing in PSW.
        callback_update_psw_printer -- Callback method for update status 
                                       in PSW.
        
        Exception:
        ValueError -- If name is not string, or 
                      callback_update_psw_printer is not callable object.
                      
        """
        self.__thread_lock.acquire()
        self.__req_psw_refresh = True
        self.__name_psw_printer = name
        self.__callback_update_psw_printer = callback_update_psw_printer
        self.__thread_lock.release()
    
    def set_setting_update(self, polling, polling_time, community_name):
        """Set the setting values updated in the setting dialog using for 
        polling thread to each member.
        
        Arguments:
        polling -- Flag whether update regularly or not.
        polling_time -- Interval time seconds for polling.
        community_name -- Encoded community name to get printer status 
                          by printerstatus.
                          
        """
        self.__thread_lock.acquire()
        self.__polling = polling
        self.__polling_time = polling_time
        self.__community_name = community_name
        self.__thread_lock.release()
    
    def del_psw_info(self):
        """Delete printer name and callback method for PSW from member."""
        self.__thread_lock.acquire()
        self.__name_psw_printer = None
        self.__callback_update_psw_printer = None
        self.__thread_lock.release()
    
    def __get_printers_status(self, community_name):
        """Get printer status of all printers registered in CUPS.
        
        Argument:
        community_name -- Encoded community name to get printer status 
                          by printerstatus.        
        
        """
        try:
            self.__info_list = []
            all_printer_info = printerinfo.get_printer_list()
            for printer_info in all_printer_info:
                new_info = _get_initialized_info()
                _set_printer_info(new_info, printer_info)
                self.__info_list.append(new_info)
        except(IOError, MemoryError):
            self.__info_list = []
            
        for info in self.__info_list:
            self.__thread_lock.acquire()
            req_quit = self.__req_quit
            self.__thread_lock.release()
            if req_quit:
                break
            
            self.__thread_lock.acquire()
            req_psw_refresh = self.__req_psw_refresh
            self.__thread_lock.release()
            if req_psw_refresh:
                self.__thread_lock.acquire()
                self.__req_psw_refresh = False
                self.__thread_lock.release()
                self.__refresh_psw_printer_status(community_name)
                self.__refreshed_psw = True
                
            # Skip getting status from this printer if already got.
            if info[psldefs.KEY_INFO_GOT]:
                continue
            
            # Get printer status
            model = info[psldefs.KEY_INFO_MODEL]
            if self.__printer_model_list.is_supported_driver_name(model):
                info[psldefs.KEY_INFO_MODEL] = \
                    self.__printer_model_list.get_model_name_from_driver_name(
                        model)
                info[psldefs.KEY_INFO_PRINTER_ID] = \
                    self.__printer_model_list.get_printer_id_from_driver_name(
                        model)
                device_name = \
                    self.__printer_model_list.get_device_name_from_driver_name(
                        model)
                
                info[psldefs.KEY_INFO_COLOR_DEVICE] = \
                    self.__printer_model_list.get_color_device_from_driver_name(
                        model)
		
		ip_address = pslmisc.get_ip_address_from_uri(
                                info[psldefs.KEY_INFO_URI])
                printer_status = printerstatus.get_status_from_printer(
                                    ip_address, 
                                    community_name,
                                    self.__resolve,
				    info[psldefs.KEY_INFO_COLOR_DEVICE])
                if printer_status[printerstatusdefs.KEY_STATUS_MODEL] == \
                    device_name:
                    info[psldefs.KEY_INFO_STATUS] = printer_status
                info[psldefs.KEY_INFO_GOT] = True
                _save_printer_status_info(printer_status, info[psldefs.KEY_INFO_COLOR_DEVICE])

    def __refresh_psw_printer_status(self, community_name):
        """Refresh PSL and PSW status of printer showing in PSW.
        
        Argument:
        community_name -- Encoded community name to get printer status 
                          by printerstatus.
        
        """
        info = None
        self.__thread_lock.acquire()
        name_psw_printer = self.__name_psw_printer
        self.__thread_lock.release()
        
        if self.__info_list:
            for info_in_list in self.__info_list:
                if info_in_list[psldefs.KEY_INFO_NAME] == \
                    name_psw_printer:
                    info = info_in_list

        # Make printer status dict if no printer info in __printer_status.
        if not info:
            try:
                printer_info = printerinfo.get_printer(name_psw_printer)
                info = _get_initialized_info()
                _set_printer_info(info, printer_info)
            except(IOError, ValueError, MemoryError):
                info = _get_initialized_info()
                _set_not_existing_info(info, name_psw_printer)
        
        model = info[psldefs.KEY_INFO_MODEL]
        support_model = \
            self.__printer_model_list.is_supported_driver_name(model)
        if support_model:
            info[psldefs.KEY_INFO_MODEL] = \
                self.__printer_model_list.get_model_name_from_driver_name(
                    model)
            info[psldefs.KEY_INFO_PRINTER_ID] = \
                self.__printer_model_list.get_printer_id_from_driver_name(
                    model)
            info[psldefs.KEY_INFO_COLOR_DEVICE] = \
                self.__printer_model_list.get_color_device_from_driver_name(
                    model)

        # Get printer status.
        if (not info[psldefs.KEY_INFO_GOT] and support_model):
            ip_address = pslmisc.get_ip_address_from_uri(
                            info[psldefs.KEY_INFO_URI])
            device_name = \
                self.__printer_model_list.get_device_name_from_driver_name(
                    model)
            
            printer_status = printerstatus.get_status_from_printer(
                                ip_address, 
                                community_name,
                                self.__resolve, 
			        info[psldefs.KEY_INFO_COLOR_DEVICE])
            if printer_status[printerstatusdefs.KEY_STATUS_MODEL] == \
                device_name:
                info[psldefs.KEY_INFO_STATUS] = printer_status
            info[psldefs.KEY_INFO_GOT] = True
        
        self.__thread_lock.acquire()
        if self.__callback_update_psw_printer:
            gtk.gdk.threads_enter()
            self.__callback_update_psw_printer(info)
            gtk.gdk.threads_leave()
        self.__thread_lock.release()
        self.__callback_update_psl_printer(info)
	
        _save_printer_status_info(info[psldefs.KEY_INFO_STATUS], info[psldefs.KEY_INFO_COLOR_DEVICE])
    
    def __refresh_all_printers_status(self):
        """Refresh PSL and PSW status of all printers registered in CUPS."""
        if not self.__refreshed_psw:
            self.__thread_lock.acquire()
            if self.__callback_update_psw_printer:
                for info_in_list in self.__info_list:
                    if info_in_list[psldefs.KEY_INFO_NAME] == \
                        self.__name_psw_printer:
                        info = info_in_list
                        break
                else:
                    info = _get_initialized_info()
                    _set_not_existing_info(info, self.__name_psw_printer)
                gtk.gdk.threads_enter()
                self.__callback_update_psw_printer(info)
                gtk.gdk.threads_leave()
            self.__thread_lock.release()            
        self.__refreshed_psw = False
        
        self.__callback_update_psl_list(self.__info_list)
        self.__thread_lock.acquire()
        self.__req_psl_refresh = False
        self.__thread_lock.release()

        
