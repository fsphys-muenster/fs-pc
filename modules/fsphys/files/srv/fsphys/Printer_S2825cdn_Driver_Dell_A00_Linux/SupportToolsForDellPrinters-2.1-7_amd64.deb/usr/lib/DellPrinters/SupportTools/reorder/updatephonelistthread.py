"""
  This class is used to get latest phone number list from server.

  (C) Fuji Xerox Co., Ltd. 2010-2012
 
  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:
  1. Redistributions of source code must retain the above copyright
     notice, this list of conditions and the following disclaimer.
  2. Redistributions in binary form must reproduce the above copyright
     notice, this list of conditions and the following disclaimer in the
     documentation and/or other materials provided with the distribution.
  3. Neither the name of Fuji Xerox Co., Ltd. nor the names of its
     contributors may be used to endorse or promote products derived from
     this software without specific prior written permission.
  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
  POSSIBILITY OF SUCH DAMAGE.
"""

try:
    from threading import Thread
    from email.Utils import parsedate
    import os
    import pwd
    import shutil
    import urllib2
    import socket
    import fcntl
    import time
    
    from reorder import tellist, reordermisc
    from common import defs
except:
    raise # Exception code is written in parent module.

# Define result value for callback function.
UNNECESSARY_UPDATE = 1
SUCCEEDED_IN_UPDATE = 0
FAILED_TO_ACCESS_SERVER = -1
FAILED_TO_DOWNLOAD = -2
FAILED_TO_MOVE_FILE = -3

# Define constant values using in the thread.
TIMEOUT_AS_SECONDS = 180.0
PATH_TO_TEMPORARY_DIR = '/tmp/'
MOD_TEMPORARY_DL_FILE = 0600


def get_lastmodified_from_server_response(response):
    """Get Last-Modified header and convert to time tuple.
    
    Argument:
    response -- Response from the server.

    Return Values:
    tuple -- Time converted from Last-Modified header.
    None -- If there is no last-modified in response.
    """
    ts = None
    try:
        info = response.info()
        if "last-modified" in info.dict:
            # Last-Modified is supposed to like 
            # "Wed, 15 Nov 1995 04:58:08 GMT".
            # time.strptime cannot use here because its result
            # depends on the current locale.
            ts = parsedate(info["last-modified"])
    except:
        ts = None

    return ts

class UpdatePhoneListThread(Thread):
    """Thread class for updating phone list file."""
        
    def __init__(self, model, callback_update_phone_list):
        """Initialize each members, and prepare to start new thread.
        
        Arguments:
        model -- Instance of SMSModel class to get CRA settings.
        callback_update_phone_list -- Callback method for update CRA dialog.
        
        Exception:
        ValueError -- If callback_update_phone_list is not callable object.
        """       
        Thread.__init__(self)
        if not callable(callback_update_phone_list):
            raise ValueError 

        self.__model = model
        self.__callback_update_phone_list = callback_update_phone_list
        self.setDaemon(True)

        username = pwd.getpwuid(os.getuid())[0]
        self.__temporary_file_path = PATH_TO_TEMPORARY_DIR + (username
                                                 + '_' + tellist.FILE_TEL_LIST)
        self.__response = None
        self.__localfile_path = (reordermisc.get_user_phone_list_dir_path() 
                                                    + tellist.FILE_TEL_LIST)
    def run(self):
        """Connect to the phone list server and update phone list file
        and UI.
        """
        timeout_backup = socket.getdefaulttimeout()
        socket.setdefaulttimeout(TIMEOUT_AS_SECONDS)
        result = self.__get_phonelist_from_server()
        # Restore the timeout setting.
        socket.setdefaulttimeout(timeout_backup)
        self.__callback_update_phone_list(result)

    def __compare_timestamp(self):
        """Compare local file with server file time stamp.
        
        Return Value:
        True -- If server file is newer or local file does not exist.
        False -- If local file is newer.
        """
        if os.access(self.__localfile_path, os.F_OK):
            ts_server = get_lastmodified_from_server_response(self.__response)
            if not ts_server:
                # No needs to update if Last-Modified is not contained.
                return False
            ts_local_sec = os.path.getmtime(self.__localfile_path)
            ts_local = time.gmtime(ts_local_sec)
            ts_server_sec_l = time.mktime(ts_server)
            ts_local_sec_l = time.mktime(ts_local)
            if ts_local_sec_l >= ts_server_sec_l:
                return False
        return True
    
    def __download_from_server(self):
        """Download phonelist from the server.
        
        Exception:
        IOError -- Failed to download or write file.        
        """
        download_file_lock = None
        download_file = None
        try:
            read_buffer = self.__response.read()
            download_file_lock = open(self.__temporary_file_path, 'a')
            fcntl.flock(download_file_lock.fileno(), fcntl.LOCK_EX)
            download_file = open(self.__temporary_file_path, 'w+')
            download_file.write(read_buffer)
            os.chmod(self.__temporary_file_path, MOD_TEMPORARY_DL_FILE)
        finally:
            if download_file:
                download_file.close()
            if download_file_lock:
                download_file_lock.close()
            self.__response.close()

    def __move_to_home_dir(self):
        """Move download file to home directory.
        
        Return Value:
        True -- Success to move file.
        False -- Failed to move file.
        """
        try:
            home_dir = os.path.expanduser(defs.PATH_DLST_HOME)
            os.makedirs(home_dir, defs.MOD_DLST_HOME)
        except:  # pylint: disable-msg=W0704
            pass  # through exception when failed to make directory.

        try:
            if os.access(self.__localfile_path, os.F_OK):
                os.remove(self.__localfile_path)
            shutil.move(self.__temporary_file_path, self.__localfile_path)
            os.chmod(self.__localfile_path, defs.MOD_DLST_HOME_FILE)
        except:
            try:
                os.remove(self.__temporary_file_path)
            except:
                pass  # Ignore if temporary file cannot remove.
            return False

        return True
    
    def __get_phonelist_from_server(self):  # pylint: disable-msg=R0911
        """Connect to the phone list server and acquire latest phone
        list file.
        
        Return Value:
        result -- The result value means the update process is success
                  or not.
        """
        if os.access(self.__temporary_file_path, os.F_OK):
            try:
                os.remove(self.__temporary_file_path)
            except:
                pass  # Ignore if temporary file cannot remove.
        
        server_url = self.__model.get_update_phone_list_server_url()
        try:
            self.__response = urllib2.urlopen(server_url)
            if not self.__response:
                # urlopen might return None.
                return FAILED_TO_ACCESS_SERVER
        except:
            # Any exception treats connection error.
            return FAILED_TO_ACCESS_SERVER

        is_updated = self.__compare_timestamp()
        if not is_updated:
            self.__response.close()
            return UNNECESSARY_UPDATE
        
        try:
            self.__download_from_server()
        except:
            return FAILED_TO_DOWNLOAD
            
        try:
            # Verify download file. 
            # Download file is invalid if it cannot load.
            download_tellist = tellist.TelList(self.__temporary_file_path)
            del download_tellist  # Nobody uses.
        except:
            try:
                os.remove(self.__temporary_file_path)
            except:
                pass  # Ignore if temporary file cannot remove.
            return FAILED_TO_DOWNLOAD

        moved = self.__move_to_home_dir()
        if not moved:
            return FAILED_TO_MOVE_FILE

        return SUCCEEDED_IN_UPDATE

