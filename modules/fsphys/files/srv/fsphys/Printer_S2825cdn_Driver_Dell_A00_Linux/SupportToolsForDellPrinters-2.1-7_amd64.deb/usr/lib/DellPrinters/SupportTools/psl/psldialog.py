"""
  This class is used to show printer selection dialog.

  (C) Fuji Xerox Co., Ltd. 2010
 
  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:
  1. Redistributions of source code must retain the above copyright
     notice, this list of conditions and the following disclaimer.
  2. Redistributions in binary form must reproduce the above copyright
     notice, this list of conditions and the following disclaimer in the
     documentation and/or other materials provided with the distribution.
  3. Neither the name of Fuji Xerox Co., Ltd. nor the names of its
     contributors may be used to endorse or promote products derived from
     this software without specific prior written permission.
  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
  POSSIBILITY OF SUCH DAMAGE.
"""

try:
    import gtk
    import gtk.glade
    import pygtk
    pygtk.require("2.0")

    from common.defs import PATH_DLST_RESOURCE
    from common import preventsamewindow, msgdlg, defs
    from common import printerinfo, webbrowser
    from common.printerstatusdefs import KEY_STATUS_STATUS
    from psl import pslmodel, settingdlg, pollingthread, pslmisc
    from psl import pslmessage, psldefs, pslstatusdefs
    from psw import pswdialog

except:
    raise  # Exception code is written in parent module.

# Variable definitions.
FILE_GLADE = 'psldialog.glade'
FILE_ICON_READY = 'dlpsl_icon_status_ready.png'
FILE_ICON_WARNING = 'dlpsl_icon_status_warning.png'
FILE_ICON_ERROR = 'dlpsl_icon_status_error.png'

INDEX_LIST_NAME = 0
INDEX_LIST_STATUS_ICON = 1
INDEX_LIST_STATUS_TEXT = 2
INDEX_LIST_MODEL = 3
INDEX_LIST_URI = 4

URI_SOCKET = 'socket://'
URI_LPD = 'lpd://'
URL_HTTP = 'http://'
URL_HTTPS = 'https://'

NAME_TREEVIEW_PRINTERLIST = 'treeviewPrinterList'

def is_supported_connection(uri):
    """Check device URI whether it is supported or not.
      
    Argument:
    uri -- device URI
        
    Return values:
    True -- Supported
    False -- Not Supported
        
     """
    if not isinstance(uri, basestring):
        return False
        
    if (uri[:len(URI_SOCKET)] == URI_SOCKET or
        uri[:len(URI_LPD)] == URI_LPD):
        return True
        
    return False

def _get_status_text_and_icon_from_status_num(status_num):
    """ Get printer status text and icon id to show in PSL status
    correspond to status id in tuple.
    
    Argument:
    status_num -- Printer status number
    
    Return values:
    Status text and icon id -- Status text and icon id 
                               corresponds to status id in tuple.
    None -- Any status id is not match.
    
    """
    if not isinstance(status_num, int):
        return None
    
    # Get PSL status from printer status.
    status_id = status_num >> (pslstatusdefs.PRINTER_STATUS_BIT - 
                               pslstatusdefs.PSL_STATUS_BIT)
    try:
        status = pslstatusdefs.PSL_STATUS_TABLE[status_id]
    except KeyError:
        status = None
        
    return status


class PSLDialog(                        # pylint: disable-msg=R0902
        preventsamewindow.PreventSameWindow):
    """Show the printer selection dialog."""
    
    WINDOW_ATOM_NAME_OF_PSLDLG =  'SupportToolsForDellPrinters_PSL_PSLDialog'
    
    def __init__(self):
        """Show the printer selection dialog.
        
        Exception:
        IOError -- failed to load setting files.
        ValueError -- invalid value in setting files.
        
        """
        preventsamewindow.PreventSameWindow.__init__(self)
        
        # Check if this program is already running.
        self.set_window_atom_name(self.WINDOW_ATOM_NAME_OF_PSLDLG)
        if self.is_existing():
            self.move_forward()
            return

        # Create instance of message box class.
        self.__err_dlg = msgdlg.MsgDialog(
                            pslmessage.MSG_PSL_TITLE_ERR_DLG,
                            defs.PATH_DLST_RESOURCE + psldefs.FILE_ICON_16x16,
                            defs.PATH_DLST_RESOURCE + psldefs.FILE_ICON_48x48)
        
        # Load printer model list.
        try:
            self.__psl_model = pslmodel.PSLModel()
        except (IOError, ValueError):
            # Show warning and exit if this failed to load printer model list.
            self.__err_dlg.show_error_dialog(pslmessage.MSG_PSL_START_FAIL)
            return
        
        # Load setting files.
        try:
            self.__psl_model.load_config()
        except (IOError, ValueError):
            self.__err_dlg.show_warning_dialog(
                pslmessage.MSG_PSL_READ_SETTING_FILE_FAIL)

        try:
            self.__polling_thread = pollingthread.PollingThread(
                                        self.__update_printer, 
                                        self.__update_list,
                                        self.__psl_model.get_resolve())
        except (ValueError, IOError):
            # Show warning and exit if this failed to load printer model list.
            self.__err_dlg.show_error_dialog(pslmessage.MSG_PSL_START_FAIL)
            return
            
        # Display the dialog.
        glade = PATH_DLST_RESOURCE + FILE_GLADE
        self.__widget_tree = gtk.glade.XML(glade)
        self.__windowMain = \
            self.__widget_tree.get_widget('windowPrinterSelection')
        self.treeviewPrinters = \
            self.__widget_tree.get_widget(NAME_TREEVIEW_PRINTERLIST)
        self.__buttonDetails = self.__widget_tree.get_widget('buttonDetails')
        self.__buttonRefresh = self.__widget_tree.get_widget('buttonRefresh')
        self.__windowMain.realize()
        self.register_window_atom(self.__windowMain.window.xid)

        self.__windowMain.set_icon_list(
            gtk.gdk.pixbuf_new_from_file(PATH_DLST_RESOURCE + 
                                         psldefs.FILE_ICON_16x16),
            gtk.gdk.pixbuf_new_from_file(PATH_DLST_RESOURCE + 
                                         psldefs.FILE_ICON_48x48))
        
        event_dic = {
            "on_windowPrinterSelection_destroy": self.on_buttonClose_clicked,
            "on_windowPrinterSelection_key_press_event": 
                            self.on_windowPrinterSelection_key_press_event,
            "on_buttonClose_clicked": self.on_buttonClose_clicked,
            "on_buttonSettings_clicked": self.on_buttonSettings_clicked,
            "on_buttonDetails_clicked": self.on_buttonDetails_clicked,
            "on_buttonRefresh_clicked": self.on_buttonRefresh_clicked,
            "on_treeviewPrinterList_row_activated": 
                                 self.__on_treeviewPrinterList_row_activated,
            "on_treeviewPrinterList_cursor_changed": 
                            self.on_treeviewPrinterList_cursor_changed}
        self.__widget_tree.signal_autoconnect(event_dic)

        # Create instance of modal message box class.
        del self.__err_dlg
        self.__err_dlg = msgdlg.MsgDialog(
                            pslmessage.MSG_PSL_TITLE_ERR_DLG,
                            defs.PATH_DLST_RESOURCE + psldefs.FILE_ICON_16x16,
                            defs.PATH_DLST_RESOURCE + psldefs.FILE_ICON_48x48,
                            self.__windowMain)
        
        # Load icons for printer status.
        self.__status_icon_ready = gtk.gdk.pixbuf_new_from_file(
                                            PATH_DLST_RESOURCE + 
                                            FILE_ICON_READY)
        self.__status_icon_warning = gtk.gdk.pixbuf_new_from_file(
                                            PATH_DLST_RESOURCE + 
                                            FILE_ICON_WARNING)
        self.__status_icon_error = gtk.gdk.pixbuf_new_from_file(
                                            PATH_DLST_RESOURCE + 
                                            FILE_ICON_ERROR)
       
        self.printer_list_data = gtk.ListStore(
                                        str, gtk.gdk.Pixbuf, str, str, str)

        # Initialize a widget for printer list.
        self.__buttonDetails.set_sensitive(False)
        self.__init_printer_list_columns()
        self.__initialize_list()
        self.treeviewPrinters.grab_focus()
        
        self.__polling_thread.set_setting_update(
            self.__psl_model.get_polling(), 
            self.__psl_model.get_polling_time(), 
            self.__psl_model.get_community_name())
        self.__polling_thread.start()
        self.__polling_thread.set_psl_refresh_flag()
        
        gtk.gdk.threads_init()        
        
        del self.__err_dlg
        self.__err_dlg = msgdlg.MsgDialog(
                            pslmessage.MSG_PSL_SETTINGS_TITLE_ERR_DLG,
                            defs.PATH_DLST_RESOURCE + psldefs.FILE_ICON_16x16,
                            defs.PATH_DLST_RESOURCE + psldefs.FILE_ICON_48x48,
                            self.__windowMain)
        
        gtk.main()
        
    def close_dialog(self):
        """ Close PSL dialog. """
        self.__windowMain.hide()
        while gtk.events_pending():
            gtk.main_iteration()
        self.delete_window_atom()   # After PSL is hide, another PSL can run.
        self.__polling_thread.quit()
        self.__polling_thread.join()
        gtk.main_quit()

    def on_buttonClose_clicked(self, button):  # pylint: disable-msg=W0613
        """Close PSL dialog.
        
        Argument:
        button -- instance of buttonClose
        
        """
        self.close_dialog()
    
    def on_windowPrinterSelection_key_press_event(  # pylint: disable-msg=W0613
            self, widget, event):
        """Quit PSL dialog when ESC-key is clicked.
        
        Arguments:
        widget -- A object of windowMain.
        event -- A event object of on_windowPrinterSelection_key_press_event.
        
        """
        if event.keyval == defs.KEY_CODE_ESC:
            self.close_dialog()
    
    def on_treeviewPrinterList_cursor_changed(self, tv):
        """Change details button's status when printer list clicked.
        
        Argument:
        tv -- instance of printer list tree view.
        
        """
        row = tv.get_selection().get_selected()
        if row[1]:
            uri = self.printer_list_data.get_value(row[1], INDEX_LIST_URI)
            supported = is_supported_connection(uri)
            self.__buttonDetails.set_sensitive(supported)
        else:
            self.__buttonDetails.set_sensitive(False)

    def on_buttonSettings_clicked(self, button):  # pylint: disable-msg=W0613
        """Open settings dialog.
        
        Argument:
        button -- instance of buttonSettings.
        
        """
        settingdlg.SettingDialog(self.__psl_model, self.__polling_thread, 
                                 self.__windowMain)
        
    def __show_details(self):
        """Show details of printer status.
        If selected printer is supported, open PSW.
        If not, open web browser for showing setting page in printer.
        
        """
        row = self.treeviewPrinters.get_selection().get_selected()
        if row[1]:
            printer_name = self.printer_list_data.get_value(
                                                row[1], INDEX_LIST_NAME)
            uri = self.printer_list_data.get_value(row[1], INDEX_LIST_URI)
            if is_supported_connection(uri):
                printer_model_name = self.__get_printer_model()
                # Check selected printer is support model or not.
                support_printer = False
                model_name_list = self.__psl_model.get_model_name_list()
                for support_model_name in model_name_list:
                    if support_model_name == printer_model_name:
                        support_printer = True
                if support_printer:
		    color_device = self.__psl_model.get_color_device_from_model_name(printer_model_name)
                    pswdialog.PSWDialog(printer_name, color_device, self.__polling_thread)
                else:
                    self.__open_setting_page_by_browser()
        else:
            uri = None
        
    def on_buttonDetails_clicked(self, button):  # pylint: disable-msg=W0613
        """Show details of printer status when clicked Details button.
        
        Argument:
        button -- instance of buttonDetails.
        
        """
        self.__show_details()
            
    def __on_treeviewPrinterList_row_activated( # pylint: disable-msg=W0613
                            self, treeview, 
                            path, view_column):
        """ Show details of printer status when double clicked.
        
        Arguments:
        treeview -- the treeview that received the row_activated.
        path -- the path of the activated row.
        view_column -- the colomn in the activated row.
        
        """
        focus_widget = self.__windowMain.get_focus()
        focus_name = focus_widget.get_name()
        if focus_name == NAME_TREEVIEW_PRINTERLIST:
            self.__show_details()
        
    def on_buttonRefresh_clicked(self, button):
        """Refresh printer status view.
        
        Argument:
        button -- instance of buttonRefresh.
        
        """
        button.set_sensitive(False)
        self.__polling_thread.set_psl_refresh_flag()

    def __add_list_column_text(self, title, column_id, last_column):
        """Add column in printer list widget for text.

        Arguments:
        title -- text of header
        column_id -- order id in ListStore object.
        last_column -- Flag of last column
        
         """
        cell_renderer = gtk.CellRendererText()
        if last_column:
            cell_renderer.set_fixed_size(0, -1)
        column = gtk.TreeViewColumn(title, cell_renderer, text=column_id)
        column.set_resizable(True)
        column.set_sort_column_id(column_id)
        self.treeviewPrinters.append_column(column)
        
    def __add_list_column_pix(self, title, column_id_pix, column_id_text):
        """Add column in printer list widget for text and image.

        Arguments:
        title -- text of header
        column_id_pix -- order id for image in ListStore object 
        column_id_text -- order id for text in ListStore object
             
         """
        cellpb = gtk.CellRendererPixbuf()
        celltext = gtk.CellRendererText()
        column = gtk.TreeViewColumn(title)
        
        column.pack_start(cellpb, False)
        column.set_attributes(cellpb, pixbuf=column_id_pix)
        column.pack_start(celltext, False)
        column.set_attributes(celltext, text=column_id_text)
        
        column.set_resizable(True)
        column.set_sort_column_id(column_id_text)
        self.treeviewPrinters.append_column(column)
        
    def __init_printer_list_columns(self):
        """Initialize printer list widget."""
        self.__add_list_column_text(
                    pslmessage.COLUMN_TEXT_NAME, INDEX_LIST_NAME, False)
        self.__add_list_column_pix(pslmessage.COLUMN_TEXT_STATUS, 
                    INDEX_LIST_STATUS_ICON, INDEX_LIST_STATUS_TEXT)
        self.__add_list_column_text(
                    pslmessage.COLUMN_TEXT_MODEL, INDEX_LIST_MODEL, False)
        self.__add_list_column_text(
                    pslmessage.COLUMN_TEXT_URI, INDEX_LIST_URI, True)
        self.treeviewPrinters.set_model(self.printer_list_data)
    
    def __initialize_list(self):
        """Initialize printer list."""
        self.printer_list_data.clear()
        for printer in self.__get_list():
            if printer[INDEX_LIST_NAME] is not None:
                self.printer_list_data.append(printer)
    
    def __get_list(self):
        """Get printers from CUPS in the PC.
        
        Return value:
        Tuple -- Tuple for adding printer to the list.
                ListStore obejct's append method can use this tuple directly.
 
        """
        printers_list = []
        try:
            all_printer_info = printerinfo.get_printer_list()
        except(IOError, MemoryError):
            all_printer_info = []
        for i in all_printer_info:
            # Add initial status to gotten list. 
            printer_status = list(i)
            printer_status.insert(INDEX_LIST_STATUS_ICON, 
                                  self.__status_icon_warning)
            printer_status.insert(INDEX_LIST_STATUS_TEXT, 
                                  pslstatusdefs.MSG_PSL_UNKNOWN)
            
            # Change driver name to model name if support driver.
            model = printer_status[INDEX_LIST_MODEL]
            support_model = \
                self.__psl_model.is_supported_driver_name(model)
            if support_model:
                printer_status[INDEX_LIST_MODEL] = \
                    self.__psl_model.get_model_name_from_driver_name(model)
                
            printers_list.append(tuple(printer_status))
            
        return tuple(printers_list)
        
    def __get_printer_model(self):
        """Get printer model name from the list.
        
        Return values:
        Printer model name -- If printer model get from list.
        None -- If printer model not get from list.
        
        """
        row = self.treeviewPrinters.get_selection().get_selected()
        if row[1]:
            printer_model = self.printer_list_data.get_value(
                                                row[1], INDEX_LIST_MODEL)
        else:
            printer_model = None
        
        return printer_model
    
    def __open_setting_page_by_browser(self):
        """Open web browser to show printer setting page."""
        row = self.treeviewPrinters.get_selection().get_selected()
        if row[1]:
            uri = self.printer_list_data.get_value(row[1], INDEX_LIST_URI)
            ip_address = pslmisc.get_ip_address_from_uri(uri)
        else:
            self.__err_dlg.show_error_dialog(
                                pslmessage.MSG_PSL_WEB_NOT_START)
            return

        port_number = self.__psl_model.get_port_number()
        if port_number == 80:
            url = URL_HTTP + ip_address
        elif port_number == 443:
            url = URL_HTTPS + ip_address
        else:
            url = URL_HTTP + ip_address + ':' + str(port_number)
        
        if webbrowser.launch_browser(url) == False:
            self.__err_dlg.show_error_dialog(
                                pslmessage.MSG_PSL_WEB_NOT_START)
            
    def __update_list(self, info_list):
        """Update all printer's status in printer list.
        
        Argument:
        info_list -- Printer status dictionary list 
                     contains printer status registered on CUPS.
                     
        """
        # Printer in a new list is update, not one is deleted.
        for printer in self.printer_list_data:
            printer_name = self.printer_list_data.get_value(printer.iter, 
                                                            INDEX_LIST_NAME)
            for index, info in enumerate(info_list):
                if printer_name == info[psldefs.KEY_INFO_NAME]:
                    self.__update_printer_from_info(printer, info)
                    # Delete used status.
                    del info_list[index]
                    break
            else:
                gtk.gdk.threads_enter()
                self.printer_list_data.remove(printer.iter)
                gtk.gdk.threads_leave()

        self.__add_printers_from_printer_status_list(info_list)
        
        gtk.gdk.threads_enter()
        self.treeviewPrinters.grab_focus()
        self.on_treeviewPrinterList_cursor_changed(self.treeviewPrinters)

        self.__buttonRefresh.set_sensitive(True)
        gtk.gdk.threads_leave()
        
    def __update_printer(self, info):
        """Update status of specified printer.
        
        Argument:
        info -- Information dictionary contains printer status.
        
        """
        for printer in self.printer_list_data:
            printer_name = self.printer_list_data.get_value(
                                printer.iter, 
                                INDEX_LIST_NAME)
            if printer_name == info[psldefs.KEY_INFO_NAME]:
                # Update matched printer if existing, or delete it if not.
                if info[psldefs.KEY_INFO_EXIST]:
                    self.__update_printer_from_info(printer, info)
                else:
                    gtk.gdk.threads_enter()
                    self.printer_list_data.remove(printer.iter)
                    gtk.gdk.threads_leave()
                break
        else:
            if info[psldefs.KEY_INFO_EXIST]:
                self.__add_printer_from_info(info)
                
        gtk.gdk.threads_enter()
        self.treeviewPrinters.grab_focus()
        self.on_treeviewPrinterList_cursor_changed(self.treeviewPrinters)
        gtk.gdk.threads_leave()
                        
    def __add_printers_from_printer_status_list(self, info_list):
        """Add printers to printer list from printer status list.
        
        Argument:
        info_list -- Information list for add.
        
        """
        for info in info_list:
            if info[psldefs.KEY_INFO_NAME] is not None:
                self.__add_printer_from_info(info)
                
    def __add_printer_from_info(self, info):
        """Add printer to printer list from information dictionary.
        
        Argument:
        info -- Information dictionary for add.
        
        """
        new_row = self.__get_row_from_info(info)
        gtk.gdk.threads_enter()
        self.printer_list_data.append(new_row)
        gtk.gdk.threads_leave()
            
    def __update_printer_from_info(self, row, info):
        """Update specified row printer from information dictionary .
        
        Arguments:
        row -- Row of printer list to update status.
        info -- Information dictionary for update.
        
        """
        new_row = self.__get_row_from_info(info)
        gtk.gdk.threads_enter()
        self.printer_list_data.set(row.iter,
                                   INDEX_LIST_STATUS_TEXT,
                                   new_row[INDEX_LIST_STATUS_TEXT],
                                   INDEX_LIST_STATUS_ICON,
                                   new_row[INDEX_LIST_STATUS_ICON],
                                   INDEX_LIST_MODEL,
                                   new_row[INDEX_LIST_MODEL],
                                   INDEX_LIST_URI,
                                   new_row[INDEX_LIST_URI])
        gtk.gdk.threads_leave()

    def __get_row_from_info(self, info):
        """Get tuple contains printer name, status icon, status text, 
        model name, device URI to add ListStore.
        
        Argument:
        info -- Information to make tuple.
        
        Return value:
        Tuple contains name, status icon, status text, model name, device URI.
        
        """
        name = info[psldefs.KEY_INFO_NAME]
        printer_status = info[psldefs.KEY_INFO_STATUS]
        model = info[psldefs.KEY_INFO_MODEL]
        device_uri = info[psldefs.KEY_INFO_URI]
        
        # Get status text and icon.
        if printer_status:
            status_id = printer_status[KEY_STATUS_STATUS]
        else:
            status_id = None
        status = _get_status_text_and_icon_from_status_num(status_id)
        if status:
            status_text = status[0]
            status_icon_id = status[1]
        else:
            status_text = pslstatusdefs.MSG_PSL_UNKNOWN
            status_icon_id = pslstatusdefs.ID_ICON_YELLOW
        if status_icon_id == pslstatusdefs.ID_ICON_GREEN:
            status_icon = self.__status_icon_ready
        elif status_icon_id == pslstatusdefs.ID_ICON_YELLOW:
            status_icon = self.__status_icon_warning
        else:
            status_icon = self.__status_icon_error
        
        row = (name, status_icon, status_text, model, device_uri)
        return row
    
