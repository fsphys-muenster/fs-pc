"""
  This class is used to launch web browser.

  (C) Fuji Xerox Co., Ltd. 2010
 
  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:
  1. Redistributions of source code must retain the above copyright
     notice, this list of conditions and the following disclaimer.
  2. Redistributions in binary form must reproduce the above copyright
     notice, this list of conditions and the following disclaimer in the
     documentation and/or other materials provided with the distribution.
  3. Neither the name of Fuji Xerox Co., Ltd. nor the names of its
     contributors may be used to endorse or promote products derived from
     this software without specific prior written permission.
  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
  POSSIBILITY OF SUCH DAMAGE.
"""

try:
    import os
    import re
    
    from common.defs import PATH_DLST_BIN
except:
    raise # Exception code is written in parent module.

# Define the information for launch browser.
PATH_XDG_OPEN = PATH_DLST_BIN + 'xdg-open'

# Define characters for sanitize.
CHAR_DOUBLE_QUOTE = '"'
CHAR_SANITIZED_DOUBLE_QUOTE = r'\"'

def launch_browser(url_address):
    """Launch the system default web browser.
    
    Argument:
    url_address -- URL address string to show.
    
    Return Values:
    True -- Succeed to launch browser.
    False -- Failed to launch browser or URL address is invalid.
    """
    if url_address is None:
        return False
    
    if not isinstance(url_address, basestring):
        return False
    
    pattern = re.compile(CHAR_DOUBLE_QUOTE)
    sanitized_url = pattern.sub(CHAR_SANITIZED_DOUBLE_QUOTE, url_address)
    
    result = os.system(PATH_XDG_OPEN + ' "' + sanitized_url + '"')
    
    if result == 0:
        return True
    else:
        return False
        