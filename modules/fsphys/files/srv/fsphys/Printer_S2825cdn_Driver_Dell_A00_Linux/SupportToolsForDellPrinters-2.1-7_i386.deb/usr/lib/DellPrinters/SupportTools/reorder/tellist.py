"""
  This class is used to managing the telephone number list file.

  (C) Fuji Xerox Co., Ltd. 2010-2012
 
  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:
  1. Redistributions of source code must retain the above copyright
     notice, this list of conditions and the following disclaimer.
  2. Redistributions in binary form must reproduce the above copyright
     notice, this list of conditions and the following disclaimer in the
     documentation and/or other materials provided with the distribution.
  3. Neither the name of Fuji Xerox Co., Ltd. nor the names of its
     contributors may be used to endorse or promote products derived from
     this software without specific prior written permission.
  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
  POSSIBILITY OF SUCH DAMAGE.
"""

try:
    import fcntl
    import xml.dom.minidom
    import xml.dom

    from common.defs import PATH_DLST_ETC
    from common import managexml, checkchartype
    from reorder import tellistdefs
except:
    raise # Exception code is written in parent module.

# Define reorder_phone.xml format.
FILE_TEL_LIST = 'reorder_phone.xml'
TAG_REORDER_PHONE = 'ReorderPhone'

TAG_PHONE_LIST = 'PhoneList'
TAG_PHONE = 'Phone'
TAG_PHONE_ID = 'ID'
TAG_NUMBER = 'Number'
TAG_LOCALE = 'Locale'
TAG_LOCALE_ID = 'LocaleID'
TAG_LOCALE_NAME = 'LocaleName'

TAG_PRODUCT_LIST = 'ProductList'
TAG_PRODUCT = 'Product'
TAG_NAME = 'Name'
TAG_PRODUCT_ID = 'ID'

# Define dictionary of telephone number list.  
DIC_KEY_COUNTRY_ID = 'country_id'
DIC_KEY_TEL_NUMBER = 'tel_number'
DIC_KEY_LOCALES = 'locales'
DIC_KEY_LOCALE_NAME = 'locale_name'
DIC_KEY_LOCALE_ID = 'locale_id'
DIC_KEY_MODEL_NAME = 'model_name'
DIC_KEY_COUNTRY_IDS = 'country_ids'

# Define locale id format
PREFIX_LOCALE_ID = '0x'
PREFIX_LOCALE_ID_URL_PARAM = '0000'

class TelList:
    """Manage the telephone number list file."""
    
    def __init__(self, filename = PATH_DLST_ETC + FILE_TEL_LIST):
        """Load telephone number list file.
        
        Argument:
        filename -- Full path of telephone number list.
                    if not specified, use default.
        
        Exceptions:
        IOError -- Failed to load the file.
        ValueError -- When the file contain incorrect value.
        """
        self.tel_list = []
        self.phone_list = []
        self.product_list = []
        xml_file = None
        
        try:
            xml_file = open(filename, 'r')
            fcntl.flock(xml_file.fileno(), fcntl.LOCK_SH)
            xml_tel_list = xml.dom.minidom.parse(xml_file)
            
        finally:
            if xml_file:
                xml_file.close()
        
	xml_tel_list_root = xml_tel_list.documentElement
        
        xml_tel_list_phone_list = managexml.get_named_child_nodes(
                                        xml_tel_list_root, 
                                        TAG_PHONE_LIST)
        xml_tel_list_phones = managexml.get_named_child_nodes(
                                        xml_tel_list_phone_list[0], 
                                        TAG_PHONE)
        self._load_phone_list_from_xml(xml_tel_list_phones)  
            
        xml_tel_list_product_list = managexml.get_named_child_nodes(
                                    xml_tel_list_root, 
                                    TAG_PRODUCT_LIST)
        xml_tel_list_products = managexml.get_named_child_nodes(
                                    xml_tel_list_product_list[0], 
                                    TAG_PRODUCT)
        self._load_product_list_from_xml(xml_tel_list_products)  
            
    def _load_phone_list_from_xml(self, phone_node_list):
        """Read product list datas from XML node, and set to menber
        variable.
        
        Argument:
        phone_node_list -- List of Phone node in tellist.xml file.
        
        Exception:
        ValueError -- Phone nodes contains invalid data.
        """
        for phone in phone_node_list:
            country_id = managexml.get_text_list(phone, TAG_PHONE_ID)
            tel_number = managexml.get_text_list(phone, TAG_NUMBER)
	    xml_tel_list_locales = managexml.get_named_child_nodes(
                                        phone, 
                                        TAG_LOCALE)
            if len(country_id) != 1 or len(tel_number) != 1:
                raise ValueError
	    self.__check_country_id(country_id[0])
            locales_buffer = []
            for locale in xml_tel_list_locales:
                locale_id = managexml.get_text_list(locale, TAG_LOCALE_ID)
                locale_name = managexml.get_text_list(locale, TAG_LOCALE_NAME)
                if len(locale_name) != 1:
                    raise ValueError
                if len(locale_id) != 0 and len(locale_id) != 1:
                    raise ValueError
                checkchartype.check_alphabet_with_under_bar(locale_name[0])
                if len(locale_id) == 0:
                    locale_dict = {DIC_KEY_LOCALE_NAME: locale_name[0],
                                   DIC_KEY_LOCALE_ID: None}
                else:
                    checkchartype.check_hex(locale_id[0])
                    locale_dict = \
                        {DIC_KEY_LOCALE_NAME: locale_name[0],
                         DIC_KEY_LOCALE_ID: '%08X' % int(locale_id[0], 16)}
                locales_buffer.append(locale_dict)
            if len(locales_buffer) < 1:
                raise ValueError

            self.phone_list.append({DIC_KEY_COUNTRY_ID: country_id[0],
                            DIC_KEY_TEL_NUMBER: tel_number[0],
                            DIC_KEY_LOCALES: locales_buffer})	
        
    def _load_product_list_from_xml(self, product_node_list):
        """Read product list datas from XML node, and set to menber
        variable.
        
        Argument:
        product_node_list -- List of Product node in tellist.xml file.
        
        Exception:
        ValueError -- Product nodes contains invalid data.
        """
        for product in product_node_list:
            product_names = managexml.get_text_list(product, TAG_NAME)
            country_ids = managexml.get_text_list(product, TAG_PRODUCT_ID)
            
            if len(country_ids) < 1:
                raise ValueError

            for country_id in country_ids:
		print "country_id before check is %s\n" % country_id
                self.__check_country_id(country_id)
                print "country_id after check is %s\n" % country_id

            outputted_products = []

            for product_name in product_names:
                checkchartype.check_alphanumeric_with_space(product_name)
                if product_name in outputted_products:
                    continue
                outputted_products.append(product_name)
            
                self.product_list.append({DIC_KEY_MODEL_NAME: product_name,
                                          DIC_KEY_COUNTRY_IDS: country_ids})
            
    def copy_from_tellist(self, src):
        """Copy members data from source.
        
        Argument:
        src -- Source data to copy to myself.
        """
        if isinstance(src, TelList):
            self.tel_list = src.tel_list
            self.phone_list = src.phone_list
            self.product_list = src.product_list
            
    def set_tellist_for_selected_model(self, model_name):
        """Set Telephone list for specified printer model.

        Argument:
        model_name -- Printer model name to set current telephone list.
        
        Exception:
        ValueError -- Specified printer model is not supported.
        """
        current_tel_list = []
        
        for product in self.product_list:
            if product[DIC_KEY_MODEL_NAME] == model_name:
                country_id_list = product[DIC_KEY_COUNTRY_IDS]
                break
        else:
            self.tel_list = []
            raise ValueError
            
        for country_id in country_id_list:
            for phone in self.phone_list:
                if phone[DIC_KEY_COUNTRY_ID] == country_id:
                    current_tel_list.append(phone)
                    break
        self.tel_list = current_tel_list
        
    def get_list_of_tel_number_with_country(self):
        """Get the list of telephone number and country name
        
        Return value:
        Telephone number list
        """
        tel_list = []
        for tel in self.tel_list:
            if tel[DIC_KEY_COUNTRY_ID] in tellistdefs.COUNTRY_NAME_TABLE:
                country_name = \
                    tellistdefs.COUNTRY_NAME_TABLE[tel[DIC_KEY_COUNTRY_ID]]
            else:
                country_name = tel[DIC_KEY_COUNTRY_ID]
            
            tel_list.append(
                tel[DIC_KEY_TEL_NUMBER] + ' - ' + country_name)
            
        return tel_list
    
    def get_index_from_locale(self, locale_name):
        """Get the index number of telephone list specified locale.
        
        Argument:
        locale_name -- Locale name to get the index.
        
        Return value:
        Index number
        """
        index = 0
        for tel in self.tel_list:
            for dic_locale in tel[DIC_KEY_LOCALES]:
                if locale_name.startswith(dic_locale[DIC_KEY_LOCALE_NAME]):
                    return index
            index += 1
        
        raise ValueError

    def get_locale_id_from_locale_name(self, locale_name):
        """Get locale ID for specified locale name.
        
        Argument:
        locale_name -- Locale name to get locale ID.
        
        Return value:
        Locale ID -- Specified locale ID from locale name.
        
        Exception:
        ValueError -- If locale_name is not supported locale. 
        """
        for phone in self.phone_list:
            for dic_locale in phone[DIC_KEY_LOCALES]:
                if locale_name.startswith(dic_locale[DIC_KEY_LOCALE_NAME]):
                    return dic_locale[DIC_KEY_LOCALE_ID]
        else:
            raise ValueError

    def get_teldict_from_index(self, index):
        """ Get telephone dictionary of the present model by index.
        
        Arguments:
        index -- Index to get telephone dictionary.
        
        Return value:
        Telephone dictionary -- Dictionary located at the index.
        
        Exception:
        IndexError -- If the index is out of bound.
        """
        if index >= 0:
            return self.tel_list[index]
        else:
            raise IndexError
        
    def get_index_from_country_id(self, country_id):
        """ Get index number of telephone list specified the country id.
        
        Arguments:
        country_id -- Country id to get the index number.
        
        Return value:
        Index number -- Index numnber indicates specified country id.
        
        Exception:
        ValueError -- If no elements found.
        """
        index = 0
        for tel in self.tel_list:
            if tel[DIC_KEY_COUNTRY_ID] == country_id:
                return index
            index += 1
        
        raise ValueError
        
    def is_same_telephone(self, origin_dict):
        """Check whether there is no differences in telephone number.
    
        Return Value:
        True -- If these are same.
        False -- If some differences are found.
        """
        if origin_dict is not None:
            for tel_dict in self.tel_list:
                if (tel_dict[DIC_KEY_COUNTRY_ID] == 
                                            origin_dict[DIC_KEY_COUNTRY_ID]):
                    if (tel_dict[DIC_KEY_TEL_NUMBER] == 
                                            origin_dict[DIC_KEY_TEL_NUMBER]):
                        return True
                    else:
                        return False
            
        return False
        
    def __check_country_id(self, string):   # pylint: disable-msg=R0201
        """Check format of country ID value.
        Following characters, and space is permitted in the country ID.
        a-z A-Z _
        
        Argument:
        string -- String to check.
        
        Exception:
        ValueError -- When string is invalid.
        """
        checkchartype.check_string(string, '[^a-zA-Z\-_ ]')
