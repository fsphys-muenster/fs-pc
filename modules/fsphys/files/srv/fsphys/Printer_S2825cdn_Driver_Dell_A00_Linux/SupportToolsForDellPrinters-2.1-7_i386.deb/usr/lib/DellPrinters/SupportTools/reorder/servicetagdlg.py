"""
  This class is used to show service tag input dialog.

  (C) Fuji Xerox Co., Ltd. 2010
 
  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:
  1. Redistributions of source code must retain the above copyright
     notice, this list of conditions and the following disclaimer.
  2. Redistributions in binary form must reproduce the above copyright
     notice, this list of conditions and the following disclaimer in the
     documentation and/or other materials provided with the distribution.
  3. Neither the name of Fuji Xerox Co., Ltd. nor the names of its
     contributors may be used to endorse or promote products derived from
     this software without specific prior written permission.
  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
  POSSIBILITY OF SUCH DAMAGE.
"""

try:
    import gtk
    import gtk.glade
    
    import common.defs
    from common.defs import PATH_DLST_RESOURCE
    from common import preventsamewindow, checkchartype, msgdlg
    from reorder import smsmessage
except:
    raise # Exception code is written in parent module.

# define information for gui controls.
FILE_GLADE = 'servicetagdlg.glade'
FILE_ICON_48x48 = 'dlsms_icon_dlsms_48x48_32.png'
FILE_ICON_16x16 = 'dlsms_icon_dlsms_16x16_32.png'
COLOR_WHITE = 'white'

# define for service tag.
DEFAULT_SERVICE_TAG = '000'
BLANK_SERVICE_TAG = ''
                           
class ServiceTagDlg(preventsamewindow.PreventSameWindow):
    """Show service tag input dialog."""
    
    WINDOW_ATOM_NAME_OF_SERVICETAGDLG = \
        'SupportToolsForDellPrinters_reorder_ServiceTagDlg'
    
    def __init__(self, model_name, start_type):
        """Constructor of this class.
        
        Arguments:
        model_name -- Printer model name to show in the title bar.
        start_type -- Start type name, standard or fixed.
        """
        
        self.__service_tag = ""
        self.__cancel_flag = True
        
        preventsamewindow.PreventSameWindow.__init__(self)
        
        # Check if this program is already running.
        window_atom_name = self.WINDOW_ATOM_NAME_OF_SERVICETAGDLG + '_' + \
                           model_name + '_' + start_type
        self.set_window_atom_name(window_atom_name)
        if self.is_existing():
            self.move_forward()
            return
        
        glade = PATH_DLST_RESOURCE + FILE_GLADE
        self.widget_tree = gtk.glade.XML(glade)
        self.windowMain = self.widget_tree.get_widget('windowMain')
        self.windowMain.realize()
        self.register_window_atom(self.windowMain.window.xid)

        self.err_dlg = msgdlg.MsgDialog(smsmessage.MSG_SMS_TITLE_ERR_DLG,
                                      PATH_DLST_RESOURCE + FILE_ICON_16x16,
                                      PATH_DLST_RESOURCE + FILE_ICON_48x48,
                                      self.windowMain)
        
        self.entryServiceTag = self.widget_tree.get_widget('entryServiceTag')
        
        self.entryServiceTag.grab_focus()
        
        self.windowMain.modify_bg(gtk.STATE_NORMAL, 
                                  gtk.gdk.color_parse(COLOR_WHITE))
        
        self.windowMain.set_title(model_name)
        
        self.windowMain.set_icon_list(
            gtk.gdk.pixbuf_new_from_file(PATH_DLST_RESOURCE + 
                                         FILE_ICON_16x16),
            gtk.gdk.pixbuf_new_from_file(PATH_DLST_RESOURCE + 
                                         FILE_ICON_48x48))
        
        self.event_dic = {
            "on_windowMain_destroy": self.quit,
            "on_buttonCancel_clicked": self.quit,
            "on_windowMain_key_press_event": self.esckey_clicked,
            "on_buttonOK_clicked": self.button_ok_clicked,
            "on_entryServiceTag_activate": self.button_ok_clicked}
        self.widget_tree.signal_autoconnect(self.event_dic)
        
        gtk.main()
        
    def button_ok_clicked(self, widget):
        """Check character format in entryServiceTag, 
        and set the  characters in __service_tag, 
        and close the dialog.
        Set False to __cancel_flag.
        If format is incorrect, show the error dialog.
        
        Argument:
        widget -- Instance of the clicked button.
        """
        service_tag = self.entryServiceTag.get_text()
        if service_tag == BLANK_SERVICE_TAG:
            service_tag = DEFAULT_SERVICE_TAG
            
        try:
            checkchartype.check_alphanumeric(service_tag)
        except:
            # Show the error message dialog.
            self.err_dlg.show_warning_dialog(
                smsmessage.MSG_SMS_SERVICETAG_INCORRECT)
            self.entryServiceTag.grab_focus()
        else:
            self.__service_tag = service_tag
            self.__cancel_flag = False
            self.quit(widget)
        
    def get_service_tag(self):
        """Get the service tag.
        
        Return value:
        service tag -- Characters input in service tag entry.
        """
        return self.__service_tag
        
    def get_cancel_flag(self):
        """Get the cancel flag.
        
        Return Value:
        True -- If other than OK button is clicked.
        False -- If OK button is clicked.
        """
        return self.__cancel_flag
        
    def quit(self, widget):  # pylint: disable-msg=W0613
        """Close the dialog and quit main loop.
        
        Argument:
        widget -- Instance of the clicked button.
        """
        self.delete_window_atom()
        self.windowMain.destroy()
        gtk.main_quit()
        
    def esckey_clicked(self, widget, event):
        """Quit the service tag input dialog when esc-key is clicked.
        
        Arguments:
        widget -- A object of windowMain.
        event -- A event object of on_windowMain_key_press_event.
        """
        if event.keyval == common.defs.KEY_CODE_ESC:
            self.quit(widget)
            