"""
  This class is used to show setting dialog.

  (C) Fuji Xerox Co., Ltd. 2010
 
  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:
  1. Redistributions of source code must retain the above copyright
     notice, this list of conditions and the following disclaimer.
  2. Redistributions in binary form must reproduce the above copyright
     notice, this list of conditions and the following disclaimer in the
     documentation and/or other materials provided with the distribution.
  3. Neither the name of Fuji Xerox Co., Ltd. nor the names of its
     contributors may be used to endorse or promote products derived from
     this software without specific prior written permission.
  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
  POSSIBILITY OF SUCH DAMAGE.
"""

try:
    import gtk
    import gtk.glade
    import pygtk
    pygtk.require("2.0")

    from common.defs import PATH_DLST_RESOURCE
    from common import urllist, msgdlg, defs, checkchartype, settingconfig
    from psl import pslmessage, psldefs
except:
    raise  # Exception code is written in parent module.

FILE_GLADE = 'dlsettings.glade'

class SettingDialog:  # pylint: disable-msg=R0902
    """Show the setting dialog."""   
    
    def __init__(self, model, polling_thread, parent):
        """Show the setting dialog.
        
        Arguments:
        model -- Instance of PSLModel class.
        polling_thread -- Instance of PollingThread class.
        parent -- Printer Selection window.
        
        Exception:
        IOError -- Failed to load URL list file.
        ValueError -- URL list file is invalid.
        
        """
        self.__model = model
        self.__polling_thread = polling_thread
        
        # Create instance of message box class.
        self.err_dlg = msgdlg.MsgDialog(
                            pslmessage.MSG_PSL_SETTINGS_TITLE_ERR_DLG,
                            defs.PATH_DLST_RESOURCE + psldefs.FILE_ICON_16x16,
                            defs.PATH_DLST_RESOURCE + psldefs.FILE_ICON_48x48,
                            parent)
        
        try:
            self.url_list = urllist.URLList()
        except (IOError, ValueError):
            self.err_dlg.show_error_dialog(
                                pslmessage.MSG_PSL_READ_URL_LIST_FAIL)
            return
        
        # Reload values from setting file for change by CRA.
        try:
            self.__reload_settings()
        except (ValueError, IOError):
            self.err_dlg.show_warning_dialog(
                                pslmessage.MSG_PSL_READ_SETTING_FILE_FAIL)
        
        glade = PATH_DLST_RESOURCE + FILE_GLADE
        self.__widget_tree = gtk.glade.XML(glade)
        self.__windowSettings = self.__widget_tree.get_widget(
                                                        'windowSettings')
        self.__checkbuttonRegularlyUpdate = self.__widget_tree.get_widget(
                                                'checkbuttonRegularlyUpdate')
        self.__editInterval = self.__widget_tree.get_widget('editInterval')
        self.__labelInterval = self.__widget_tree.get_widget('labelInterval')
        self.__labelIntervalExtend = self.__widget_tree.get_widget(
                                                    'labelIntervalExtend')
        self.__editPort = self.__widget_tree.get_widget('editPort')
        self.__editCommunity = self.__widget_tree.get_widget(
                                                        'editCommunityName')
        self.__comboboxReorderURL = self.__widget_tree.get_widget(
                                                    'comboboxReorderURL')
        self.__buttonOk = self.__widget_tree.get_widget('buttonOk')
        self.__buttonApply = self.__widget_tree.get_widget('buttonApply')
          
        self.__windowSettings.set_icon_list(
            gtk.gdk.pixbuf_new_from_file(PATH_DLST_RESOURCE + 
                                         psldefs.FILE_ICON_16x16),
            gtk.gdk.pixbuf_new_from_file(PATH_DLST_RESOURCE + 
                                         psldefs.FILE_ICON_48x48))

        # Hold setting file's value to set them if setting'll fail. 
        self.__setting_file_update = self.__model.get_polling()
        self.__setting_file_interval = self.__model.get_polling_time()
        self.__setting_file_port = self.__model.get_port_number()
        self.__setting_file_default_url = self.__model.get_default_url()
        self.__setting_file_community = self.__model.get_community_name()

        # Member value definitions.
        self.__focus_in_community = False
        self.__community_updated = False
        self.__community_name = None

        # Widgets are initialized.
        for url in self.url_list.get_url_address_list():
            self.__comboboxReorderURL.append_text(url)
        self.__set_initial_value()
        self.__buttonApply.set_sensitive(False)
        self.__buttonOk.grab_focus()
        
        event_dic = {
            "on_windowSettings_destroy": self.on_buttonCancel_clicked,
            "on_windowSettings_key_press_event": 
                                self.on_windowSettings_key_press_event,
            "on_buttonOk_clicked": self.on_buttonOk_clicked,
            "on_checkbuttonRegularlyUpdate_clicked": 
                                self.on_checkbuttonRegularlyUpdate_clicked,
            "on_buttonCancel_clicked": self.on_buttonCancel_clicked,
            "on_buttonApply_clicked": self.on_buttonApply_clicked,
            "on_editInterval_changed": self.on_settings_changed,
            "on_editPort_changed": self.on_settings_changed,
            "on_editInterval_insert_text": 
                                self.on_NumberEditbox_insert_text,
            "on_editPort_insert_text": 
                                self.on_NumberEditbox_insert_text,
            "on_editCommunityName_focus_in_event": 
                                self.on_editCommunityName_focus_in_event,
            "on_editCommunityName_focus_out_event": 
                                self.on_editCommunityName_focus_out_event,
            "on_editCommunityName_insert_text": 
                                self.on_editCommunityName_insert_text,
            "on_comboboxReorderURL_changed": self.on_settings_changed}
        self.__widget_tree.signal_autoconnect(event_dic)

        # Create instance of modal message box class.
        del self.err_dlg
        self.err_dlg = msgdlg.MsgDialog(
                            pslmessage.MSG_PSL_SETTINGS_TITLE_ERR_DLG,
                            defs.PATH_DLST_RESOURCE + psldefs.FILE_ICON_16x16,
                            defs.PATH_DLST_RESOURCE + psldefs.FILE_ICON_48x48,
                            self.__windowSettings)
        
        gtk.main()
        

    def __set_initial_value(self):
        """ Set initial value in UI. """

        # Set parameters of UI. 
        self.__checkbuttonRegularlyUpdate.set_active(
                                        self.__setting_file_update)
        self.__change_interval_ui_status(self.__setting_file_update)
        
        self.__editInterval.set_text(str(self.__setting_file_interval))
        self.__editInterval.set_alignment(1.0)
        
        self.__editPort.set_text(str(self.__setting_file_port))
        self.__editPort.set_alignment(1.0)
        
        default_url = self.__model.get_default_url()
        self.__comboboxReorderURL.set_active(
                        self.url_list.get_index_from_url_name(default_url))

        # Set '0's to community name edit box.
        # The string length is same of community name.
        community_len = self.__model.get_community_name_len()
        self.__editCommunity.set_text('0' * community_len)
        
    
    def __change_interval_ui_status(self, active):
        """Change interval widgets status if checked or not.
        
        Argument:
        active -- True if checked. False if not checked.
        
        """
        if active:
            self.__labelInterval.set_sensitive(True)   
            self.__editInterval.set_sensitive(True)
            self.__labelIntervalExtend.set_sensitive(True)
        else:
            self.__labelInterval.set_sensitive(False)   
            self.__editInterval.set_sensitive(False)
            self.__labelIntervalExtend.set_sensitive(False)
            
    def close_setting_dialog(self):
        """Close setting dialog"""
        self.__windowSettings.destroy()
        gtk.main_quit()

    def on_checkbuttonRegularlyUpdate_clicked(self, button):
        """Change interval widgets status when it is clicked. 
        
        Argument:
        button -- instance of checkbutton.
        
        """
        active = button.get_active()
        self.__change_interval_ui_status(active)
        self.__buttonApply.set_sensitive(True)
            
    def on_buttonOk_clicked(self, button):  # pylint: disable-msg=W0613
        """Save settings and close dialog.
        
        Argument:
        button -- instance of buttonOk
        
        Exception:
        IOError -- Failed to save settings.
        ValueError -- Showed warning which settings are invalid.
        
        """
        try:
            self.save_settings()
        except ValueError:
            return  # Don't close the dialog if failed setting.
        except IOError:
            pass # Close the dialog if failed saving to file.
        
        self.close_setting_dialog()
    
    def on_buttonCancel_clicked(self, button):  # pylint: disable-msg=W0613
        """Close setting dialog and cancel settings.
        
        Argument:
        button -- instance of buttonCancel
        
        """
        self.close_setting_dialog()
    
    def on_windowSettings_key_press_event(  # pylint: disable-msg=W0613
            self, widget, event):
        """Quit setting dialog when Esc-key is clicked.
        
        Arguments:
        widget -- A object of windowMain.
        event -- A event object of on_windowSettings_key_press_event.
        
        """
        if event.keyval == defs.KEY_CODE_ESC:
            self.close_setting_dialog()
    
    def on_buttonApply_clicked(self, button):  # pylint: disable-msg=W0613
        """Save settings.
        
        Argument:
        button -- instance of buttonApply
        
        Exception:
        IOError -- Failed to save settings.
        ValueError -- Showed warning which settings are invalid.
        
        """
        try:
            self.save_settings()
        except (IOError, ValueError):
            return  # Don't close the dialog if failed setting.

        self.__buttonApply.set_sensitive(False)
        self.__buttonOk.grab_focus()
        
    def on_settings_changed(self, widget):  # pylint: disable-msg=W0613
        """Be enable apply button when any setting changed.
        
        Argument:
        widget -- instance of setting changed widget.
        
        """
        self.__buttonApply.set_sensitive(True)
        
    def on_NumberEditbox_insert_text(   # pylint: disable-msg=W0613, R0201
                    self, editable, new_text, 
                    new_text_length, 
                    position):
        """ Check input value only number in editInterval and editPort.
        
        Arguments:
        editable -- A widget that received insert_text event.
        new_text -- text input.
        new_text_length -- length of input text.
        position -- position of input.
        
        """
        for char in new_text:
            if (ord(char) < ord('0') or ord(char) > ord('9')):
                editable.stop_emission("insert_text")
        
    def on_editCommunityName_focus_in_event(    # pylint: disable-msg=W0613
            self, widget, event):
        """Delete string in community name if that is focused.
        
        Arguments:
        widget -- instance of editCommunityName.
        event -- A event object of on_editCommunityName_focus_in_event.
        
        """
        self.__community_name = self.__editCommunity.get_text()
        self.__editCommunity.set_text("")
        self.__focus_in_community = True
    
    def on_editCommunityName_focus_out_event(   # pylint: disable-msg=W0613
            self, widget, event):
        """Show community name in edit box if user does not change it and 
        focus out.
        
        Arguments:
        widget -- instance of editCommunityName.
        event -- A event object of on_editCommunityName_focus_out_event.
        
        """
        self.__focus_in_community = False
        if "" == self.__editCommunity.get_text():
            self.__editCommunity.set_text(self.__community_name)
        else:
            self.__community_updated = True
    
    def on_editCommunityName_insert_text(   # pylint: disable-msg=W0613
                    self, editable, new_text, 
                    new_text_length, position):
        """Change a flag if user insert text to community name.
        
        Arguments:
        editable -- A widget that received insert_text event.
        new_text -- text input.
        new_text_length -- length of input text.
        position -- position of input.
        
        """
        if self.__focus_in_community:
            try:
                checkchartype.check_displayable(new_text)
                self.__buttonApply.set_sensitive(True)
            except ValueError:
                editable.stop_emission("insert_text")
        
    def save_settings(self):
        """Save settings which customize on UI by user.
            
        Exception:
        IOError -- Failed to save settings.
        ValueError -- Settings are invalid.
            
        """
        update = self.__checkbuttonRegularlyUpdate.get_active()
        self.__model.set_polling(update)
        
        if update:
            try:
                interval = self.__editInterval.get_text()
                self.__model.set_polling_time(int(interval))
            except ValueError:
                self.err_dlg.show_warning_dialog(
                    pslmessage.MSG_PSL_INTERVAL_CHECK_FAIL)
                self.__editInterval.grab_focus()
                raise
        
        try:
            port = self.__editPort.get_text()
            self.__model.set_port_number(int(port))
        except ValueError:
            self.err_dlg.show_warning_dialog(
                                pslmessage.MSG_PSL_PORT_CHECK_FAIL)  
            self.__editPort.grab_focus()         
            raise
        
        try:
            if self.__community_updated:
                community = self.__editCommunity.get_text()
                self.__model.set_community_name(community)
        except ValueError:
            self.err_dlg.show_warning_dialog(
                            pslmessage.MSG_PSL_COMMUNITY_NAME_CHECK_FAIL)
            self.__editCommunity.grab_focus()
            raise 
        
        default_url = self.url_list.get_url_name_from_index(
                                    self.__comboboxReorderURL.get_active())
        self.__model.set_default_url(default_url)

        # save file
        try:
            self.__model.save_config()
        except IOError:
            self.err_dlg.show_error_dialog(
                                pslmessage.MSG_PSL_SAVE_SETTING_FILE_FAIL)
            self.__model.set_polling(self.__setting_file_update)
            self.__model.set_polling_time(int(self.__setting_file_interval))
            self.__model.set_port_number(int(self.__setting_file_port))
            self.__model.set_default_url(self.__setting_file_default_url)
            self.__model.set_encoded_community_name(
                                                self.__setting_file_community)
            raise
        
        self.__polling_thread.set_setting_update(
                                        self.__model.get_polling(), 
                                        self.__model.get_polling_time(), 
                                        self.__model.get_community_name())
        
        self.__setting_file_update = self.__model.get_polling()
        self.__setting_file_interval = self.__model.get_polling_time()
        self.__setting_file_port = self.__model.get_port_number()
        self.__setting_file_default_url = self.__model.get_default_url()
        self.__setting_file_community = self.__model.get_community_name()

    def __reload_settings(self):
        """Load the setting file from user home directory,
        and set loaded values to PSLModel class instance.
        If failed to load, values is not set.
        
        Exceptions:
        IOError -- Failed to load the file.
        ValueError -- When the file contains incorrect value.
            
        """
        setting_conf = settingconfig.SettingConfig()
        setting_conf.load_config()
        polling = setting_conf.get_polling()
        polling_time = setting_conf.get_polling_time()
        port_number = setting_conf.get_port_number()
        default_url = setting_conf.get_default_url()
        community_name = setting_conf.get_community_name()
        
        self.__model.set_polling(polling)
        self.__model.set_polling_time(polling_time)
        self.__model.set_port_number(port_number)
        self.__model.set_default_url(default_url)
        self.__model.set_encoded_community_name(community_name)
        