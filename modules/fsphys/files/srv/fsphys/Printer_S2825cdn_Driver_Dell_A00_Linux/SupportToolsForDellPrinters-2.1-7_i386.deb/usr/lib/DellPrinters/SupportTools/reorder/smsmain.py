"""
  This class is used to control Supplies Management System.

  (C) Fuji Xerox Co., Ltd. 2010-2012
 
  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:
  1. Redistributions of source code must retain the above copyright
     notice, this list of conditions and the following disclaimer.
  2. Redistributions in binary form must reproduce the above copyright
     notice, this list of conditions and the following disclaimer in the
     documentation and/or other materials provided with the distribution.
  3. Neither the name of Fuji Xerox Co., Ltd. nor the names of its
     contributors may be used to endorse or promote products derived from
     this software without specific prior written permission.
  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
  POSSIBILITY OF SUCH DAMAGE.
"""

try:
    from common import defs, webbrowser, msgdlg
    from reorder import smsdlg, servicetagdlg, smsmodel, smsmessage
    from reorder import reordermisc
except:
    raise # Exception code is written in parent module.

# Define for error smsmessage.
ERR_DLG_MINIMUM_WIDTH = 330

# Define file names.
FILE_ICON_48x48 = 'dlsms_icon_dlsms_48x48_32.png'
FILE_ICON_16x16 = 'dlsms_icon_dlsms_16x16_32.png'

# Define ATOM name string when status fixed start.
FIXED_ATOM_NAME = 'Fixed'

# Defile Locale ID Key for URL params.
KEY_LOCALE_NUMBER = 'LC'

# Define Printer ID Information
MIN_PRNID_LEN = 7
SLICE_END_PRNID_NAME = 5
INDEX_PRNID_SEPARATOR = 5
SLICE_START_PRNID_VALUE = 6

def generate_url(url_address, status_info):
    """Generate URL from URL address and status information.
    
    Arguments:
    url_address -- URL address string.
    status_info -- Printer status information to set URL parameters.
    
    Return values:
    URL address -- When succeed to generate URL.
    None -- When failed to generate URL.
    """
    if not url_address:
        return None
    
    if not status_info:
        return url_address
    
    return_value = url_address
    
    chain_char = '?'
    i = 0
    for status_name in status_info.keys():
        if status_info[status_name]:
            return_value += chain_char + \
                            status_name + \
                            '=' + \
                            status_info[status_name]
            i += 1
        if i == 1:
            chain_char = '&'
    
    return return_value

def get_printer_id_value(printer_id_param):
    """Separate printer ID value from printer ID command line parameter.
    
        Argument:
        printer_id_param -- Printer ID command line parameter.
        
        Return Value:
        Printer ID value -- Separated value from command line parameter.
    
        Exception:
        ValueError -- When printer ID parameter is invalid value.
    """
    if (len(printer_id_param) < MIN_PRNID_LEN or 
        printer_id_param[:SLICE_END_PRNID_NAME] != defs.PARAM_PRINTER_ID or 
        printer_id_param[INDEX_PRNID_SEPARATOR] != '='):
        raise ValueError
    return printer_id_param[SLICE_START_PRNID_VALUE:]

class SMSMain:
    """Control Supplies Management System."""
    
    def set_parent_of_msgdlg(self, parent):
        """Set parent window of message dialog.
        
        Argument:
        parent -- parent window's instance of message dialog.
                  None means message dialog hasn't parent.
        """
        del self.err_dlg
        self.err_dlg = msgdlg.MsgDialog(
                            smsmessage.MSG_SMS_TITLE_ERR_DLG,
                            defs.PATH_DLST_RESOURCE + FILE_ICON_16x16,
                            defs.PATH_DLST_RESOURCE + FILE_ICON_48x48,
                            parent)
               
    def __init__(self):
        """Constructor of this class."""
        self.sms_model = None
        self.sms_dlg = None
        self.err_dlg = msgdlg.MsgDialog(
                            smsmessage.MSG_SMS_TITLE_ERR_DLG,
                            defs.PATH_DLST_RESOURCE + FILE_ICON_16x16,
                            defs.PATH_DLST_RESOURCE + FILE_ICON_48x48)
        
        try:
            self.sms_model = smsmodel.SMSModel()
        except:
            self.err_dlg.show_error_dialog(smsmessage.MSG_SMS_START_FAIL)
            raise
        
        try:
            self.sms_model.load_config()
            self.sms_model.load_cra_config()
        except:
            self.err_dlg.show_warning_dialog(
                smsmessage.MSG_SMS_LOAD_SETTING_FAIL)
        
    def launch(self, params):
        """
        Execute standard start, or fixed start according to params.
        
        Argument:
        params -- Command line parameters of dlsms.py
        """
        # First element of params is executed file name.
        # Start with no command line parameter, len(params) become 1.
        if len(params) == 1:
            self.__launch_without_parameter()
        else:
            self.__launch_with_parameter(params)
        
    def __launch_without_parameter(self):
        """Execute standard start."""
        self.sms_dlg = smsdlg.SMSDlg(self, self.sms_model)
        
    def __launch_with_parameter(self, params):
        """
        Execute fixed start.
        
        Argument:
        params -- Command line parameters of dlsms.py
        """
        if not params or not isinstance(params, list) or len(params) <= 1:
            self.err_dlg.show_error_dialog(smsmessage.MSG_SMS_START_FAIL)
            return
        
        url_name = self.sms_model.get_default_url()
        url_address = \
            self.sms_model.get_url_address_from_url_name(url_name)
        model_name = None
        try:
            printer_id = get_printer_id_value(params[1])
            model_name = self.sms_model.get_model_name_from_printer_id(
                            printer_id)
            self.sms_model.load_status_info_from_commandline(params[2:])
        except:
            self.err_dlg.show_error_dialog(smsmessage.MSG_SMS_START_FAIL)
            return
            
        # If service tag is not specified, show service tag input dialog.
        service_tag = self.sms_model.get_service_tag()
        if not service_tag and url_name == defs.URL_NAME_REGULAR:
            model_number = self.sms_model.get_printer_model_number()
            service_tag_dlg = \
                servicetagdlg.ServiceTagDlg(model_name, FIXED_ATOM_NAME)
                
            if service_tag_dlg.get_cancel_flag():
                return
            
            # Load status information file using service tag.
            service_tag = service_tag_dlg.get_service_tag()
            try:
                self.sms_model.load_status_info_from_file(service_tag)
                self.sms_model.set_service_tag(service_tag)
                self.sms_model.set_printer_model_number(model_number)
            except ValueError:
                self.err_dlg.show_error_dialog(
                    smsmessage.MSG_SMS_STATUS_INCORRECT)
                return
            except:
                self.err_dlg.show_error_dialog(
                    smsmessage.MSG_SMS_STATUS_LOAD_FAIL)
                return
            
            printer_info = self.sms_model.get_status_info()
        elif url_name == defs.URL_NAME_REGULAR:
            printer_info = self.sms_model.get_status_info()
        else:
            printer_info = None
            
        if not self.browse_order_site_with_params(url_address, printer_info):
            self.err_dlg.show_error_dialog(smsmessage.MSG_SMS_BROWSE_FAIL)
            
    def browse_order_site(self, printer_model_index, url_index, service_tag):
        """
        Launch browser, and show the supplies order site.
        
        Arguments:
        printer_model_index -- Selected index number 
                               in printer model combobox.
        url_index -- Selected index number in URL combobox.
        service_tag -- Service tag number input in service tag dialog.
        """
        url_name = self.sms_model.get_url_name_from_index(url_index)
        try:
            # If URL name is incorrect, not save to the file.
            self.sms_model.set_default_url(url_name)
            self.sms_model.save_config()
        except:
            self.err_dlg.show_error_dialog(smsmessage.MSG_SMS_URL_SAVE_FAIL)
            
        # When regular URL, get printer status.
        if url_name == defs.URL_NAME_REGULAR:
            try:
                self.sms_model.load_status_info_from_file(service_tag)
                model_number = self.sms_model.get_model_number_from_index(
                                                        printer_model_index)
                self.sms_model.set_printer_model_number(model_number)
            except ValueError:
                self.err_dlg.show_error_dialog(
                    smsmessage.MSG_SMS_STATUS_INCORRECT)
                return
            except:
                self.err_dlg.show_error_dialog(
                    smsmessage.MSG_SMS_STATUS_LOAD_FAIL)
                return
            printer_info = self.sms_model.get_status_info()
        else:
            printer_info = None
            
        url_address = self.sms_model.get_url_address_from_index(url_index)
        if not self.browse_order_site_with_params(url_address, printer_info):
            self.err_dlg.show_error_dialog(smsmessage.MSG_SMS_BROWSE_FAIL)
            
    def browse_order_site_with_params(self, url_address, params):
        """Browse the supplies reorder site with URL parameters.
        
        Arguments:
        url_address -- URL address string
        params -- Printer status information for URL parameters.
        
        Return values:
        True -- Succeed to browse.
        False -- Failed to browse.
        """
        if params:
            locale_name = self.get_locale_id()
            params[KEY_LOCALE_NUMBER] = locale_name
            url_address = generate_url(url_address, params)
            if not url_address:
                return False
        
        result = webbrowser.launch_browser(url_address)
        return result
    
    def get_locale_id(self):
        """ Get locale ID correspond to locale name of current locale.
        
        Return Value
        Locale ID of current locale -- If current locale have locale ID.
        Locale ID of defualt locale -- If current locale dont have locale ID.
        """
        # If locale name not get correctly, set default locale.
        locale_name = reordermisc.get_locale()
        try:
            locale_param = \
                self.sms_model.get_locale_id_from_locale_name(locale_name)
        except ValueError:
            locale_param = \
                self.sms_model.get_locale_id_from_locale_name(
                    defs.DEFAULT_LOCALE)
            
        return locale_param
