"""
  This class is to manage prnmodel.xml.

  (C) Fuji Xerox Co., Ltd. 2010
 
  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:
  1. Redistributions of source code must retain the above copyright
     notice, this list of conditions and the following disclaimer.
  2. Redistributions in binary form must reproduce the above copyright
     notice, this list of conditions and the following disclaimer in the
     documentation and/or other materials provided with the distribution.
  3. Neither the name of Fuji Xerox Co., Ltd. nor the names of its
     contributors may be used to endorse or promote products derived from
     this software without specific prior written permission.
  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
  POSSIBILITY OF SUCH DAMAGE.
"""

try:
    import fcntl
    import xml.dom.minidom
    import xml.dom

    from common.defs import PATH_DLST_ETC
    from common import managexml, checkchartype
except:
    raise # Exception code is written in parent module.

# Define prnmodel.xml format.
FILE_PRNMODEL = 'prnmodel.xml'
TAG_PRINTER = 'Printer'
TAG_PRINTER_ID = 'PrinterID'
TAG_MODEL_NUMBER = 'ModelNumber'
TAG_MODEL_NAME = 'ModelName'
TAG_DRIVER_NAME = 'DriverName'
TAG_DEVICE_NAME = 'DeviceName'
TAG_COLOR_DEVICE = 'ColorDevice'

# Define dictionary of printer model list.  
DIC_KEY_PRINTER_ID = 'printer_id'
DIC_KEY_MODEL_NUMBER = 'model_number'
DIC_KEY_MODEL_NAME = 'model_name'
DIC_KEY_DRIVER_NAME = 'driver_name'
DIC_KEY_DEVICE_NAME = 'device_name'
DIC_KEY_COLOR_DEVICE = 'color_device'


class PrinterModelList:
    """Manage the printer model list."""
    
    def __init__(self, filename=PATH_DLST_ETC + FILE_PRNMODEL):
        """Load printer model file.
        
        Argument:
        filename -- Full path of printer model list.
                    If you don't specify it, this method uses default path.
        
        Exceptions:
        IOError -- When can't load the file.
        ValueError -- When the file contains invalid values.
        
        """
        self.__printer_list = []
        
        xml_file = None
        try:
            xml_file = open(filename, 'r')
            fcntl.flock(xml_file.fileno(), fcntl.LOCK_SH)
            xml_prnmodel = xml.dom.minidom.parse(xml_file)
        finally:
            if xml_file:
                xml_file.close()
                
        xml_prnmodel_root = xml_prnmodel.documentElement
        xml_prnmodel_printerlist = managexml.get_named_child_nodes(
                                        xml_prnmodel_root, 
                                        TAG_PRINTER)
        
        for printer in xml_prnmodel_printerlist:
            printer_id = managexml.get_text_list(printer, TAG_PRINTER_ID)
            model_number = managexml.get_text_list(printer, TAG_MODEL_NUMBER)
            model_name = managexml.get_text_list(printer, TAG_MODEL_NAME)
            driver_name = managexml.get_text_list(printer, TAG_DRIVER_NAME)
            device_name = managexml.get_text_list(printer, TAG_DEVICE_NAME)
            color_device = managexml.get_text_list(printer, TAG_COLOR_DEVICE)

            if (len(model_number) != 1 or len(model_name) != 1 or 
                len(driver_name) <= 0 or len(device_name) != 1 or
                len(printer_id) != 1 or len(color_device) != 1):
                raise ValueError
            checkchartype.check_alphanumeric(printer_id[0])
            checkchartype.check_alphanumeric(model_number[0])
            checkchartype.check_alphanumeric_with_space(model_name[0])
            checkchartype.check_displayable(device_name[0])
	    checkchartype.check_alphanumeric(color_device[0])
	
            for i in driver_name:
                checkchartype.check_alphanumeric_with_space(i)
            
            self.__printer_list.append({DIC_KEY_PRINTER_ID:printer_id[0],
                            DIC_KEY_MODEL_NUMBER:model_number[0],
                            DIC_KEY_MODEL_NAME:model_name[0],
                            DIC_KEY_DRIVER_NAME:driver_name,
                            DIC_KEY_DEVICE_NAME:device_name[0],
			    DIC_KEY_COLOR_DEVICE:color_device[0]})
            
    def get_model_name_list(self):
        """Get printer model name list.
        
        Return value:
        String array of printer model name list.
        """
        model_name_list = []
        for printer in self.__printer_list:
            model_name_list.append(printer[DIC_KEY_MODEL_NAME])
            
        return model_name_list
    
    def get_model_number_from_driver_name(self, driver_name):
        """Get model number which matches driver name specified.
        
        Argument:
        driver_name -- Driver name.
        
        Return Value:
        Model number -- When driver name matches anything.
        
        Exception:
        ValueError -- When driver name matches nothing.
        
        """
        for printer in self.__printer_list:
            for dic_driver_name in printer[DIC_KEY_DRIVER_NAME]:
                if dic_driver_name == driver_name:
                    return printer[DIC_KEY_MODEL_NUMBER]
                
        raise ValueError
    
    def get_model_number_from_device_name(self, device_name):
        """Get model number which matches device name specified.
        
        Argument:
        device_name -- Device name.
        
        Return Value:
        Model number -- When device name matches anything.
        
        Exception:
        ValueError -- When device name matches nothing.
        
        """
        for printer in self.__printer_list:
            if printer[DIC_KEY_DEVICE_NAME] == device_name:
                return printer[DIC_KEY_MODEL_NUMBER]
                
        raise ValueError
        
    def get_model_number_from_index(self, index):
        """Get model number which matches index of the array.
        
        Argument:
        index -- Index of the array.
        
        Return Values:
        Model number
        
        """
        return  self.__printer_list[index][DIC_KEY_MODEL_NUMBER]
    
    def get_model_name_from_model_number(self, model_number):
        """Get model name which matches model number specified.
        
        Argument:
        model_number -- Model number.
        
        Return Value:
        Model name -- When model number matches anything.
        
        Exception:
        ValueError -- When model number matches nothing.
        
        """
        for printer in self.__printer_list:
            if printer[DIC_KEY_MODEL_NUMBER] == model_number:
                return printer[DIC_KEY_MODEL_NAME]
                
        raise ValueError
    
    def get_device_name_from_driver_name(self, driver_name):
        """Get device name which matches driver name specified.
        
        Argument:
        driver_name -- Driver name.
        
        Return Value:
        Device name -- When driver name matches anything.
        
        Exception:
        ValueError -- When driver name matches nothing.
        
        """
        for printer in self.__printer_list:
            for dic_driver_name in printer[DIC_KEY_DRIVER_NAME]:
                if dic_driver_name == driver_name:
                    return printer[DIC_KEY_DEVICE_NAME]
                
        raise ValueError
    
    def get_model_name_from_driver_name(self, driver_name):
        """Get model name which matches driver name specified.
        
        Argument:
        driver_name -- Driver name.
        
        Return Value:
        Model Name -- When driver name matches anything.
        
        Exception:
        ValueError -- When driver name matches nothing.
        
        """
        for printer in self.__printer_list:
            for dic_driver_name in printer[DIC_KEY_DRIVER_NAME]:
                if dic_driver_name == driver_name:
                    return printer[DIC_KEY_MODEL_NAME]
                
        raise ValueError
        
    def is_supported_driver_name(self, driver_name):
        """Check if driver name is supported or not.
        
        Argument:
        driver_name -- Driver name which is checked.
        
        Return Values:
        True -- Supported.
        False -- Not supported.
        
        """
        for printer in self.__printer_list:
            for dic_driver_name in printer[DIC_KEY_DRIVER_NAME]:
                if dic_driver_name == driver_name:
                    return True
                
        return False
    
    def is_supported_model_number(self, model_number):
        """Check if model number is supported or not.
        
        Argument:
        model_number -- Model number which is checked.
        
        Return Values:
        True -- Supported.
        False -- Not supported.
        
        """
        for printer in self.__printer_list:
            if printer[DIC_KEY_MODEL_NUMBER] == model_number:
                return True
            
        return False
    
    def get_printer_id_from_driver_name(self, driver_name):
        """Get printer ID which matches driver name specified.
        
        Argument:
        driver_name -- Driver name.
        
        Return Value:
        Printer ID -- When driver name matches anything.
        
        Exception:
        ValueError -- When model name matches nothing.
        
        """
        for printer in self.__printer_list:
            for dic_driver_name in printer[DIC_KEY_DRIVER_NAME]:
                if dic_driver_name == driver_name:
                    return printer[DIC_KEY_PRINTER_ID]
                
        raise ValueError
    
    def get_model_name_from_printer_id(self, printer_id):
        """Get model name which matches printer ID specified.
        
        Argument:
        printer_id -- Printer ID.
        
        Return Value:
        Model Name -- When printer ID matches anything.
        
        Exception:
        ValueError -- When printer ID matches nothing.
        
        """
        for printer in self.__printer_list:
            if printer[DIC_KEY_PRINTER_ID] == printer_id:
                return printer[DIC_KEY_MODEL_NAME]
                
        raise ValueError
    
    def get_color_device_from_driver_name(self, driver_name):
        """Get Color Device which matches driver name specified.
        
        Argument:
        driver_name -- Driver name.
        
        Return Value:
        Color Device -- When driver name matches anything.
        
        Exception:
        ValueError -- When driver name matches nothing.
        
        """
        for printer in self.__printer_list:
            for dic_driver_name in printer[DIC_KEY_DRIVER_NAME]:
                if dic_driver_name == driver_name:
                    return printer[DIC_KEY_COLOR_DEVICE]
                
        raise ValueError
     
    def get_color_device_from_model_name(self, model_name):
        """Get Color Device which matches model name specified.
        
        Argument:
        model_name -- Model name.
        
        Return Value:
        Color Device -- When driver name matches anything.
        
        Exception:
        ValueError -- When driver name matches nothing.
        
        """
        for printer in self.__printer_list:
		if printer[DIC_KEY_MODEL_NAME] == model_name:
			return printer[DIC_KEY_COLOR_DEVICE]

        raise ValueError
    
   
