"""
  This class is used to managing setting.xml.

  (C) Fuji Xerox Co., Ltd. 2010-2012
 
  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:
  1. Redistributions of source code must retain the above copyright
     notice, this list of conditions and the following disclaimer.
  2. Redistributions in binary form must reproduce the above copyright
     notice, this list of conditions and the following disclaimer in the
     documentation and/or other materials provided with the distribution.
  3. Neither the name of Fuji Xerox Co., Ltd. nor the names of its
     contributors may be used to endorse or promote products derived from
     this software without specific prior written permission.
  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
  POSSIBILITY OF SUCH DAMAGE.
"""

try:
    import os
    import shutil
    import fcntl
    import xml.dom.minidom
    import xml.dom
    import base64
    import binascii

    from common import defs, managexml, checkchartype, printerstatus
except:
    raise # Exception code is written in parent module.

# Define setting.xml format.
FILE_SETTING = 'setting.xml'
TAG_POLLING = 'Polling'
TAG_POLLING_TIME = 'PollingTime'
TAG_HTTP_PORT_NUMBER = 'HttpPortNumber'
TAG_COMMUNITY_NAME = 'CommunityName'
TAG_DEFAULT_URL = 'DefaultURL'
TAG_RESOLVE = 'Resolve'

# Define dictionary of __user_config and default.  
DIC_KEY_POLLING = 'polling'
DIC_KEY_POLLING_TIME = 'polling_time'
DIC_KEY_PORT_NUMBER = 'port_number'
DIC_KEY_COMMUNITY_NAME = 'community_name'
DIC_KEY_DEFAULT_URL = 'default_url'
DIC_KEY_RESOLVE = 'resolve'

DEFAULT_POLLING = True
DEFAULT_POLLING_TIME = 30
DEFAULT_PORT_NUMBER = 80
DEFAULT_COMMUNITY_NAME = 'tePF283I'     # 'public' encoded base64
DEFAULT_DEFAULT_URL = defs.URL_NAME_REGULAR
DEFAULT_RESOLVE = 0

MIN_POLLING_TIME = 15
MAX_POLLING_TIME = 600
HTTP_PORT_NUMBER = 80
HTTPS_PORT_NUMBER = 443
MIN_HTTP_PORT_NUMBER = 8000
MAX_HTTP_PORT_NUMBER = 9999
RESOLVE_V4_BEFORE_V6 = 0
RESOLVE_V6_BEFORE_V4 = 1
RESOLVE_V4 = 2
RESOLVE_V6 = 3

# Define XML file format same as FILE_SETTING in PATH_DLST_ETC.
FORMAT_CONFIG_XML = """\
<Setting>
  <Polling>""" + str(DEFAULT_POLLING) + """</Polling>
  <PollingTime> """ + str(DEFAULT_POLLING_TIME) + """</PollingTime>
  <HttpPortNumber>""" + str(DEFAULT_PORT_NUMBER) + """</HttpPortNumber>
  <CommunityName> """ + DEFAULT_COMMUNITY_NAME + """</CommunityName>
  <DefaultURL>""" + DEFAULT_DEFAULT_URL + """</DefaultURL>
  <Resolve>""" + str(DEFAULT_RESOLVE) + """</Resolve>
</Setting>
"""

# Define XML file encoding.
ENCODING_XML = 'UTF-8'

class SettingConfig:
    """Manage the setting file."""
    
    def __init__(self):
        """Initialize member."""
        self.__user_config = {
                DIC_KEY_POLLING:None, 
                DIC_KEY_POLLING_TIME:None, 
                DIC_KEY_PORT_NUMBER:None, 
                DIC_KEY_COMMUNITY_NAME:None, 
                DIC_KEY_DEFAULT_URL:None,
                DIC_KEY_RESOLVE:None}
        self.home_dir = os.path.expanduser(defs.PATH_DLST_HOME)
        self.filename = self.home_dir + FILE_SETTING 
        
    def load_config(self):
        """Load the setting file from user home directory.
        If the file is not found, this function copies the template file
        to user home directory.
        
        Exceptions:
        IOError -- Failed to load the file.
        ValueError -- When the file contains incorrect value.
        """
        try:
            if not os.access(self.filename, os.F_OK):
                self.__copy_template_config_file()
            self.__load_config_from_file()
        except:
            self.__set_default_config()
            raise
        
    def save_config(self):
        """Save the setting file.
        
        Exceptions:
        IOError -- Failed to save file.
        """
        xml_file = None
        xml_file_lock = None
        
        # Create XML object from format.
        xml_setting = xml.dom.minidom.parseString(FORMAT_CONFIG_XML)
        xml_setting_root = xml_setting.documentElement
        
        managexml.set_text(xml_setting_root, TAG_POLLING, 
                           self.__user_config[DIC_KEY_POLLING])
        managexml.set_text(xml_setting_root, TAG_POLLING_TIME, 
                           self.__user_config[DIC_KEY_POLLING_TIME])
        managexml.set_text(xml_setting_root, TAG_HTTP_PORT_NUMBER, 
                           self.__user_config[DIC_KEY_PORT_NUMBER])
        managexml.set_text(xml_setting_root, TAG_COMMUNITY_NAME, 
                           self.__user_config[DIC_KEY_COMMUNITY_NAME])
        managexml.set_text(xml_setting_root, TAG_DEFAULT_URL, 
                           self.__user_config[DIC_KEY_DEFAULT_URL])
        managexml.set_text(xml_setting_root, TAG_RESOLVE, 
                           self.__user_config[DIC_KEY_RESOLVE])
            
        try:
            # Open file with mode 'a' for get file lock before mode 'w'
            xml_file_lock = open(self.filename, 'a')
            fcntl.flock(xml_file_lock.fileno(), fcntl.LOCK_EX)
            xml_file = open(self.filename, 'w+')
            xml_setting.writexml(xml_file, encoding=ENCODING_XML)
            os.chmod(self.filename, defs.MOD_DLST_HOME_FILE)
        finally:
            if xml_file:
                xml_file.close()
            if xml_file_lock:
                xml_file_lock.close()
                
    def __load_config_from_file(self):
        """Load the setting file.
        
        Exceptions:
        IOError -- Failed to load file.
        ValueError -- When the file contains incorrect value.
        """
        xml_file = None
        
        try:
            xml_file = open(self.filename, 'r')
            fcntl.flock(xml_file.fileno(), fcntl.LOCK_SH)
            xml_setting = xml.dom.minidom.parse(xml_file)
        finally:
            if xml_file:
                xml_file.close()
                
        xml_setting_root = xml_setting.documentElement
        if not xml_setting_root:
            raise ValueError
        
        polling = managexml.get_text_list(xml_setting_root, TAG_POLLING)
        polling_time = managexml.get_text_list(xml_setting_root, \
                                               TAG_POLLING_TIME)
        http_port_number = managexml.get_text_list(xml_setting_root, 
                                                  TAG_HTTP_PORT_NUMBER)
        community_name = managexml.get_text_list(xml_setting_root, 
                                            TAG_COMMUNITY_NAME)
        default_url = managexml.get_text_list(xml_setting_root, \
                                              TAG_DEFAULT_URL)
        resolve = managexml.get_text_list(xml_setting_root, \
                                              TAG_RESOLVE)
            
        self.__check_polling(polling[0])
        self.__check_polling_time(int(polling_time[0]))
        self.__check_http_port_number(int(http_port_number[0]))
        self.__check_community_name_on_file(community_name[0])
        checkchartype.check_alphanumeric(default_url[0])
        self.__check_resolve(int(resolve[0]))
        
        if polling[0] == 'False':
            bool_polling = False
        else:
            bool_polling = True
            
        self.__user_config = {
                DIC_KEY_POLLING:bool_polling, 
                DIC_KEY_POLLING_TIME:int(polling_time[0]), 
                DIC_KEY_PORT_NUMBER:int(http_port_number[0]), 
                DIC_KEY_COMMUNITY_NAME:community_name[0], 
                DIC_KEY_DEFAULT_URL:default_url[0],
                DIC_KEY_RESOLVE:int(resolve[0])}
        
    def __copy_template_config_file(self):
        """Copy the template file to home directory.
        If home directory is not found, this method makes it.
        
        Exception:
        Throw all exception except when makedirs.
        """
        try:
            os.makedirs(self.home_dir, defs.MOD_DLST_HOME)
        except:  # pylint: disable-msg=W0704
            pass  # through exception when failed to make directory.
        
        src = open(defs.PATH_DLST_ETC + FILE_SETTING, 'r')
        fcntl.flock(src.fileno(), fcntl.LOCK_SH)
        dst_lock = open(self.filename, 'a')
        fcntl.flock(dst_lock.fileno(), fcntl.LOCK_EX)
        dst = open(self.filename, 'w')
        shutil.copyfileobj(src, dst)
        os.chmod(self.filename, defs.MOD_DLST_HOME_FILE)
        dst.close()
        dst_lock.close()
        src.close()
        
    def __set_default_config(self):
        """Set default configuration value to this member."""
        self.__user_config = {
                DIC_KEY_POLLING:DEFAULT_POLLING, 
                DIC_KEY_POLLING_TIME:DEFAULT_POLLING_TIME, 
                DIC_KEY_PORT_NUMBER:DEFAULT_PORT_NUMBER, 
                DIC_KEY_COMMUNITY_NAME:DEFAULT_COMMUNITY_NAME, 
                DIC_KEY_DEFAULT_URL:DEFAULT_DEFAULT_URL,
                DIC_KEY_RESOLVE:DEFAULT_RESOLVE}
        
    def get_default_url(self):
        """Get default URL.
        
        Return value:
        string of Default URL.
        """
        return self.__user_config[DIC_KEY_DEFAULT_URL]
        
    def set_default_url(self, url_name):
        """Set the specified URL to the member.
        
        Argument:
        url_name -- String of URL.
        
        Exception:
        ValueError -- When argument contains incorrect value.
        """
        checkchartype.check_alphanumeric(url_name)
        if url_name == '':
            raise ValueError
        
        self.__user_config[DIC_KEY_DEFAULT_URL] = url_name
        
    def get_polling(self):
        """Get setting of polling printer status.
        
        Return value:
        True -- Enable polling
        False -- Disable polling
        """
        return self.__user_config[DIC_KEY_POLLING]
        
    def set_polling(self, flag):
        """Set setting of polling printer status.
        
        Argument:
        flag -- Boolean of polling setting.
        
        Exception:
        ValueError -- When argument contains incorrect value.
        """
        if not isinstance(flag, bool):
            raise ValueError
        
        self.__user_config[DIC_KEY_POLLING] = flag
        
    def get_polling_time(self):
        """Get interval time of polling.
        
        Return value:
        Interval time.
        """
        return self.__user_config[DIC_KEY_POLLING_TIME]
        
    def set_polling_time(self, time):
        """Set interval time of polling.
        
        Argument:
        time -- Interval time of polling.
        
        Exception:
        ValueError -- When argument contains incorrect value.
        """
        self.__check_polling_time(time)
        self.__user_config[DIC_KEY_POLLING_TIME] = time
        
    def get_port_number(self):
        """Get port number to connect printer manage page.
        
        Return value:
        Port number.
        """
        return self.__user_config[DIC_KEY_PORT_NUMBER]
    
        
    def set_port_number(self, port_number):
        """Set port number to connect printer manage page.
        
        Argument:
        port_number -- Port number.
        
        Exception:
        ValueError -- When argument contains incorrect value.
        """
        self.__check_http_port_number(port_number)
        self.__user_config[DIC_KEY_PORT_NUMBER] = port_number

    def __get_community_name_on_file(self):
        """Get community name from file. Its encoded base64.
        
        Return value:
        String of encoded community name which is encoded base64 and 
        printerstatus.so.
        """
        return self.__user_config[DIC_KEY_COMMUNITY_NAME]
        
    def get_community_name(self):
        """Get community name for read to get printer status using SNMP.
        It's encoded by printerstatus.so.
        
        Return value:
        Binary string of encoded community name.
        """
        return base64.decodestring(str(self.__get_community_name_on_file()))
        
    def get_community_name_len(self):
        """Get length of community name.
        
        Return value:
        length of community name.
        """
        encoded_name_base64 = self.__get_community_name_on_file()
        encoded_name = base64.decodestring(str(encoded_name_base64))
        return printerstatus.get_length_of_community_name(encoded_name)


    def set_encoded_community_name(self, encoded_community_name):
        """Set encoded community name for read to get printer status 
        using SNMP.
        
        Argument:
        encoded_community_name -- Encoded community name for read.
        
        Attention:
        You usually should use set_community_name method.
        If you use this, you MUST specified validated encoded community name.
        Because this method doesn't check it.
        """
        encoded_name_base64 = base64.encodestring(encoded_community_name)

        # Delete '\n' at end added base64.encode string.
        encoded_name_base64_len = len(encoded_name_base64) - 1
        encoded_name_base64 = encoded_name_base64[:encoded_name_base64_len]
        
        self.__user_config[DIC_KEY_COMMUNITY_NAME] = encoded_name_base64
        

    def set_community_name(self, community_name):
        """Set community name for read to get printer status using SNMP.
        
        Argument:
        community_name -- Community name for read.
        
        Exception:
        ValueError -- When argument contains incorrect value.
        """
        self.__check_community_name(community_name)
        if community_name == '':
            raise ValueError
        
        # Encode community name.
        encoded_name = printerstatus.encode_community_name(community_name)
        self.set_encoded_community_name(encoded_name)
        
    def get_resolve(self):
        """Get flag how to resolve host name.
        
        Return value:
        Flag value how to resolve host name.
        """
        return self.__user_config[DIC_KEY_RESOLVE]
        
        
    def __check_polling(self, polling):  # pylint: disable-msg=R0201
        """Check format of polling value.
        
        Argument:
        polling -- Value to check.
        
        Exception:
        ValueError -- When argument contains incorrect value.
        """
        if polling != 'True' and polling != 'False':
            raise ValueError
        
    def __check_polling_time(self, time):  # pylint: disable-msg=R0201
        """Check format of polling time value.
        
        Argument:
        time -- Value to check.
        
        Exception:
        ValueError -- When argument contains incorrect value.
        """
        if time < MIN_POLLING_TIME or time > MAX_POLLING_TIME:
            raise ValueError
        
    def __check_http_port_number(self, http_port_number):  # pylint: disable-msg=R0201, C0301
        """Check format of http port number value.
        
        Argument:
        time -- Value to check.
        
        Exception:
        ValueError -- When argument contains incorrect value.
        """
        if ((http_port_number != HTTP_PORT_NUMBER) and 
            (http_port_number != HTTPS_PORT_NUMBER) and
            (http_port_number < MIN_HTTP_PORT_NUMBER or 
             http_port_number > MAX_HTTP_PORT_NUMBER)):
            raise ValueError
        
    def __check_community_name(self, community_name):  # pylint: disable-msg=R0201, C0301
        """Check format of community name value.
        
        Argument:
        community_name -- Value to check.
        
        Exception:
        ValueError -- When argument contains incorrect value.
        """
        checkchartype.check_displayable(community_name)

    def __check_community_name_on_file(self,      # pylint: disable-msg=R0201
                                       encoded_name_base64):
        """Check whether can decode the community name from base64 format
        or not.
        
        Argument:
        encoded_name_base64 -- Value to check.
        
        Exception:
        ValueError -- When failed to decode the community name.
        """ 
        try:
            base64.decodestring(str(encoded_name_base64))
        except binascii.Error:
            raise ValueError
        
    def __check_resolve(self, resolve): # pylint: disable-msg=R0201
        """Check format of flag how to resolve host name.
        
        Argument:
        resolve -- Value to check.
        
        Exception:
        ValueError -- When argument contains incorrect value.
        """
        if (resolve != RESOLVE_V4_BEFORE_V6 and
            resolve != RESOLVE_V6_BEFORE_V4 and
            resolve != RESOLVE_V4 and
            resolve != RESOLVE_V6):
            raise ValueError
        