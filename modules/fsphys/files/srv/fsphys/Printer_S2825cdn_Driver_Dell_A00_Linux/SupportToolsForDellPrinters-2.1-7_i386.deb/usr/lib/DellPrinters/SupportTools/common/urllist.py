"""
  This class is used to managing the URL list file.

  (C) Fuji Xerox Co., Ltd. 2010
 
  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:
  1. Redistributions of source code must retain the above copyright
     notice, this list of conditions and the following disclaimer.
  2. Redistributions in binary form must reproduce the above copyright
     notice, this list of conditions and the following disclaimer in the
     documentation and/or other materials provided with the distribution.
  3. Neither the name of Fuji Xerox Co., Ltd. nor the names of its
     contributors may be used to endorse or promote products derived from
     this software without specific prior written permission.
  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
  POSSIBILITY OF SUCH DAMAGE.
"""

try:
    import fcntl
    import xml.dom.minidom
    import xml.dom
    
    from common.defs import PATH_DLST_ETC
    from common import managexml, checkchartype
except:
    raise # Exception code is written in parent module.

# define reorder_url.xml format.
FILE_REORDER_URL = 'reorder_url.xml'
TAG_URL = 'URL'
TAG_NAME = 'Name'
TAG_ADDRESS = 'Address'

# define dictionary of URL list.  
DIC_KEY_URL_NAME = 'url_name'
DIC_KEY_URL_ADDRESS = 'url_address'


class URLList:
    """Manage the URL list file."""
    
    def __init__(self, filename=PATH_DLST_ETC + FILE_REORDER_URL):
        """Load the URL list file.
        
        Argument:
        filename -- URL list file full path name.
                    If you don't specify it, this method uses default path.
        
        Exceptions:
        IOError -- When failed to load the URL list file.
        ValueError -- When the incorrect URL is contained in the file.
        """
        self.__url_list = []
        xml_file = None
        
        try:
            xml_file = open(filename, 'r')
            fcntl.flock(xml_file.fileno(), fcntl.LOCK_SH)
            xml_url_list = xml.dom.minidom.parse(xml_file)
        finally:
            if xml_file:
                xml_file.close()

        xml_url_list_root = xml_url_list.documentElement
        xml_url_list_url = managexml.get_named_child_nodes(
                                            xml_url_list_root, 
                                            TAG_URL)
            
        for url in xml_url_list_url:
            url_name = managexml.get_text_list(url, TAG_NAME)
            url_address = managexml.get_text_list(url, TAG_ADDRESS)
                
            # Raise ValueError exception if these are invalid.
            if (len(url_name) != 1 or len(url_address) != 1):
                raise ValueError
            checkchartype.check_alphanumeric(url_name[0])
            checkchartype.check_url_address(url_address[0])
            
            self.__url_list.append({DIC_KEY_URL_NAME:url_name[0],
                            DIC_KEY_URL_ADDRESS:url_address[0]})
            
    def get_url_address_list(self):
        """Get the URL addresses as string array.
        
        Return value:
        String array contains all URL addresses.
        """
        url_address_list = []
        
        for url in self.__url_list:
            url_address_list.append(url["url_address"])
            
        return url_address_list
        
    def get_url_name_from_index(self, index):
        """Get the URL name specified the index number.
        
        Argument:
        index -- The index number of the url_list array.
        
        Return values:
        URL name
        """
        return self.__url_list[index][DIC_KEY_URL_NAME]
        
    def get_url_address_from_index(self, index):
        """Get the URL address specified the index number.
        
        Argument:
        index -- The index number of the url_list array.
        
        Return values:
        URL address
        """
        return self.__url_list[index][DIC_KEY_URL_ADDRESS]
        
    def get_url_address_from_url_name(self, url_name):
        """Get the URL address specified the URL name.
        
        Argument:
        url_name -- The name of the URL address to get.
        
        Return values:
        URL address -- When the specified URL exist.
        
        Exception:
        ValueError -- If no name match.
        """
        for url in self.__url_list:
            if url[DIC_KEY_URL_NAME] == url_name:
                return url[DIC_KEY_URL_ADDRESS]
            
        raise ValueError
        
    def get_index_from_url_name(self, url_name):
        """Get the index number of the url_list 
        specified the URL name.
        
        Argument:
        url_name -- The URL name of the index number to get.
        
        Return value:
        index number
        
        Exception:
        ValueError -- If no name match.
        """
        index = 0
        for url in self.__url_list:
            if url[DIC_KEY_URL_NAME] == url_name:
                return index
            index += 1
        
        raise ValueError
