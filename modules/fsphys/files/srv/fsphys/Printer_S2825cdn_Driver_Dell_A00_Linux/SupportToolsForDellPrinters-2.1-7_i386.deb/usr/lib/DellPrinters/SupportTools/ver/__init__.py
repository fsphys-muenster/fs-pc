"""
  ver package initialize.

  (C) Fuji Xerox Co., Ltd. 2010
 
  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:
  1. Redistributions of source code must retain the above copyright
     notice, this list of conditions and the following disclaimer.
  2. Redistributions in binary form must reproduce the above copyright
     notice, this list of conditions and the following disclaimer in the
     documentation and/or other materials provided with the distribution.
  3. Neither the name of Fuji Xerox Co., Ltd. nor the names of its
     contributors may be used to endorse or promote products derived from
     this software without specific prior written permission.
  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
  POSSIBILITY OF SUCH DAMAGE.
"""

try:
    import gettext
    import locale
    import os

    import common.defs
        
    # Set C to LC_MESSAGES to display UI by left justify.
    os.putenv(common.defs.ENV_LC_MESSAGES, common.defs.DEFAULT_LC_MESSAGES)

    import pygtk
    pygtk.require("2.0")
    import gtk
    import gtk.glade
except:
    raise # Exception code is written in parent module.

PACKAGE_NAME_VER = 'ver'

# setting internationalization.
try:
    locale.setlocale(locale.LC_ALL, '')
except:
    locale.setlocale(locale.LC_ALL, common.defs.DEFAULT_LOCALE_LANG)
gettext.bindtextdomain(PACKAGE_NAME_VER, common.defs.PATH_DLST_LOCALES)
gettext.textdomain(PACKAGE_NAME_VER)
gtk.glade.bindtextdomain(PACKAGE_NAME_VER, common.defs.PATH_DLST_LOCALES)
gtk.glade.textdomain(PACKAGE_NAME_VER)
