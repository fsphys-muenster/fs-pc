"""
  This class is to prevent same window on desktop.

  (C) Fuji Xerox Co., Ltd. 2010
 
  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:
  1. Redistributions of source code must retain the above copyright
     notice, this list of conditions and the following disclaimer.
  2. Redistributions in binary form must reproduce the above copyright
     notice, this list of conditions and the following disclaimer in the
     documentation and/or other materials provided with the distribution.
  3. Neither the name of Fuji Xerox Co., Ltd. nor the names of its
     contributors may be used to endorse or promote products derived from
     this software without specific prior written permission.
  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
  POSSIBILITY OF SUCH DAMAGE.
"""

try:
    import gtk
except:
    raise # Exception code is written in parent module.
    

class PreventSameWindow:
    """Prevent same window on desktop.
    You must call set_window_atom_name before calling other functions.
    
    """

    def __init__(self):
        """This class constructor."""
        self.__atom_name = ''
    
    def set_window_atom_name(self, atom_name):
        """Set window atom name.
        
        Argument:
        atom_name --  a unique name of window atom
        
        """
        self.__atom_name = atom_name

    def register_window_atom(self, xid):
        """Register a window atom which is prevented multiple running.
        
        Argument:
        xid -- a x window id which is integer.
        
        """
        # Put window xid into root window atom.
        root = gtk.gdk.get_default_root_window()
        window_atom = gtk.gdk.atom_intern(self.__atom_name, False)
        root.property_change(window_atom,
            gtk.gdk.atom_intern(
                'SupportToolsForDellPrinters_preventsamewindow', 
                False),
            32,
            gtk.gdk.PROP_MODE_REPLACE,
            [xid])

    def delete_window_atom(self):
        """Delete a window atom which is prevented multiple running."""
        root = gtk.gdk.get_default_root_window()
        window_atom = gtk.gdk.atom_intern(self.__atom_name, False)
        root.property_delete(window_atom)

    def __get_specified_window_xid(self):
        """Get xid of a window atom which is prevented multiple running.
        
        Return values:
        Integer -- xid
        None -- error
         
        """
        try:
            root = gtk.gdk.get_default_root_window()
            window_atom = gtk.gdk.atom_intern(self.__atom_name, False)
            prop = root.property_get(window_atom)
            if prop is not None:
                xid = prop[2]  # '2' is index of xid list in tuple.
                return long(xid[0])  # '0' is index of xid in list.
            
            return None
        except:
            return None
    
    def is_existing(self):
        """Check same window exists on desktop.
        
        Return values:
        True -- already exist.
        False -- not exist or error.
        
        """
        xid = self.__get_specified_window_xid()
        if xid is not None:
            # Check if window of xid is realized.
            window = gtk.gdk.window_foreign_new(xid)
            if window is not None:
                return True
        
        return False

    def move_forward(self):
        """Move a window to forward."""
        xid = self.__get_specified_window_xid()
        if xid is not None:
            window = gtk.gdk.window_foreign_new(xid)
            if window is not None:
                window.focus()
                while gtk.events_pending():
                    gtk.main_iteration()
