"""
  This file defines various functions used by all of PSL.

  (C) Fuji Xerox Co., Ltd. 2010
 
  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:
  1. Redistributions of source code must retain the above copyright
     notice, this list of conditions and the following disclaimer.
  2. Redistributions in binary form must reproduce the above copyright
     notice, this list of conditions and the following disclaimer in the
     documentation and/or other materials provided with the distribution.
  3. Neither the name of Fuji Xerox Co., Ltd. nor the names of its
     contributors may be used to endorse or promote products derived from
     this software without specific prior written permission.
  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
  POSSIBILITY OF SUCH DAMAGE.
"""
try:
    import re
except:
    raise # Exception code is written in parent module.

SCHEMA_SOCKET = 'socket://'
SCHEMA_LPD = 'lpd://'

REGEXP_IPV6_VERSION = 'v[0-9A-Fa-f]\.'
LEN_IPV6_VERSION = 3

def get_ip_address_from_uri(uri):
    """ Get IP Address from URI using LPD or Socket schema.
    
    Argument:
    uri -- Device URI
    
    Return Values:
    IP Address -- IP Address find in Device URI.
    None -- Device URI use schema except LPD or Socket.
    """
    if (uri[:len(SCHEMA_SOCKET)] == SCHEMA_SOCKET or
        uri[:len(SCHEMA_LPD)] == SCHEMA_LPD):
        if uri[:len(SCHEMA_SOCKET)] == SCHEMA_SOCKET:
            len_schema = len(SCHEMA_SOCKET)
        else:
            len_schema = len(SCHEMA_LPD)
        if (uri[len_schema] == '[' and
            ']' in uri) :   # Find a pair of brackets for IPv6.
            # Remove IPv6 version string if start with it.
            ipv6_ver_start_index = len_schema + 1
            ipv6_ver_end_index = ipv6_ver_start_index + LEN_IPV6_VERSION
            result = re.compile(REGEXP_IPV6_VERSION).match(
                uri[ipv6_ver_start_index:ipv6_ver_end_index])
            if result is not None:
                uri = uri[:ipv6_ver_start_index]+ uri[ipv6_ver_end_index:]
            # Replace zone ID delimiter from '+' of URI to '%' of URL.
            zone_id_index = uri.find('+')
            if -1 < zone_id_index:
                uri = uri[:zone_id_index] + '%' +uri[zone_id_index + 1:]
                
            end_index = uri.find(']') + 1
        else:
            index = 0
            for i in uri[len_schema:]:
                if (i == ":" or
                    i == "?" or
                    i == "/"):  # Find a delimiter after IP address.
                    end_index = len_schema + index
                    break
                else:
                    index += 1
            else:
                end_index = len(uri)
        ip_address = uri[len_schema:end_index]
    else:
        ip_address = None
        
    return ip_address
