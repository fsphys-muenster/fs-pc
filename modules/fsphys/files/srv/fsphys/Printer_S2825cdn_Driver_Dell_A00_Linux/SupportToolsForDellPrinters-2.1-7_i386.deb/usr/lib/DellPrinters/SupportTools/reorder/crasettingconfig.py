"""
  This class is used to managing cra_setting.xml.

  (C) Fuji Xerox Co., Ltd. 2010-2012
 
  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:
  1. Redistributions of source code must retain the above copyright
     notice, this list of conditions and the following disclaimer.
  2. Redistributions in binary form must reproduce the above copyright
     notice, this list of conditions and the following disclaimer in the
     documentation and/or other materials provided with the distribution.
  3. Neither the name of Fuji Xerox Co., Ltd. nor the names of its
     contributors may be used to endorse or promote products derived from
     this software without specific prior written permission.
  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
  POSSIBILITY OF SUCH DAMAGE.
"""

try:
    import os
    import shutil
    import fcntl
    import xml.dom.minidom
    import xml.dom
    import time
    import datetime

    from common import defs, managexml, checkchartype
except:
    raise # Exception code is written in parent module.

# Define cra_setting.xml format.
FILE_SETTING = 'cra_setting.xml'
TAG_UPDATE_PHONE_LIST = 'UpdatePhoneList'
TAG_PHONE_LIST_UPDATED_DATE = 'PhoneListUpdatedDate'
TAG_PHONE_LIST_UPDATE_INTERVAL = 'PhoneListUpdateInterval'
TAG_UPDATE_PHONE_LIST_SERVER_URL = 'UpdatePhoneListServerUrl'

# Define dictionary of __user_config and default.  
DIC_KEY_UPDATE_PHONE_LIST = 'update_phone_list'
DIC_KEY_PHONE_LIST_UPDATED_DATE = 'phone_list_updated_date'
DIC_KEY_PHONE_LIST_UPDATE_INTERVAL = 'phone_list_update_interval'
DIC_KEY_UPDATE_PHONE_LIST_SERVER_URL = 'update_phone_list_server_url'

DEFAULT_UPDATE_PHONE_LIST = True
DEFAULT_PHONE_LIST_UPDATED_DATE = None
DEFAULT_PHONE_LIST_UPDATE_INTERVAL = 0
DEFAULT_UPDATE_PHONE_LIST_SERVER_URL = "http://ftp.us.dell.com/printer/dell_printers_dtms_phonelist.xml"

# Define XML file format same as FILE_SETTING in PATH_DLST_ETC.
# pylint: disable-msg=C0301
FORMAT_CONFIG_XML = """\
<CRASetting>
  <UpdatePhoneList>""" + str(DEFAULT_UPDATE_PHONE_LIST) + """</UpdatePhoneList>
  <PhoneListUpdatedDate> """ + str(DEFAULT_PHONE_LIST_UPDATED_DATE) + """</PhoneListUpdatedDate>
  <PhoneListUpdateInterval>""" + str(DEFAULT_PHONE_LIST_UPDATE_INTERVAL) + """</PhoneListUpdateInterval> 
  <UpdatePhoneListServerUrl> """ + str(DEFAULT_UPDATE_PHONE_LIST_SERVER_URL) + """</UpdatePhoneListServerUrl>
</CRASetting>
"""
FORMAT_CONFIG_XML_WITHOUT_UPDATED_DATE = """\
<CRASetting>
  <UpdatePhoneList>""" + str(DEFAULT_UPDATE_PHONE_LIST) + """</UpdatePhoneList>
  <PhoneListUpdateInterval>""" + str(DEFAULT_PHONE_LIST_UPDATE_INTERVAL) + """</PhoneListUpdateInterval> 
  <UpdatePhoneListServerUrl> """ + str(DEFAULT_UPDATE_PHONE_LIST_SERVER_URL) + """</UpdatePhoneListServerUrl>
</CRASetting>
"""
# pylint: enable-msg=C0301

# Define XML file encoding.
ENCODING_XML = 'UTF-8'

class CRASettingConfig:
    """Manage cra_setting.xml."""
    
    def __init__(self):
        """Initialize member."""
        self.__user_config = {
                DIC_KEY_UPDATE_PHONE_LIST:None, 
                DIC_KEY_PHONE_LIST_UPDATED_DATE:None, 
                DIC_KEY_PHONE_LIST_UPDATE_INTERVAL:None, 
                DIC_KEY_UPDATE_PHONE_LIST_SERVER_URL:None}
        self.__home_dir = os.path.expanduser(defs.PATH_DLST_HOME)
        self.__filename = self.__home_dir + FILE_SETTING 
        
    def load_cra_config(self):
        """Load cra_setting.xml from user home directory.
        If the file is not found, this function copies the template file
        to user home directory.
        
        Exceptions:
        IOError -- Failed to load the file.
        ValueError -- When the file contains incorrect value.
        """
        try:
            if not os.access(self.__filename, os.F_OK):
                self.__copy_template_config_file()
            self.__load_config_from_file()
        except:
            self.__set_default_config()
            raise
       
    def save_cra_config(self):
        """Save cra_setting.xml.
        
        Exception:
        IOError -- Failed to save file.
        """
        xml_file = None
        xml_file_lock = None
        
        # Create XML object from format.
        if self.__user_config[DIC_KEY_PHONE_LIST_UPDATED_DATE] is not None:
            xml_setting = xml.dom.minidom.parseString(FORMAT_CONFIG_XML)
        else:
            xml_setting = xml.dom.minidom.parseString(
                                    FORMAT_CONFIG_XML_WITHOUT_UPDATED_DATE)

        xml_setting_root = xml_setting.documentElement
        
        managexml.set_text(xml_setting_root, TAG_UPDATE_PHONE_LIST, 
                           self.__user_config[DIC_KEY_UPDATE_PHONE_LIST])
        if self.__user_config[DIC_KEY_PHONE_LIST_UPDATED_DATE] is not None:
            updated_date = self.__user_config[DIC_KEY_PHONE_LIST_UPDATED_DATE]
            updated_date = datetime.date.strftime(updated_date, "%Y-%m-%d")
            managexml.set_text(xml_setting_root, TAG_PHONE_LIST_UPDATED_DATE, 
                               updated_date)
        managexml.set_text(xml_setting_root, TAG_PHONE_LIST_UPDATE_INTERVAL, 
                    self.__user_config[DIC_KEY_PHONE_LIST_UPDATE_INTERVAL])
        managexml.set_text(xml_setting_root, TAG_UPDATE_PHONE_LIST_SERVER_URL,
                    self.__user_config[DIC_KEY_UPDATE_PHONE_LIST_SERVER_URL])
        
        try:
            # Open file with mode 'a' for get file lock before mode 'w'
            xml_file_lock = open(self.__filename, 'a')
            fcntl.flock(xml_file_lock.fileno(), fcntl.LOCK_EX)
            xml_file = open(self.__filename, 'w+')
            xml_setting.writexml(xml_file, encoding=ENCODING_XML)
            os.chmod(self.__filename, defs.MOD_DLST_HOME_FILE)
        finally:
            if xml_file:
                xml_file.close()
            if xml_file_lock:
                xml_file_lock.close()

    def __load_config_from_file(self):
        """Load cra_setting.xml.
        
        Exceptions:
        IOError -- Failed to load file.
        ValueError -- When the file contains incorrect value.
        """
        xml_file = None
        
        try:
            xml_file = open(self.__filename, 'r')
            fcntl.flock(xml_file.fileno(), fcntl.LOCK_SH)
            xml_setting = xml.dom.minidom.parse(xml_file)
        finally:
            if xml_file:
                xml_file.close()
                
        xml_setting_root = xml_setting.documentElement
        if not xml_setting_root:
            raise ValueError
        
        update_phone_list = managexml.get_text_list(xml_setting_root, 
                                                    TAG_UPDATE_PHONE_LIST)
        try:
            phone_list_updated_date = managexml.get_text_list(
                                xml_setting_root, TAG_PHONE_LIST_UPDATED_DATE)
        except ValueError:
            # No PhoneListUpdateDate tag is acceptable and means 
            # phone list file have never been updated.
            phone_list_updated_date = None
                
        phone_list_update_interval = managexml.get_text_list(
                           xml_setting_root, TAG_PHONE_LIST_UPDATE_INTERVAL)
        update_phone_list_server_url = managexml.get_text_list(
                           xml_setting_root, TAG_UPDATE_PHONE_LIST_SERVER_URL)
            
        self.__check_update_phone_list(update_phone_list[0])
        if phone_list_updated_date is not None:
            self.__check_phone_list_updated_date(phone_list_updated_date[0])
            upd = time.strptime(phone_list_updated_date[0], '%Y-%m-%d')
            updated_date = datetime.date(upd[0], upd[1], upd[2])
        else:
            updated_date = None
        self.__check_phone_list_update_interval(
                                        int(phone_list_update_interval[0]))
        self.__check_update_phone_list_server_url(
                                        update_phone_list_server_url[0])
        
        if update_phone_list[0] == 'False':
            bool_update_phone_list = False
        else:
            bool_update_phone_list = True
            
        self.__user_config = {
                            DIC_KEY_UPDATE_PHONE_LIST:bool_update_phone_list, 
                            DIC_KEY_PHONE_LIST_UPDATED_DATE:updated_date, 
                            DIC_KEY_PHONE_LIST_UPDATE_INTERVAL:
                                        int(phone_list_update_interval[0]), 
                            DIC_KEY_UPDATE_PHONE_LIST_SERVER_URL:
                                        (update_phone_list_server_url[0])}

    def __copy_template_config_file(self):
        """Copy the template file to home directory.
        If home directory is not found, this method makes it.
        
        Exception:
        Throw all exception except when makedirs.
        """
        try:
            os.makedirs(self.__home_dir, defs.MOD_DLST_HOME)
        except:
            pass  # through exception when failed to make directory.
        
        src = open(defs.PATH_DLST_ETC + FILE_SETTING, 'r')
        fcntl.flock(src.fileno(), fcntl.LOCK_SH)
        dst_lock = open(self.__filename, 'a')
        fcntl.flock(dst_lock.fileno(), fcntl.LOCK_EX)
        dst = open(self.__filename, 'w')
        shutil.copyfileobj(src, dst)
        os.chmod(self.__filename, defs.MOD_DLST_HOME_FILE)
        dst.close()
        dst_lock.close()
        src.close()
        
    def __set_default_config(self):
        """Set default configuration value to this member."""
        self.__user_config = {
                              DIC_KEY_UPDATE_PHONE_LIST:
                                        DEFAULT_UPDATE_PHONE_LIST, 
                              DIC_KEY_PHONE_LIST_UPDATED_DATE:
                                        DEFAULT_PHONE_LIST_UPDATED_DATE, 
                              DIC_KEY_PHONE_LIST_UPDATE_INTERVAL:
                                        DEFAULT_PHONE_LIST_UPDATE_INTERVAL, 
                              DIC_KEY_UPDATE_PHONE_LIST_SERVER_URL:
                                        DEFAULT_UPDATE_PHONE_LIST_SERVER_URL}

    def get_update_phone_list(self):
        """Get flag of auto update for phone list file.
        
        Return value:
        True -- If auto update for phone list is enabled.
        False -- If auto update for phone list is not enabled.
        """
        return self.__user_config[DIC_KEY_UPDATE_PHONE_LIST]

    def set_update_phone_list(self, update_flag):
        """Set flag of auto update for phone list file.
        
        Argument:
        update_flag -- Flag whether auto update is enabled.
        
        Exception:
        ValueError -- When update_flag is not bool instance.
        """
        if not isinstance(update_flag, bool):
            raise ValueError
        
        self.__user_config[DIC_KEY_UPDATE_PHONE_LIST] = update_flag

    def get_phone_list_updated_date(self):
        """Get the date when auto update for phone list run.
        
        Return value:
        Date object -- The date when auto update run.
        """
        return self.__user_config[DIC_KEY_PHONE_LIST_UPDATED_DATE]

    def set_phone_list_updated_date(self, updated_date):
        """Set the date when auto update for phone list run.
        
        Argument:
        updated_date -- Date object indicates last updated date.
        
        Exception:
        ValueError -- When updated_date is not date instance.
        """
        if not isinstance(updated_date, datetime.date):
            raise ValueError
        
        self.__user_config[DIC_KEY_PHONE_LIST_UPDATED_DATE] = updated_date

    def get_phone_list_update_interval(self):
        """Get the update interval of phone list.
        
        Return value:
        Update interval for phone list.
        """
        return self.__user_config[DIC_KEY_PHONE_LIST_UPDATE_INTERVAL]

    def get_update_phone_list_server_url(self):
        """Get the server URL to update phone list file.
        
        Return value:
        Phone list server URL for phone list.
        """
        return self.__user_config[DIC_KEY_UPDATE_PHONE_LIST_SERVER_URL]
        
    def __check_update_phone_list(self, update_phone_list):  # pylint: disable-msg=R0201, C0301
        """Check format of update phone list flag.
        
        Argument:
        update_phone_list -- Value to check.
        
        Exception:
        ValueError -- When argument contains incorrect value.
        """
        if update_phone_list != 'True' and update_phone_list != 'False':
            raise ValueError
                
    def __check_phone_list_updated_date(self, phone_list_updated_date):  # pylint: disable-msg=R0201, C0301
        """Check format of phonelist updated date.
        
        Argument:
        phone_list_updated_date -- Value to check.
        
        Exception:
        ValueError -- When argument contains incorrect value.
        """
        if ((not isinstance(phone_list_updated_date, basestring)) or 
            (not phone_list_updated_date)):
            raise ValueError

    def __check_phone_list_update_interval(self, phone_list_update_interval):  # pylint: disable-msg=R0201, C0301
        """Check format of the interval of auto update.
        
        Argument:
        phone_list_update_interval -- Value to check.
        
        Exception:
        ValueError -- When phone_list_update_interval is less than 0.
        """
        if phone_list_update_interval < 0:
            raise ValueError

    def __check_update_phone_list_server_url(self, # pylint: disable-msg=R0201, C0301
                                             update_phone_list_server_url):  
        """Check format of the URL of phone list server.
        
        Argument:
        update_phone_list_server_url -- Value to check.
        
        Exception:
        ValueError -- When argument contains incorrect value.
        """
        checkchartype.check_url_address(update_phone_list_server_url)
        
        if not update_phone_list_server_url:
            raise ValueError
        
