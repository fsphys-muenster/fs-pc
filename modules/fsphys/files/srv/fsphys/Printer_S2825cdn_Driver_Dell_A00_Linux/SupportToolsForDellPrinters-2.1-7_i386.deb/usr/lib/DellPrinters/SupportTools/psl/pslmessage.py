"""
  This file defines messages used by Printer Selection.

  (C) Fuji Xerox Co., Ltd. 2010
 
  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:
  1. Redistributions of source code must retain the above copyright
     notice, this list of conditions and the following disclaimer.
  2. Redistributions in binary form must reproduce the above copyright
     notice, this list of conditions and the following disclaimer in the
     documentation and/or other materials provided with the distribution.
  3. Neither the name of Fuji Xerox Co., Ltd. nor the names of its
     contributors may be used to endorse or promote products derived from
     this software without specific prior written permission.
  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
  POSSIBILITY OF SUCH DAMAGE.
"""
try:
    import gettext
except:
    raise # Exception code is written in parent module.

_ = gettext.gettext

# Define messages used by PSL.
# pylint: disable-msg=C0301
MSG_PSL_TITLE_ERR_DLG = _('Status Monitor Console')
MSG_PSL_SETTINGS_TITLE_ERR_DLG = _('Printer Selection')

MSG_PSL_START_FAIL = _('Status Monitor Console did not appear.')
MSG_PSL_READ_SETTING_FILE_FAIL = _('Failed to read the setting file.')
MSG_PSL_READ_URL_LIST_FAIL = _('Settings dialog did not appear.')
MSG_PSL_INTERVAL_CHECK_FAIL = _('The time that can be specified at Update intervals is up to 15 to 600 second.')
MSG_PSL_PORT_CHECK_FAIL = _('The port number that can be entered is 80 and 443 and 8000 to 9999.')
MSG_PSL_COMMUNITY_NAME_CHECK_FAIL = _('The character input to the community name is illegal.')
MSG_PSL_SAVE_SETTING_FILE_FAIL = _('Failed to save the setting file.')
MSG_PSL_WEB_NOT_START = _('The Web browser did not start. Make sure the default Web browser is properly installed.')

COLUMN_TEXT_NAME = _('Printer Name')
COLUMN_TEXT_STATUS = _('Status')
COLUMN_TEXT_MODEL = _('Model Name')
COLUMN_TEXT_URI = _('URI')
# pylint: enable-msg=C0301

