"""
  This code is for checking character type.

  (C) Fuji Xerox Co., Ltd. 2010
 
  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:
  1. Redistributions of source code must retain the above copyright
     notice, this list of conditions and the following disclaimer.
  2. Redistributions in binary form must reproduce the above copyright
     notice, this list of conditions and the following disclaimer in the
     documentation and/or other materials provided with the distribution.
  3. Neither the name of Fuji Xerox Co., Ltd. nor the names of its
     contributors may be used to endorse or promote products derived from
     this software without specific prior written permission.
  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
  POSSIBILITY OF SUCH DAMAGE.
"""

try:
    import re
except:
    raise # Exception code is written in parent module.

MIN_DISPLAYABLE_CHAR = 0x20
MAX_DISPLAYABLE_CHAR = 0x7E

MIN_DEVICE_NAME_CHAR = 0x20
MAX_DEVICE_NAME_CHAR = 0x7E

def check_string(string, invalid_pattern):
    """Check string by regular expression pattern.
        
    Arguments:
    string -- String to check.
    invalid_pattern -- Regular expression of invalid pattern.
        
    Exception:
    ValueError -- When string is invalid.
    """
    # Raise exception if string includes except pattern.
    pattern = re.compile(invalid_pattern)
    result = pattern.search(string)
    if result:
        raise ValueError


def check_alphabet(string):
    """Check string by alphabet characters.
        
    Argument:
    string -- String to check.
        
    Exception:
    ValueError -- When string is invalid.
    """
    check_string(string, '[^a-zA-Z]')
    
    
def check_alphabet_with_under_bar(string):
    """Check string by alphabet characters or under bar.
    
    Argument:
    string -- String to check.
    
    Exception:
    ValueError -- When string is invalid.
    """
    check_string(string, '[^a-zA-Z_]')


def check_alphabet_with_space(string):
    """Check string by alphabet characters or space.
    
    Argument:
    string -- String to check.
    
    Exception:
    ValueError -- When string is invalid.
    """
    check_string(string, '[^a-zA-Z ]')


def check_alphanumeric(string):
    """Check string by alphanumeric characters.
    
    Argument:
    string -- String to check.
    
    Exception:
    ValueError -- When string is invalid.
    """
    check_string(string, '[^a-zA-Z0-9]')

def check_alphanumeric_with_space(string):
    """Check if string by alphanumeric characters or space.
    
    Argument:
    string -- String to check.
     
    Exception:
    ValueError -- When string is invalid.
    """
    check_string(string, '[^a-zA-Z0-9 \-]')


def check_alphanumeric_with_hyphen(string):
    """Check if string by alphanumeric characters or hyphen.
    
    Argument:
    string -- String to check.
    
    Exception:
    ValueError -- When string is invalid.
    """
    check_string(string, '[^a-zA-Z0-9\-]')


def check_url_address(string):
    """Check if string by URL permitted characters.
    Following characters is permitted in the URL address.
    a-z A-Z 0-9 - _ . / , $ ! * ' ( ) ; : @ = & + % ?
    These characters is based on 
    RFC 1738, Uniform Resource Locators (URL)
    
    Argument:
    string -- String to check.
    
    Exception:
    ValueError -- When string is invalid.
    """
    check_string(string, '[^a-zA-Z0-9\-_./,$!*\'();:@=&+%\?]')
    
    
def check_hex(string):
    """Check if string by hexadecimal number characters.
    
    Argument:
    string -- String to check.
    
    Exception:
    ValueError -- When string is invalid.
    """
    check_string(string, '[^0-9A-F]')
    
def check_displayable(string):  # pylint: disable-msg=R0201, C0301
    """Check string by displayable characters.

    Argument:
    string -- String to check.
    
    Exception:
    ValueError -- When argument contains incorrect value.
    """
    for i in string:
        if ord(i) < MIN_DISPLAYABLE_CHAR or ord(i) > MAX_DISPLAYABLE_CHAR:
            raise ValueError
        
