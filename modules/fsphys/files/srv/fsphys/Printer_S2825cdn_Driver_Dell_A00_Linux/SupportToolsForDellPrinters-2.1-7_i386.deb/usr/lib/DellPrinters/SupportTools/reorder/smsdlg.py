"""
  This class is used to show supplies reorder dialog.

  (C) Fuji Xerox Co., Ltd. 2010-2012
 
  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:
  1. Redistributions of source code must retain the above copyright
     notice, this list of conditions and the following disclaimer.
  2. Redistributions in binary form must reproduce the above copyright
     notice, this list of conditions and the following disclaimer in the
     documentation and/or other materials provided with the distribution.
  3. Neither the name of Fuji Xerox Co., Ltd. nor the names of its
     contributors may be used to endorse or promote products derived from
     this software without specific prior written permission.
  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
  POSSIBILITY OF SUCH DAMAGE.
"""

try:
    import gtk
    import gtk.glade
    import gobject
    import os
    import common.defs

    from common.defs import PATH_DLST_RESOURCE, DEFAULT_LOCALE
    from common import preventsamewindow, msgdlg, webbrowser
    from reorder import servicetagdlg, reordermisc, smsmessage
    from reorder import tellist, updatephonelistthread
    from datetime import date
except:
    raise # Exception code is written in parent module.

FILE_GLADE = 'dlsms.glade'
FILE_ICON_48x48 = 'dlsms_icon_dlsms_48x48_32.png'
FILE_ICON_16x16 = 'dlsms_icon_dlsms_16x16_32.png'
COLOR_WHITE = 'white'

# Define ATOM name string when standard start.
STANDARD_ATOM_NAME = 'Standard'

# Define time to hide notification text. The unit is millisecond.
TIME_TILL_HIDDEN_NOTIFICATION_TEXT = 20000

# Define URL of recycle site.
RECYCLE_SITE_URL = 'http://www.dell.com/recycle'


class SMSDlg(preventsamewindow.PreventSameWindow): # pylint: disable-msg=R0902
    """Show the supplies reorder dialog."""
    
    WINDOW_ATOM_NAME_OF_SMSDLG = 'SupportToolsForDellPrinters_reorder_SMSDlg'
    
    def __init__(self, parent, model):  # pylint: disable-msg=R0914, R0915, C0301
        """Show the supplies reorder dialog.
        
        Arguments:
        parent -- The parent instance of this class.
        model -- Instance of SMSModel class.
        """
        preventsamewindow.PreventSameWindow.__init__(self)
        
        # Check if this program is already running.
        self.set_window_atom_name(self.WINDOW_ATOM_NAME_OF_SMSDLG)
        if self.is_existing():
            self.move_forward()
            return
        
        self.__parent = parent
        self.__model = model
        self.__prn_model_list = model.get_model_name_list()
        
        glade = PATH_DLST_RESOURCE + FILE_GLADE
        self.widget_tree = gtk.glade.XML(glade)
        windowMain = self.widget_tree.get_widget('windowMain')
        windowMain.realize()
        self.register_window_atom(windowMain.window.xid)
        
        buttonClose = self.widget_tree.get_widget('buttonClose')
        self.comboboxPrnModel = self.widget_tree.get_widget(
                                                    'comboboxPrnModel')
        self.comboboxBrowse = self.widget_tree.get_widget('comboboxBrowse')
        self.comboboxPhone = self.widget_tree.get_widget('comboboxPhone')
        self.checkbuttonAutoUpdate = self.widget_tree.get_widget(
                                                    'checkbuttonAutoUpdate')
        self.labelUpdateNotification = self.widget_tree.get_widget(
                                                    'labelUpdateNotification')

        self.warn_dlg = msgdlg.MsgDialog(smsmessage.MSG_SMS_TITLE_ERR_DLG,
                                      PATH_DLST_RESOURCE + FILE_ICON_16x16,
                                      PATH_DLST_RESOURCE + FILE_ICON_48x48,
                                      windowMain)
        self.info_dlg = msgdlg.MsgDialog(smsmessage.MSG_SMS_TITLE_ERR_DLG,
                                      PATH_DLST_RESOURCE + FILE_ICON_16x16,
                                      PATH_DLST_RESOURCE + FILE_ICON_48x48,
                                      windowMain)
        
        for prn_model in self.__prn_model_list:
            self.comboboxPrnModel.append_text(prn_model)
        for url in model.get_url_address_list():
            self.comboboxBrowse.append_text(url)
            
        self.comboboxPrnModel.set_active(0)
        model_name = self.__prn_model_list[0]
        try:
            self.__model.set_tellist_for_selected_model(model_name)
            for phone in model.get_list_of_tel_number_with_country():
                self.comboboxPhone.append_text(phone)
                
            locale_name = reordermisc.get_locale()
            try:
                default_phone_index = \
                    model.get_index_from_locale(locale_name)
            except:
                default_phone_index = \
                    model.get_index_from_locale(DEFAULT_LOCALE)
            
            self.comboboxPhone.set_active(default_phone_index)
        except ValueError:
            pass
                
        default_url = model.get_default_url()
        default_url_index = model.get_index_from_url_name(default_url)
        self.comboboxBrowse.set_active(default_url_index)
        
        buttonClose.grab_focus()
        
        windowMain.modify_bg(gtk.STATE_NORMAL, 
                                  gtk.gdk.color_parse(COLOR_WHITE))
        
        windowMain.set_icon_list(
            gtk.gdk.pixbuf_new_from_file(PATH_DLST_RESOURCE + 
                                         FILE_ICON_16x16),
            gtk.gdk.pixbuf_new_from_file(PATH_DLST_RESOURCE + 
                                         FILE_ICON_48x48))
        
        event_dic = {
            "on_windowMain_destroy": self.quit,
            "on_buttonClose_clicked": self.quit,
            "on_buttonRecyclePage_clicked": self.button_recyclepage_clicked,
            "on_windowMain_key_press_event": self.esckey_clicked,
            "on_buttonBrowse_clicked": self.button_browse_clicked,
            "on_comboboxPrnModel_changed": self.__on_comboboxPrnModel_changed}
        self.widget_tree.signal_autoconnect(event_dic)
        
        self.__parent.set_parent_of_msgdlg(windowMain)

        # Initialize for updating phone list.
        self.labelUpdateNotification.set_child_visible(False)
        update_phone_list_check_flag = model.get_update_phone_list()
        self.checkbuttonAutoUpdate.set_active(update_phone_list_check_flag)
        if update_phone_list_check_flag and self.__check_required_update():
            self.labelUpdateNotification.set_child_visible(True)
            self.labelUpdateNotification.set_markup(
                                    smsmessage.MSG_SMS_NOTIFY_NOW_UPDATING)
            self.__update_phonelist_thread = (
                    updatephonelistthread.UpdatePhoneListThread(
                        self.__model,
                        self.__notify_finishing_update_thread_for_phonelist))
            self.__update_phonelist_thread.start()
            gtk.gdk.threads_init()          

        gtk.main()

    def __check_required_update(self):
        """Check whether phone list update is required.
        This function reads update interval and last updated date and
        confirms that update should be do this time.

        Return Values:
        True -- If update is required.
        False -- If update is not required.        
        """
        # Default is True
        retval = True
        last_updated_date = self.__model.get_phone_list_updated_date()
        update_interval = self.__model.get_phone_list_update_interval()

        if (last_updated_date is not None) and (update_interval != 0):
            today_date = date.today()
            date_diff = today_date - last_updated_date
            retval = (date_diff.days >= update_interval)
            
        return retval
          
    def button_browse_clicked(self, widget):  # pylint: disable-msg=W0613
        """Launch the browser and show the supplies order site.
        If regular URL is selected in the dialog,
        show the service tag input dialog.
        If Premier URL is selected in the dialog.
        launch browser at once.
        
        Argument:
        widget -- Instance of the buttonBrowse
        """
        model_name_index = self.comboboxPrnModel.get_active()
        url_index = self.comboboxBrowse.get_active()
        
        # Show the service tag input dialog, 
        # if regular URL is selected.
        if url_index == 0:
            model_name = self.__prn_model_list[model_name_index]
            service_tag_dlg = \
                servicetagdlg.ServiceTagDlg(model_name, STANDARD_ATOM_NAME)
            # If the service tag dialog is closed by other than the 
            # OK button, delete instance and end.
            if service_tag_dlg.get_cancel_flag():
                del service_tag_dlg
                return
            
            service_tag = service_tag_dlg.get_service_tag()
            del service_tag_dlg
        else:
            service_tag = None
        
        self.__parent.browse_order_site(model_name_index, 
                                            url_index, 
                                            service_tag)

    def button_recyclepage_clicked(self, widget):  # pylint: disable-msg=W0613
        """Launch the browser and show the recycle site.
        
        Argument:
        widget -- Instance of the buttonRecyclePage
        """
        result = webbrowser.launch_browser(RECYCLE_SITE_URL)
        if not result:
            self.warn_dlg.show_error_dialog(smsmessage.MSG_SMS_BROWSE_FAIL)
        
    def quit(self, widget):  # pylint: disable-msg=W0613
        """Close supplies reorder dialog.
        
        Argument:
        widget -- Instance of the buttonClose.
        """

        update_phone_list_check_flag = self.checkbuttonAutoUpdate.get_active()
        self.__model.set_update_phone_list(update_phone_list_check_flag)
        
        try:
            self.__model.save_cra_config()
        except:
            self.warn_dlg.show_error_dialog(
                smsmessage.MGS_SMS_SAVE_UPDATE_FLAG_FAIL)
            
        self.delete_window_atom()
        gtk.main_quit()

    def esckey_clicked(self, widget, event):
        """Quit supplies reorder dialog when esc-key is clicked.
        
        Arguments:
        widget -- A object of windowMain.
        event -- A event object of on_windowMain_key_press_event.
        """
        if event.keyval == common.defs.KEY_CODE_ESC:
            self.quit(widget)
            
    def __on_comboboxPrnModel_changed(self,  # pylint: disable-msg=W0613
                                      combobox):
        """Reset telephone list for selected printer model,
        and show phone number for current locale.
        
        Argument:
        combobox -- instance of combobox.
        
        """
        model_name_index = self.comboboxPrnModel.get_active()
        model_name = self.__prn_model_list[model_name_index]
        try:
            self.__model.set_tellist_for_selected_model(model_name)
        except ValueError:
            self.comboboxPhone.get_model().clear()
            return

        self.comboboxPhone.get_model().clear()
        for phone in self.__model.get_list_of_tel_number_with_country():
            self.comboboxPhone.append_text(phone)
            
        locale_name = reordermisc.get_locale()
        
        try:
            default_phone_index = \
                        self.__model.get_index_from_locale(locale_name)
        except:
            default_phone_index = \
                        self.__model.get_index_from_locale(DEFAULT_LOCALE)
                
        self.comboboxPhone.set_active(default_phone_index)
    
    def __notify_finishing_update_thread_for_phonelist(self, result):  # pylint: disable-msg=R0912, R0915, C0301
        """Callback from phonelist update thread and update ui
        according to the result of the thread.
        
        Argument:
        result -- The result of updating phone list file.
        """
        phone_list_file_path = reordermisc.get_user_phone_list_dir_path() + (
                                                        tellist.FILE_TEL_LIST)
        
        if result >= 0:
            if result == updatephonelistthread.SUCCEEDED_IN_UPDATE:
                # Required update ui.
                gtk.gdk.threads_enter()
                selected_index = self.comboboxPhone.get_active()
                model_name_index = self.comboboxPrnModel.get_active()
                gtk.gdk.threads_leave()
                model_name = self.__prn_model_list[model_name_index]
                old_tel_dict = None
                country_id = None
                try:
                    old_tel_dict = self.__model.get_teldict_from_index(
                                                                selected_index)
                    country_id = old_tel_dict[tellist.DIC_KEY_COUNTRY_ID]
                except IndexError:
                    old_tel_dict = None
                    
                gtk.gdk.threads_enter()
                try:
                    updated_tellist = tellist.TelList(phone_list_file_path)
                    self.__model.copy_from_tellist(updated_tellist)
                except:
                    if os.access(phone_list_file_path, os.F_OK):
                        try:
                            os.remove(phone_list_file_path)
                        except:
                            pass
                    self.__set_notification_text(
                                updatephonelistthread.FAILED_TO_MOVE_FILE)

                exists_model = True
                number_modified = True
                try:
                    self.__model.set_tellist_for_selected_model(model_name)
                    number_modified = not self.__model.is_same_telephone(
                                                                old_tel_dict)
                except ValueError:
                    # There is no phone number associated with the model.
                    exists_model = False

                if number_modified:
                    self.info_dlg.show_information_dialog(
                            smsmessage.MGS_SMS_UPDATED_PHONE_NUMBER_INFO)
                    
                if exists_model:
                    self.__update_phonelist(country_id)
                else:
                    self.comboboxPhone.get_model().clear()
                    
                self.__set_notification_text(result)
                gtk.gdk.threads_leave()
            elif result == updatephonelistthread.UNNECESSARY_UPDATE:
                # No needs to update.
                gtk.gdk.threads_enter()
                self.__set_notification_text(result)
                gtk.gdk.threads_leave()
                
            today_date = date.today()
            self.__model.set_phone_list_updated_date(today_date)
            
            try:
                self.__model.save_cra_config()
            except:
                gtk.gdk.threads_enter()
                self.warn_dlg.show_error_dialog(
                                smsmessage.MGS_SMS_SAVE_UPDATEED_DATE_FAIL)
                gtk.gdk.threads_leave()
        else:
            gtk.gdk.threads_enter()
            self.__set_notification_text(result)
            gtk.gdk.threads_leave()
            
        gobject.timeout_add(TIME_TILL_HIDDEN_NOTIFICATION_TEXT, 
                            self.__hide_notification_text)
    
    def __update_phonelist(self, country_id):
        """Update phone list combobox.
        
        Argument:
        country_id -- A country id which is currently selected. 
        """
        model_name_index = self.comboboxPrnModel.get_active()
        model_name = self.__prn_model_list[model_name_index]
        self.__model.set_tellist_for_selected_model(model_name)

        self.comboboxPhone.get_model().clear()
        for phone in self.__model.get_list_of_tel_number_with_country():
            self.comboboxPhone.append_text(phone)
            
        try:
            default_phone_index = \
                self.__model.get_index_from_country_id(country_id)
        except:
            locale_name = reordermisc.get_locale()
            try:
                default_phone_index = \
                    self.__model.get_index_from_locale(locale_name)
            except:
                default_phone_index = \
                    self.__model.get_index_from_locale(DEFAULT_LOCALE)
                
        self.comboboxPhone.set_active(default_phone_index)

    def __hide_notification_text(self):
        """Hide notification text for updating phone list.
        """
        self.labelUpdateNotification.set_child_visible(False)
        
    def __set_notification_text(self, result):
        """Set notification text for updating phone list.
        """
        if result == updatephonelistthread.SUCCEEDED_IN_UPDATE:
            self.labelUpdateNotification.set_markup(
                            smsmessage.MSG_SMS_NOTIFY_SUCCESS_IN_UPDATE)
        elif result == updatephonelistthread.UNNECESSARY_UPDATE:
            self.labelUpdateNotification.set_markup(
                                smsmessage.MSG_SMS_NOTIFY_NO_UPDATE)
        elif result == updatephonelistthread.FAILED_TO_ACCESS_SERVER:
            self.labelUpdateNotification.set_markup(
                            smsmessage.MSG_SMS_NOTIFY_FAILED_TO_CONNECT)
        elif result == updatephonelistthread.FAILED_TO_DOWNLOAD:
            self.labelUpdateNotification.set_markup(
                            smsmessage.MSG_SMS_NOTIFY_FAILED_TO_DOWNLOAD)
        elif result == updatephonelistthread.FAILED_TO_MOVE_FILE:
            self.labelUpdateNotification.set_markup(
                            smsmessage.MSG_SMS_NOTIFY_FAILED_TO_UPDATE)
    