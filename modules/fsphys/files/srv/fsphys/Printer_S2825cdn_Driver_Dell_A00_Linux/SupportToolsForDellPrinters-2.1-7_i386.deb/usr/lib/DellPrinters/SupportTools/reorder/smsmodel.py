"""
  This class is to control all files necessary for Supplies Management System.

  (C) Fuji Xerox Co., Ltd. 2010-2012
 
  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:
  1. Redistributions of source code must retain the above copyright
     notice, this list of conditions and the following disclaimer.
  2. Redistributions in binary form must reproduce the above copyright
     notice, this list of conditions and the following disclaimer in the
     documentation and/or other materials provided with the distribution.
  3. Neither the name of Fuji Xerox Co., Ltd. nor the names of its
     contributors may be used to endorse or promote products derived from
     this software without specific prior written permission.
  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
  POSSIBILITY OF SUCH DAMAGE.
"""
try:
    import os
    
    from common import urllist, printermodellist, defs
    from common import printerstatusinfo, settingconfig
    from reorder import tellist, crasettingconfig
except:
    raise # Exception code is written in parent module.

class SMSModel(urllist.URLList,  # pylint: disable-msg=R0904
              printermodellist.PrinterModelList, 
              tellist.TelList, 
              printerstatusinfo.PrinterStatusInfo, 
              settingconfig.SettingConfig,
              crasettingconfig.CRASettingConfig):
    """Manage necessary various Informations and data."""
    
    def __init__(self):
        """Constructor of this class."""
        urllist.URLList.__init__(self)
        printermodellist.PrinterModelList.__init__(self)
        try:
            tellist.TelList.__init__(self, 
                                     self.__get_existence_phonelist_path())
        except:
            tellist.TelList.__init__(self)  # pylint: disable-msg=W0233       
	printerstatusinfo.PrinterStatusInfo.__init__(self)
	settingconfig.SettingConfig.__init__(self)
        crasettingconfig.CRASettingConfig.__init__(self)

    def __get_existence_phonelist_path(self):  # pylint: disable-msg=R0201
        """Get existing phonelist file path.
        This function returns the file path in home directory if it
        exists. Otherwise default phonelist file path is returned.
        
        Return Value:
        path -- File path which is to home or etc directory.
        """
        home_dir = os.path.expanduser(defs.PATH_DLST_HOME)
        if os.access(home_dir + tellist.FILE_TEL_LIST, os.F_OK):
            return home_dir + tellist.FILE_TEL_LIST
        else:
            return defs.PATH_DLST_ETC + tellist.FILE_TEL_LIST
    
