"""
  This file is used to manage the XML files.

  (C) Fuji Xerox Co., Ltd. 2010
 
  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:
  1. Redistributions of source code must retain the above copyright
     notice, this list of conditions and the following disclaimer.
  2. Redistributions in binary form must reproduce the above copyright
     notice, this list of conditions and the following disclaimer in the
     documentation and/or other materials provided with the distribution.
  3. Neither the name of Fuji Xerox Co., Ltd. nor the names of its
     contributors may be used to endorse or promote products derived from
     this software without specific prior written permission.
  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
  POSSIBILITY OF SUCH DAMAGE.
"""

try:
    import xml.dom.minidom
    import xml.dom
except:
    raise # Exception code is written in parent module.

def get_named_child_nodes(parent, name):
    """Get child node have specified node name from parent node.
    
    Arguments:
    parent -- Parent node to get child node.
    name -- Child node name to get.
    
    Return values:
    Child nodes array -- If parent node have specified child nodes.
    
    Exception:
    ValueError -- When error occurred, or 
                  parent node don't have specified child node.
    """
    children_list = []
    if not parent or not name:
        raise ValueError
    
    for child in parent.childNodes:
        if child.nodeType == xml.dom.Node.ELEMENT_NODE and \
           child.nodeName == name:
            children_list.append(child)
    # If no child in parent, raise ValueError.
    if len(children_list) == 0:
        raise ValueError
    else:
        return children_list
    

def get_text_list(node, tag):
    """Get the text of node.
    
    Arguments:
    node -- Node which has tag.
    tag -- Tag which has text you need.
    
    Return value:
    String array -- Array of text gotten.

    Exception:
    ValueError -- When error occurred, or 
                  no text node exist.
    """
    text_list = []
    
    tag_list = get_named_child_nodes(node, tag)
    for i in tag_list:
        for j in i.childNodes:
            if j.nodeType == xml.dom.Node.TEXT_NODE:
                text_list.append(j.data)
                break
    
    return text_list


def set_text(node, tag, text):
    """Set the text of only one node.
    This method set same text to all specified nodes.
    
    Arguments:
    node -- Node which has tag.
    tag -- Tag which has text you want to set.
    text -- Text which is set.
    
    Exception:
    ValueError -- When error occurred, or 
                  no text node exist.
    """
    tag_list = get_named_child_nodes(node, tag)
    
    err_flag = True
    for i in tag_list:
        for j in i.childNodes:
            if j.nodeType == xml.dom.Node.TEXT_NODE:
                j.data = text
                err_flag = False
                
    if err_flag:
        raise ValueError
    